---

# Omni AI
The All-in-One Intelligent Workspace and Creative Studio

Omni AI is an all-in-one artificial intelligence platform designed as a comprehensive productivity assistant and digital creative studio. By uniting various state-of-the-art AI models within a single, elegant, and responsive interface, Omni AI provides seamless solutions for everyday needs. Ranging from natural language processing, advanced image generation and manipulation, and social media utility tools, to voice processing, this application is engineered to maximize user efficiency and creativity within a secure and centralized ecosystem.

![React](https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)
![FastAPI](https://img.shields.io/badge/fastapi-109989?style=for-the-badge&logo=fastapi&logoColor=white)
![SQLite](https://img.shields.io/badge/SQLite-07405E?style=for-the-badge&logo=sqlite&logoColor=white)
![Puter.js](https://img.shields.io/badge/Puter.js-Cloud_OS-blue?style=for-the-badge)

---

## Key Features

### Intelligence and Voice
1.  **Landing Page**: Perkenalan fitur utama dengan UI 3D interaktif yang responsif dan futuristik.
2.  **Login / Register Page**: Portal autentikasi pengguna yang aman sebelum mengakses workspace utama.
3.  **AI ChatBot**: Asisten cerdas dengan fitur *session history* dan penamaan judul otomatis berbasis konteks.
4.  **Jarvis Mode (TTS)**: Fitur Text-to-Speech interaktif untuk membacakan hasil respon chatbot secara *real-time*.
5.  **Speech-to-Text**: Konversi suara pengguna menjadi teks menggunakan mikrofon perangkat untuk input AI yang efisien.
6.  **AI Voice Changer**: Mengubah rekaman suara menjadi 30+ tipe suara berbeda menggunakan teknologi ElevenLabs.

### Computer Vision and Analysis
7.  **Neural Vision Stream**: Deteksi objek di sekitar secara *real-time* menggunakan kamera perangkat (YOLOv8).
8.  **Omni Vision (VQA)**: Visual Question Answering untuk mengenali dan menjawab pertanyaan berdasarkan gambar yang diunggah.
9.  **AI Face Swapper**: Pertukaran wajah antar gambar dengan penyesuaian pencahayaan otomatis (Inswapper ONNX).
10. **AI Face Analytics**: Prediksi umur dan jenis kelamin pengguna melalui analisis biometrik wajah.
11. **AI Adjustable Background**: Penghapusan latar belakang video *real-time* dengan fitur kustomisasi *green screen* dan perekaman.
12. **Gesture Control**: Navigasi dan *output* perintah melalui deteksi pola gerakan tangan dan jari.

### Creative Studio & Image Processing
13. **Animagine AI**: Pembuatan gambar berkualitas tinggi berbasis prompt khusus gaya Anime.
14. **DeepAI Art**: Versi *upgrade* generator gambar dengan kontrol *vibes* dan kustomisasi ukuran kanvas.
15. **Image Upscaler**: Meningkatkan resolusi dan ketajaman gambar secara signifikan menggunakan metode EDSR x4.
16. **Image Unblur**: Menghilangkan efek buram dan meningkatkan fokus pada foto yang tidak tajam.
17. **Image Colorizer**: Transformasi foto hitam putih klasik menjadi berwarna secara otomatis.
18. **Background Remover**: Penghapusan latar belakang gambar secara instan untuk menghasilkan format .PNG transparan.
19. **Monochrome Converter**: Konversi foto berwarna menjadi hitam putih artistik menggunakan HTML5 Canvas.
20. **3D Pixel Reconstruction**: Merekonstruksi pixel dan warna dari gambar sumber untuk membentuk objek baru yang unik.

### Web Utilities and Downloaders
21. **Web Screenshot Scanner**: Mengambil cuplikan tampilan website via URL tanpa harus membuka situs secara langsung.
22. **TikTok Downloader**: Unduh video TikTok tanpa *watermark* melalui input tautan.
23. **YouTube Video Downloader**: Alat pengunduh video YouTube yang terintegrasi.
24. **Instagram Media Downloader**: Unduh konten Reels dan postingan gambar/video dari Instagram.
25. **Threads Media Downloader**: Mendukung pengunduhan konten foto maupun video dari platform Threads.

### Administration and Management
26. **Admin Account**: Status akun khusus dengan hak akses eksklusif dan dasbor kontrol sistem.
27. **Statistik Server (Admin)**: Dasbor pemantauan penggunaan CPU, RAM, dan status jaringan secara *real-time*.
28. **Manajemen Pengguna (Admin)**: Kendali penuh untuk mengelola daftar pengguna terdaftar dan keamanan akun.
29. **Tren Penggunaan (Admin)**: Visualisasi tren interaksi harian dan statistik fitur terpopuler menggunakan grafik pie interaktif.

### System Experience
30. **Adaptive Themes**: Dukungan penuh untuk Light dan Dark mode serta optimasi responsif untuk perangkat Mobile (Android/iOS).

---

## Tech Stack

- **Frontend**: React.js (Vite)
- **Styling**: Dynamic CSS-in-JS dan Lucide Icons
- **Cloud Services**: Puter.js V2 (Cloud OS)
- **Backend**: FastAPI (Python)
- **Database**: SQLite (omni_users.db)
- **Security**: JWT (JSON Web Tokens) dan Passlib

---

## Installation and Setup

Follow these steps to get Omni AI running on your local machine.

### 1. Clone the Repository
```bash
git clone https://github.com/WilsonRusli/omni-ai.git
cd omni-ai
```

### 2. Backend Setup
Navigate to the backend folder and create a virtual environment:
```bash
cd backend
python -m venv venv
```
On Windows:
```bash
venv\Scripts\activate
```
On macOS/Linux:
```bash
source venv/bin/activate
```

Install the required modules:
```bash
pip install fastapi uvicorn pyjwt python-multipart sqlite3 passlib ultralytics ollama insightface mediapipe opencv-python numpy rembg python-dotenv requests bcrypt==3.2.0
```

### 3. Frontend Setup
Navigate to the frontend folder and install dependencies:
```bash
cd ../frontend
npm install
```

---

## Running the Application

### Start Backend (FastAPI)
```bash
python main.py
```

### Start Frontend (Vite)
In a separate terminal, run:
```bash
npm run dev
```

---

## Security and User Interface
- **Password Hashing**: Semua kata sandi dienkripsi menggunakan salted bcrypt 3.2.0.
- **Session Management**: Autentikasi ditangani via JWT yang disimpan di localStorage.
- **Interface**: Sidebar kolapsibel yang dioptimalkan untuk desktop dan mobile dengan animasi halus.

---

## Author
Kelompok MBG (Mantap Banget Gacor) :
1. Wilson Rusli (241111583)
2. Grace Christiani (241111967)
3. Kevin Halim (241111123)
4. Jessica Gunawan (241110182) 
5. David Tandersen (241110908)
Computer Science Student - AI Project

Project Started at 19-March-2026 'till Now
