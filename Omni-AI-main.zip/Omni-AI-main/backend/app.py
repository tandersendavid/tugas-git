from flask import Flask, request, jsonify
from flask_cors import CORS
import cv2
import numpy as np
import torch
from transformers import ViltProcessor, ViltForQuestionAnswering
from PIL import Image
import io

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})

# --- LOAD AI MODEL (MiDaS) ---
# Model ini akan menebak kedalaman gambar secara otomatis
model_type = "MiDaS_small" # Versi cepat agar tidak lag
midas = torch.hub.load("intel-isl/MiDaS", model_type)
device = torch.device("cpu") # Gunakan "cuda" jika ada GPU NVIDIA
midas.to(device)
midas.eval()

# Transformasi gambar untuk AI
midas_transforms = torch.hub.load("intel-isl/MiDaS", "transforms")
transform = midas_transforms.small_transform if model_type == "MiDaS_small" else midas_transforms.dpt_transform

MODEL_NAME = "dandelin/vilt-b32-finetuned-vqa"

print("Memuat Omni Vision Engine (Pro Mode)...")
processor = ViltProcessor.from_pretrained(MODEL_NAME)
model = ViltForQuestionAnswering.from_pretrained(MODEL_NAME)
model.eval()

@app.route('/vqa', methods=['POST'])
def vqa_endpoint():
    try:
        file = request.files['image']
        question = request.form['question']
        image = Image.open(io.BytesIO(file.read())).convert("RGB")

        # Proses gambar & teks
        inputs = processor(image, question, return_tensors="pt")

        with torch.no_grad():
            outputs = model(**inputs)
        
        # Model asli dandelin sudah punya kamus jawaban internal (config.id2label)
        idx = outputs.logits.argmax(-1).item()
        answer = model.config.id2label[idx]

        return jsonify({
            "status": "success",
            "answer": answer
        })
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route('/process-image', methods=['POST', 'OPTIONS'])
def process():
    if request.method == 'OPTIONS': return jsonify({"status": "ok"})

    file1 = request.files['source'].read()
    file2 = request.files['target'].read()

    img_source = cv2.imdecode(np.frombuffer(file1, np.uint8), cv2.IMREAD_COLOR)
    img_target = cv2.imdecode(np.frombuffer(file2, np.uint8), cv2.IMREAD_COLOR)

    size = 150 
    img_s = cv2.resize(img_source, (size, size))
    img_t = cv2.resize(img_target, (size, size))
    
    img_s = cv2.cvtColor(img_s, cv2.COLOR_BGR2RGB)
    img_t_rgb = cv2.cvtColor(img_t, cv2.COLOR_BGR2RGB)

    # --- PROSES AI DEPTH ESTIMATION ---
    # AI menganalisa Gambar 2 (Target)
    input_batch = transform(img_t).to(device)
    with torch.no_grad():
        prediction = midas(input_batch)
        depth_map = torch.nn.functional.interpolate(
            prediction.unsqueeze(1),
            size=img_t.shape[:2],
            mode="bicubic",
            align_corners=False,
        ).squeeze()
    
    depth_map = depth_map.cpu().numpy()
    # Normalisasi hasil AI agar nilainya 0 sampai 1
    depth_min = depth_map.min()
    depth_max = depth_map.max()
    depth_map = (depth_map - depth_min) / (depth_max - depth_min)

    # --- MAPPING PIXEL (SORTING) ---
    source_pixels = img_s.reshape(-1, 3)
    source_brightness = np.sum(source_pixels, axis=1)
    source_sorted_indices = np.argsort(source_brightness)
    sorted_source_pixels = source_pixels[source_sorted_indices]

    target_pixels = img_t_rgb.reshape(-1, 3)
    target_brightness = np.sum(target_pixels, axis=1)
    target_sorted_indices = np.argsort(target_brightness)

    pixel_data = [None] * (size * size)
    scale_factor = 0.05 

    for i in range(len(target_sorted_indices)):
        target_idx = target_sorted_indices[i]
        y_coord = target_idx // size
        x_coord = target_idx % size
        
        r, g, b = sorted_source_pixels[i].tolist()
        
        # NILAI Z SEKARANG DIAMBIL DARI HASIL AI (bukan brightness lagi!)
        depth_val = depth_map[y_coord, x_coord]

        pixel_data[target_idx] = {
            "x": (x_coord - size/2) * scale_factor,
            "y": -(y_coord - size/2) * scale_factor,
            "z": float(depth_val) * 3.5, # AI Depth multiplier
            "r": r, "g": g, "b": b
        }

    return jsonify(pixel_data)

if __name__ == '__main__':
    app.run(port=5000)