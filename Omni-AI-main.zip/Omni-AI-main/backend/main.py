import time
import winsound


from fastapi import FastAPI, File, UploadFile, BackgroundTasks, Header, HTTPException, Depends, Query, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, Response, FileResponse
from transformers import ViltProcessor, ViltForQuestionAnswering
from PIL.ExifTags import TAGS
from cryptography.fernet import Fernet
import base64
import ollama
import google.generativeai as genai
import uvicorn
import requests
import psutil
import os
import cv2
import numpy as np
from ultralytics import YOLO
from dotenv import load_dotenv
import urllib.request
from cv2 import dnn_superres
from rembg import remove
import torch
from PIL import Image
import io


import sqlite3
import jwt
import datetime
from passlib.context import CryptContext
from pydantic import BaseModel

# --- IMPORTS UNTUK FACE SWAP & VIRTUAL BACKGROUND ---
import insightface
from insightface.app import FaceAnalysis
import mediapipe as mp # <--- TAMBAHKAN INI

load_dotenv()
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")
last_audio_time = 0

print("Memuat model MediaPipe Hands...")
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=1,
    min_detection_confidence=0.7,
    min_tracking_confidence=0.5
)
mp_draw = mp.solutions.drawing_utils
print("✅ MediaPipe Hands siap!")

# --- LOGIKA RECONSTRUCTION (MiDaS) ---
model_type = "MiDaS_small"
midas = torch.hub.load("intel-isl/MiDaS", model_type)
midas.to(torch.device("cpu"))
midas.eval()
midas_transforms = torch.hub.load("intel-isl/MiDaS", "transforms")
transform = midas_transforms.small_transform if model_type == "MiDaS_small" else midas_transforms.dpt_transform
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Konfigurasi Gemini
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
genai.configure(api_key=GOOGLE_API_KEY)
# Gunakan model 'gemini-1.5-flash' untuk respon super cepat
gemini_model = genai.GenerativeModel('gemini-2.5-flash')

# --- LOGIKA OMNI VISION (ViLT) ---
MODEL_NAME = "dandelin/vilt-b32-finetuned-vqa"
try:
    processor = ViltProcessor.from_pretrained(MODEL_NAME, local_files_only=True)
    model_vilt = ViltForQuestionAnswering.from_pretrained(MODEL_NAME, local_files_only=True)
    model_vilt.eval()
except Exception as e:
    print(f"Peringatan: ViLT gagal dimuat secara offline. Detail: {e}")


pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
SECRET_KEY = "omni_rahasia_super_kuat_123" # Kunci rahasia untuk Token

# Membuat File Database SQLite otomatis
conn = sqlite3.connect("omni_users.db", check_same_thread=False)
cursor = conn.cursor()
cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT,
        credits INTEGER DEFAULT 50,
        is_premium INTEGER DEFAULT 0,
        last_login DATE DEFAULT (date('now', 'localtime'))
    )
""")
conn.commit()

cursor.execute("""
    CREATE TABLE IF NOT EXISTS activity_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        feature TEXT,
        timestamp DATETIME DEFAULT (datetime('now', 'localtime'))
    )
""")
conn.commit()

def log_activity(feature: str):
    try:
        cursor.execute("INSERT INTO activity_logs (feature) VALUES (?)", (feature,))
        conn.commit()
    except:
        pass

def get_credit_checker(cost: int):
    async def consume_credit(
        authorization: str = Header(None), 
        token: str = Query(None) # <--- Tambahkan ini untuk membaca dari URL (?token=...)
    ):
        # 1. Cari token di Header dulu, kalau tidak ada baru cari di URL
        final_token = None
        if authorization and authorization.startswith("Bearer "):
            final_token = authorization.split(" ")[1]
        elif token:
            final_token = token

        if not final_token:
            raise HTTPException(status_code=401, detail="Token tidak ditemukan. Silakan login.")
        
        try:
            # 2. Dekode token yang ditemukan
            payload = jwt.decode(final_token, SECRET_KEY, algorithms=["HS256"])
            username = payload.get("sub")
            
            cursor.execute("SELECT id, credits, is_premium FROM users WHERE username = ?", (username,))
            user = cursor.fetchone()
            
            if not user:
                raise HTTPException(status_code=401, detail="User tidak valid.")
            
            user_id, credits, is_premium = user
            
            # Admin & Wilson gratis
            if is_premium == 1 or username.lower() in ["wilson", "admin"]:
                return username
                
            if credits < cost:
                raise HTTPException(status_code=403, detail=f"Kredit tidak cukup! Butuh {cost}")
            
            # Potong kredit
            cursor.execute("UPDATE users SET credits = credits - ? WHERE id = ?", (cost, user_id))
            conn.commit()
            
            return username

        except jwt.ExpiredSignatureError:
            raise HTTPException(status_code=401, detail="Sesi login habis.")
        except Exception:
            raise HTTPException(status_code=401, detail="Akses ditolak.")
            
    return consume_credit

def generate_safe_key(user_key: str):
    # AES Fernet butuh kunci 32-byte base64
    key = user_key.ljust(32)[:32] # Pastikan 32 karakter
    return base64.urlsafe_b64encode(key.encode())


def text_to_binary(text):
    return ''.join(format(ord(c), '08b') for c in text)

class UserData(BaseModel):
    username: str
    password: str

class CreditUpdate(BaseModel):
    credits: int

model_path_x4 = "EDSR_x4.pb"
if not os.path.exists(model_path_x4):
    urllib.request.urlretrieve("https://github.com/Saafke/EDSR_Tensorflow/raw/master/models/EDSR_x4.pb", model_path_x4)

sr = dnn_superres.DnnSuperResImpl_create()
sr.readModel(model_path_x4)
sr.setModel("edsr", 4)
# ==========================================
# INISIALISASI MODEL AI (YOLO, INSIGHTFACE, MEDIAPIPE)
# ==========================================


DIR = r"D:\Semester 4\Kecerdasan Artificial\Proyek AI\backend" # Sesuaikan path folder kamu
PROTOTXT = os.path.join(DIR, "colorization_deploy_v2.prototxt")
MODEL = os.path.join(DIR, "colorization_release_v2.caffemodel")
POINTS = os.path.join(DIR, "pts_in_hull.npy")

# Muat Model Caffe
net = cv2.dnn.readNetFromCaffe(PROTOTXT, MODEL)
pts = np.load(POINTS)

# Tambahkan cluster centers ke model
class8 = net.getLayerId("class8_ab")
conv8 = net.getLayerId("conv8_313_rh")
pts = pts.transpose().reshape(2, 313, 1, 1)
net.getLayer(class8).blobs = [pts.astype("float32")]
net.getLayer(conv8).blobs = [np.full([1, 313], 2.606, dtype="float32")]

# 1. Model YOLO (Vision)
model_yolo = YOLO("yolov8n.pt")
import torch
torch.set_num_threads(2)

# 2. Model Face Swap (Buffalo_L & Inswapper ONNX)
face_swap_ready = False
try:
    print("Memuat model Face Swap Buffalo_L... (Harap tunggu)")
    # Ini mendownload model pendeteksi 'buffalo_l' (300MB) jika belum ada
    face_app = FaceAnalysis(name='buffalo_l')
    face_app.prepare(ctx_id=0, det_size=(640, 640))
    # Memuat file inswapper_128.onnx di folder backend
    swapper = insightface.model_zoo.get_model('inswapper_128.onnx', download=False, download_zip=False)
    face_swap_ready = True
    print("✅ Model Face Swap berhasil dimuat!")
except Exception as e:
    print(f"❌ Peringatan: Model Face Swap gagal dimuat. Detail: {e}")

# 3. Model MediaPipe Selfie Segmentation (Virtual Background)
print("Memuat model MediaPipe Segmentation... (Enteng)")
import mediapipe.python.solutions.selfie_segmentation as mp_selfie_module
mp_selfie = mp_selfie_module
# model_selection=0 untuk performa cepat (CPU), =1 untuk kualitas tinggi (GPU)
selfie_seg = mp_selfie.SelfieSegmentation(model_selection=0)
print("✅ MediaPipe Segmentation siap!")




@app.get("/")
def home():
    return {"status": "Online", "system": "Omni Node v3 (Hybrid AI + Vision Suite)"}

# ==========================================
# GESTURE MANAJEMEN KAMERA (SINGLETON)
# ==========================================
# Agar tidak konflik 'Camera already in use', kita pakai satu objek kamera saja
camera = None
custom_bg_image = None
is_recording = False
video_writer = None
is_ai_active = False

def get_camera():
    global camera
    if camera is None or not camera.isOpened():
        if camera is not None:
            camera.release()
        camera = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    return camera


# ==========================================
# ENDPOINT: REGISTER
# ==========================================
@app.post("/api/register")
async def register_user(user: UserData):
    hashed_pw = pwd_context.hash(user.password) # Acak password agar aman
    try:
        cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (user.username, hashed_pw))
        conn.commit()
        return {"status": "success", "message": "Registrasi berhasil! Silakan Login."}
    except sqlite3.IntegrityError:
        return {"status": "error", "message": "Username sudah terdaftar!"}

# ==========================================
# ENDPOINT: LOGIN
# ==========================================
# ==========================================
# ENDPOINT: LOGIN
# ==========================================
@app.post("/api/login")
async def login_user(user: UserData):
    cursor.execute("SELECT password, credits, last_login FROM users WHERE username = ?", (user.username,))
    row = cursor.fetchone()

    if row and pwd_context.verify(user.password, row[0]):
        stored_credits = row[1]
        last_login = row[2]
        today = datetime.date.today().isoformat()

        # LOGIKA RESET HARIAN
        if last_login != today:
            stored_credits = 50
            cursor.execute("UPDATE users SET credits = 50, last_login = ? WHERE username = ?", (today, user.username))
            conn.commit()

        token = jwt.encode(
            {"sub": user.username, "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=24)}, 
            SECRET_KEY, algorithm="HS256"
        )
        
        user_role = "admin" if user.username.lower() in ["wilson", "admin"] else "user"
        
        return {
            "status": "success", 
            "token": token, 
            "username": user.username,
            "role": user_role,
            "credits": stored_credits # Kirim info kredit ke React
        }
    else:
        return {"status": "error", "message": "Username atau Password salah!"}
    
@app.get("/api/users")
async def get_all_users():
    # Tambahkan 'credits' pada perintah SELECT
    cursor.execute("SELECT id, username, credits FROM users")
    rows = cursor.fetchall()
    
    user_list = []
    for row in rows:
        role = "admin" if row[1].lower() in ["wilson", "admin"] else "user"
        user_list.append({
            "id": row[0], 
            "username": row[1], 
            "role": role, 
            "credits": row[2] 
        })
        
    return {"status": "success", "data": user_list}

@app.get("/api/user/me")
async def get_current_user_info(
    # Kita gunakan biaya 0 agar admin/wilson tetap bisa masuk tanpa potong saldo
    username: str = Depends(get_credit_checker(0)) 
):
    # Ambil data saldo real-time dari database
    cursor.execute("SELECT credits FROM users WHERE username = ?", (username,))
    row = cursor.fetchone()
    
    if row:
        return {
            "username": username,
            "credits": row[0]
        }
    raise HTTPException(status_code=404, detail="User tidak ditemukan")

# ==========================================
# ENDPOINT 1: CHATBOT HIBRIDA (Tidak Berubah)
# ==========================================
@app.post("/api/chat")
async def chat_ai(
    message: str = Form(...), # Ubah ke Form agar bisa kirim file & teks bareng
    image: UploadFile = File(None), 
    username: str = Depends(get_credit_checker(1))
):
    log_activity(f"Chatbot AI oleh {username}")
    
    try:
        # LOGIKA 1: Jika ada gambar, langsung lempar ke Gemini (Cloud)
        if image:
            img_bytes = await image.read()
            img_data = Image.open(io.BytesIO(img_bytes))
            
            # Gemini memproses teks + gambar
            response = gemini_model.generate_content([message, img_data])
            return {"reply": response.text, "source": "Gemini Vision (Cloud)"}

        # LOGIKA 2: Jika hanya teks, coba Ollama lokal dulu (Hemat Biaya)
        try:
            response = ollama.chat(model='gemma3:4b', messages=[{'role': 'user', 'content': message}])
            return {"reply": response['message']['content'], "source": "local"}
            
        except Exception:
            # LOGIKA 3: Fallback ke Gemini API jika Ollama mati
            if not GOOGLE_API_KEY:
                raise Exception("Gemini API Key tidak diatur")
                
            response = gemini_model.generate_content(message)
            return {"reply": f"{response.text}\n\n*(Sistem dialihkan ke Gemini Cloud)*", "source": "Gemini Cloud"}
            
    except Exception as e:
        # REFUND otomatis jika semua jalur gagal
        cursor.execute("UPDATE users SET credits = credits + 1 WHERE username = ?", (username,))
        conn.commit()
        return {"reply": f"### Critical Failure\nSistem tidak merespon: {str(e)}"}


# ==========================================
# ENDPOINT 2: NEURAL VISION (YOLO Stream)
# ==========================================
def gen_frames_yolo():
    global is_ai_active
    is_ai_active = True
    cam = get_camera()
    
    try:
        while is_ai_active:
            success, frame = cam.read()
            if not success or not is_ai_active: 
                break

            frame = cv2.resize(frame, (640, 480))
            results = model_yolo(frame, conf=0.5, verbose=False)
            total_object = len(results[0].boxes)
            annotated_frame = results[0].plot()
            
            cv2.putText(annotated_frame, f'Total YOLO: {total_object}', (10, 50), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2, cv2.LINE_AA)
            ret, buffer = cv2.imencode('.jpg', annotated_frame)
            yield (b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
            
    finally:
        # HUKUM MUTLAK: Lepaskan akses hardware agar lampu kamera mati!
        if cam is not None and cam.isOpened():
            cam.release()

@app.get("/api/vision/stream")
async def video_feed_yolo(
    username: str = Depends(get_credit_checker(5)) # <--- Biaya 5 kredit untuk akses YOLO Stream
):
    log_activity(f"YOLO Object Detection oleh {username}")
    
    # Menampilkan YOLO (Frame dengan kotak-kotak deteksi objek)
    return StreamingResponse(
        gen_frames_yolo(), 
        media_type="multipart/x-mixed-replace; boundary=frame"
    )

def delete_video_file(path: str):
    try:
        if os.path.exists(path):
            os.remove(path)
            print(f"🗑️ File {path} berhasil dihapus dari server setelah diunduh.")
    except Exception as e:
        print(f"❌ Gagal menghapus file: {e}")

@app.get("/api/vision/download_record")
async def download_recorded_video(background_tasks: BackgroundTasks):
    file_path = "rekaman_omni.avi"
    
    if os.path.exists(file_path):
        # Rahasianya ada di sini: Jalankan fungsi hapus file SETELAH video selesai dikirim ke browser user
        background_tasks.add_task(delete_video_file, file_path)
        
        # Kirim file video ke user
        return FileResponse(path=file_path, filename="Omni_Studio_Record.avi", media_type="video/x-msvideo")
    
    return {"error": "File rekaman tidak ditemukan."}

@app.post("/api/vision/stop")
async def stop_vision():
    global camera, is_recording, video_writer, is_ai_active
    
    # 1. Matikan saklar utama agar semua loop (while) berhenti seketika
    is_ai_active = False
    is_recording = False
    
    # 2. Hentikan file rekaman jika ada
    if video_writer is not None:
        video_writer.release()
        video_writer = None
        
    # 3. Lepaskan global kamera secara paksa
    if camera is not None and camera.isOpened():
        camera.release()
    camera = None

    # 4. Hancurkan jendela OpenCV yang mungkin tersisa di memori
    cv2.destroyAllWindows() 
    
    import gc
    gc.collect() 
    
    import torch
    if torch.cuda.is_available():
        torch.cuda.empty_cache() # Bersihkan VRAM jika pakai GPU (NVIDIA)
    else:
        torch.set_grad_enabled(False) # Ringankan beban memori jika pakai CPU
        
    return {"status": "Hardware Kamera Diputus, Lampu Dimatikan."}

# ==========================================
# ENDPOINT NEW: AI VIRTUAL BACKGROUND (MediaPipe Stream)
# ==========================================
def gen_frames_vb():
    # KUNCI 1: Panggil is_recording dan video_writer ke dalam global
    global camera, is_ai_active, custom_bg_image, is_recording, video_writer
    is_ai_active = True
    
    cam = get_camera()
    while is_ai_active:
        success, frame = cam.read()
        if not success or not is_ai_active:
            break
            
        frame = cv2.resize(frame, (640, 480))
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = selfie_seg.process(frame_rgb)
        
        if results.segmentation_mask is not None:
            mask = results.segmentation_mask
            condition = mask > 0.5 
            
            if custom_bg_image is not None:
                bg_image = cv2.resize(custom_bg_image, (640, 480))
            else:
                bg_image = np.zeros(frame.shape, dtype=np.uint8)
                bg_image[:] = [0, 255, 0]
                
            output_frame = np.where(condition[..., None], frame, bg_image)
        else:
            output_frame = frame
            
        # ====================================================
        # KUNCI 2: LOGIKA PEREKAMAN (YANG SEBELUMNYA HILANG)
        # ====================================================
        if is_recording:
            # Jika video_writer belum nyala, nyalakan sekarang
            if video_writer is None:
                fourcc = cv2.VideoWriter_fourcc(*'XVID')
                # Resolusi harus sama persis dengan output_frame (640x480)
                video_writer = cv2.VideoWriter('rekaman_omni.avi', fourcc, 20.0, (640, 480))
            
            # Tulis frame demi frame ke dalam file
            video_writer.write(output_frame)
        # ====================================================

        ret, buffer = cv2.imencode('.jpg', output_frame)
        yield (b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
        
    if camera:
        camera.release()
        camera = None

# ==========================================
# ENDPOINT: REAL-TIME FACE ANALYTICS
# ==========================================
def gen_frames_analytics():
    global is_ai_active, camera
    is_ai_active = True
    
    if not face_swap_ready:
        yield (b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + b'')
        return

    cam = get_camera()
    
    try:
        while is_ai_active:
            success, frame = cam.read()
            if not success or not is_ai_active: 
                break

            # 1. Perkecil gambar agar AI tidak membaca pixel terlalu banyak
            frame = cv2.resize(frame, (640, 480))

            # 2. Deteksi Wajah menggunakan InsightFace
            faces = face_app.get(frame)

            for face in faces:
                bbox = face.bbox.astype(int)
                cv2.rectangle(frame, (bbox[0], bbox[1]), (bbox[2], bbox[3]), (255, 255, 0), 2)

                gender = "Male" if face.gender == 1 else "Female"
                age = int(face.age)

                label = f"{gender}, {age} yrs"
                cv2.putText(frame, label, (bbox[0], bbox[1] - 10), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)

            ret, buffer = cv2.imencode('.jpg', frame)
            
            # 3. Peredam Kejut jika koneksi browser diputus
            try:
                yield (b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
            except Exception:
                break
                
            # 4. REM CPU (SANGAT PENTING UNTUK INSIGHTFACE!)
            # InsightFace sangat berat. Kita beri jeda 0.1 detik (10 FPS). 
            # Mata manusia tetap melihatnya real-time, tapi CPU kamu bisa istirahat 50%!
            time.sleep(0.1) 

    finally:
        # 5. PEMUTUS ARUS: Matikan lampu kamera hardware
        if cam is not None and cam.isOpened():
            cam.release()

@app.get("/api/vision/stream_analytics")
async def video_feed_analytics(
    username: str = Depends(get_credit_checker(5)) # <--- Biaya 5 kredit untuk akses analytics
):
    log_activity(f"Face Analytics oleh {username}")
    
    # Menampilkan Real-time Face Analytics (Umur & Gender)
    return StreamingResponse(
        gen_frames_analytics(), 
        media_type="multipart/x-mixed-replace; boundary=frame"
    )


@app.post("/api/vision/background")
async def set_background(file: UploadFile = File(...)):
    global custom_bg_image
    try:
        contents = await file.read()
        np_arr = np.frombuffer(contents, np.uint8)
        img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        custom_bg_image = img
        return {"status": "success"}
    except Exception as e:
        return {"error": str(e)}

@app.post("/api/vision/record")
async def toggle_record(data: dict):
    global is_recording, video_writer
    action = data.get("action")
    
    if action == "start":
        is_recording = True
        return {"status": "Recording dimulai"}
        
    elif action == "stop":
        is_recording = False
        saved_path = "Gagal menyimpan"
        
        if video_writer is not None:
            video_writer.release()
            video_writer = None
            time.sleep(1.0) # Jeda untuk memastikan OS selesai menyimpan
            
            # Ambil path lengkap (Absolute Path) tempat file disimpan
            saved_path = os.path.join(os.getcwd(), "rekaman_omni.avi")
            
        return {
            "status": "Recording selesai disimpan.",
            "path": saved_path # <--- Ini data baru yang dikirim ke React
        }

@app.get("/api/vision/stream_vb")
async def video_feed_vb():
    log_activity("Virtual Background")
    # Menampilkan AI Virtual Background (Kamar hilang, diganti warna hijau biner)
    return StreamingResponse(gen_frames_vb(), media_type="multipart/x-mixed-replace; boundary=frame")


# ==========================================
# ENDPOINT 3: FACE SWAP (Tidak Berubah)
# ==========================================
@app.post("/api/faceswap")
async def face_swap(
    source_img: UploadFile = File(...), 
    target_img: UploadFile = File(...),
    username: str = Depends(get_credit_checker(3))
):
    log_activity(f"Face Swap AI oleh {username}")
    
    if not face_swap_ready:
        cursor.execute("UPDATE users SET credits = credits + 3 WHERE username = ?", (username,))
        conn.commit()
        return {"error": "Model Face Swap tidak siap. Cek terminal backend."}
        
    try:
        source_bytes = await source_img.read()
        target_bytes = await target_img.read()
        
        source_np = cv2.imdecode(np.frombuffer(source_bytes, np.uint8), cv2.IMREAD_COLOR)
        target_np = cv2.imdecode(np.frombuffer(target_bytes, np.uint8), cv2.IMREAD_COLOR)
        
        source_faces = face_app.get(source_np)
        target_faces = face_app.get(target_np)
        
        if not source_faces or not target_faces:
            # Jika gagal deteksi wajah, kembalikan kreditnya karena AI tidak bekerja penuh
            cursor.execute("UPDATE users SET credits = credits + 3 WHERE username = ?", (username,))
            conn.commit()
            return {"error": "Gagal: Wajah tidak terdeteksi di salah satu foto."}

        source_face = source_faces[0]
        target_face = target_faces[0]
        
        result_img = swapper.get(target_np, target_face, source_face, paste_back=True)
        _, encoded_img = cv2.imencode('.jpg', result_img)
        
        return Response(content=encoded_img.tobytes(), media_type="image/jpeg")
        
    except Exception as e:
        # Jika error sistem, kembalikan juga kreditnya
        cursor.execute("UPDATE users SET credits = credits + 3 WHERE username = ?", (username,))
        conn.commit()
        return {"error": f"Gagal memproses gambar: {str(e)}"}
    

def gen_frames_gesture():
    global camera, is_ai_active, last_audio_time
    cam = get_camera()
    is_ai_active = True
    
    try:
        while is_ai_active:
            success, frame = cam.read()
            if not success or not is_ai_active: break
            
            frame = cv2.flip(frame, 1) # Mode Cermin
            frame = cv2.resize(frame, (640, 480))
            img_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(img_rgb)

            gesture_msg = "Menunggu Tangan..."
            command_msg = ""
            
            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks:
                    mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
                    landmarks = hand_landmarks.landmark
                    
                    # -- LOGIKA JARI-JARI --
                    # 4 Jari menekuk?
                    fingers_folded = [
                        landmarks[8].y > landmarks[6].y,   # Telunjuk
                        landmarks[12].y > landmarks[10].y, # Tengah
                        landmarks[16].y > landmarks[14].y, # Manis
                        landmarks[20].y > landmarks[18].y  # Kelingking
                    ]
                    
                    # Jempol Tegak: Ujung jempol (4) harus LEBIH TINGGI dari sendi pangkal telunjuk (5)
                    is_thumb_up = landmarks[4].y < landmarks[5].y
                    
                    # Posisi pergelangan tangan (landmark 0) di setengah layar ke atas?
                    is_hand_high = landmarks[0].y < 0.5 
                    
                    # Tangan Mengepal: 4 jari menekuk, dan jempol TIDAK tegak (ujungnya lebih rendah dari sendi telunjuk)
                    is_fist = all(fingers_folded) and not is_thumb_up

                    # -- EKSEKUSI EASTER EGG --
                    if all(fingers_folded) and is_thumb_up:
                        gesture_msg = "THUMBS-UP DETECTED (✌️)"
                        command_msg = "SELAMAT, BERJUANG, SUKSES!" 
                        color_glow = (0, 255, 0) # Hijau
                        
                    elif is_fist and is_hand_high:
                        gesture_msg = "FIST RAISED (✊)"
                        command_msg = "HIDUP JOKOWI!!!"
                        color_glow = (0, 0, 255) # Merah membara!
                        
                        # --- FITUR PUTAR AUDIO (Dengan Cooldown 5 Detik) ---
                        current_time = time.time()
                        if current_time - last_audio_time > 5.0: # Jeda agar suara tidak bertabrakan
                            try:
                                # SND_ASYNC = Putar di background, jangan bikin video macet!
                                winsound.PlaySound("jokowi.wav", winsound.SND_FILENAME | winsound.SND_ASYNC)
                                last_audio_time = current_time
                            except Exception as e:
                                print("Gagal putar audio. Pastikan file jokowi.wav ada di folder backend.")
                                
                    else:
                        gesture_msg = "GESTURE ACTIVE"

            # -- GAMBAR TEKS AESTHETIC KE VIDEO --
            if command_msg:
                font = cv2.FONT_HERSHEY_SIMPLEX
                text_size = cv2.getTextSize(command_msg, font, 1.2, 3)[0]
                text_x = (frame.shape[1] - text_size[0]) // 2
                text_y = (frame.shape[0] + text_size[1]) // 2
                
                # Glow hitam pekat sebagai bayangan
                cv2.putText(frame, command_msg, (text_x+3, text_y+3), font, 1.2, (0, 0, 0), 6, cv2.LINE_AA)
                # Teks warna menyala
                cv2.putText(frame, command_msg, (text_x, text_y), font, 1.2, color_glow, 3, cv2.LINE_AA)

            # Teks status kecil di pojok kiri atas
            cv2.putText(frame, gesture_msg, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            
            ret, buffer = cv2.imencode('.jpg', frame)
            
            # Peredam Kejut Browser
            try:
                yield (b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
            except Exception:
                break
                
            
    finally:
        if cam is not None and cam.isOpened():
            cam.release()

@app.get("/api/vision/stream_gesture")
async def video_feed_gesture(
    username: str = Depends(get_credit_checker(3)) 
):
    # Sekarang log_activity bisa mencatat siapa yang menggunakan gestur
    log_activity(f"Gesture Control oleh {username}")
    
    return StreamingResponse(
        gen_frames_gesture(), 
        media_type="multipart/x-mixed-replace; boundary=frame"
    )

@app.post("/api/upscale")
async def upscale_image(
    file: UploadFile = File(...),
    username: str = Depends(get_credit_checker(2)) # Berubah menjadi 2 kredit
):
    log_activity(f"Image Upscaler oleh {username}")
    
    try:
        contents = await file.read()
        nparr = np.frombuffer(contents, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

        if img is None:
            # Refund 2 kredit jika gambar tidak valid
            cursor.execute("UPDATE users SET credits = credits + 2 WHERE username = ?", (username,))
            conn.commit()
            return {"error": "Invalid image"}

        # Cek resolusi agar server tidak timeout (Limit 2000px)
        h, w = img.shape[:2]
        if h * w > 2000 * 2000:
            cursor.execute("UPDATE users SET credits = credits + 2 WHERE username = ?", (username,))
            conn.commit()
            return {"error": "Resolusi terlalu besar untuk Upscale x4"}

        # Proses Upscale (EDSR x4)
        upscaled = sr.upsample(img)

        # Proses Sharpening
        kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
        upscaled = cv2.filter2D(upscaled, -1, kernel)

        _, encoded_img = cv2.imencode('.png', upscaled)
        
        # Mengembalikan file biner agar diterima sebagai 'blob' di React
        return Response(content=encoded_img.tobytes(), media_type="image/png")

    except Exception as e:
        # Refund 2 kredit otomatis jika terjadi error sistem
        cursor.execute("UPDATE users SET credits = credits + 2 WHERE username = ?", (username,))
        conn.commit()
        print(f"Upscale Error: {str(e)}")
        return {"error": "Gagal memproses gambar"}

# ==========================================
# ENDPOINT 7: AI IMAGE UNBLUR (SHARPENING)
# ==========================================
@app.post("/api/unblur")
async def unblur_image(
    file: UploadFile = File(...),
    username: str = Depends(get_credit_checker(3)) # <--- Biaya 3 kredit
):
    log_activity(f"Image Unblur oleh {username}")
    try:
        contents = await file.read()
        nparr = np.frombuffer(contents, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

        if img is None:
            # REFUND: Kembalikan kredit jika file tidak valid
            cursor.execute("UPDATE users SET credits = credits + 3 WHERE username = ?", (username,))
            conn.commit()
            return {"error": "Invalid image"}

        # --- Proses Image Unblur (Sharpening Logic) ---
        smoothed = cv2.bilateralFilter(img, 5, 50, 50)

        gaussian_blur = cv2.GaussianBlur(smoothed, (0, 0), 1.0)
        unblurred = cv2.addWeighted(smoothed, 1.1, gaussian_blur, -0.1, 0)

        kernel = np.array([[0, -0.1, 0], 
                           [-0.1, 1.4, -0.1], 
                           [0, -0.1, 0]])
        final_img = cv2.filter2D(unblurred, -1, kernel)
        # ----------------------------------------------

        _, encoded_img = cv2.imencode('.png', final_img)
        return Response(content=encoded_img.tobytes(), media_type="image/png")

    except Exception as e:
        # REFUND: Kembalikan kredit jika terjadi error sistem
        cursor.execute("UPDATE users SET credits = credits + 3 WHERE username = ?", (username,))
        conn.commit()
        return {"error": str(e)}
    
@app.post("/api/colorize")
async def colorize_image(
    file: UploadFile = File(...),
    username: str = Depends(get_credit_checker(3)) # <--- Biaya 3 kredit
):
    log_activity(f"Image Colorizer oleh {username}")
    try:
        contents = await file.read()
        nparr = np.frombuffer(contents, np.uint8)
        image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

        if image is None:
            # REFUND: Kembalikan kredit jika file bukan gambar yang valid
            cursor.execute("UPDATE users SET credits = credits + 3 WHERE username = ?", (username,))
            conn.commit()
            return {"error": "Invalid image"}

        # --- Proses AI Colorization ---
        # 1. Konversi ke ruang warna Lab dan ambil channel 'L' (Lightness)
        scaled = image.astype("float32") / 255.0
        lab = cv2.cvtColor(scaled, cv2.COLOR_BGR2LAB)
        
        # Resize untuk input model (224x224)
        resized = cv2.resize(lab, (224, 224))
        L = cv2.split(resized)[0]
        L -= 50 # Mean subtraction

        # 2. Prediksi channel 'a' dan 'b' (Warna) menggunakan Model Caffe
        net.setInput(cv2.dnn.blobFromImage(L))
        ab = net.forward()[0, :, :, :].transpose((1, 2, 0))
        ab = cv2.resize(ab, (image.shape[1], image.shape[0]))

        # 3. Gabungkan kembali L dengan prediksi a, b
        L = cv2.split(lab)[0]
        colorized = np.concatenate((L[:, :, np.newaxis], ab), axis=2)
        colorized = cv2.cvtColor(colorized, cv2.COLOR_LAB2BGR)
        colorized = np.clip(colorized, 0, 1)
        colorized = (255 * colorized).astype("uint8")
        # ------------------------------

        _, encoded_img = cv2.imencode('.png', colorized)
        return Response(content=encoded_img.tobytes(), media_type="image/png")

    except Exception as e:
        # REFUND: Kembalikan kredit jika terjadi crash pada sistem AI
        cursor.execute("UPDATE users SET credits = credits + 3 WHERE username = ?", (username,))
        conn.commit()
        return {"error": f"Gagal memproses pewarnaan: {str(e)}"}

@app.post("/api/remove-bg")
async def remove_background(
    file: UploadFile = File(...),
    username: str = Depends(get_credit_checker(3)) # <--- Biaya 3 kredit
):
    log_activity(f"Background Remover oleh {username}")
    try:
        contents = await file.read()
        nparr = np.frombuffer(contents, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

        if img is None:
            # REFUND: Jika file bukan gambar yang valid
            cursor.execute("UPDATE users SET credits = credits + 3 WHERE username = ?", (username,))
            conn.commit()
            return {"error": "Invalid image"}

        # Proses penghapusan background menggunakan AI (rembg)
        # Hasilnya otomatis berupa format RGBA (Transparan)
        output = remove(img)

        # Encode ke PNG agar transparansinya terjaga
        _, encoded_img = cv2.imencode('.png', output)
        return Response(content=encoded_img.tobytes(), media_type="image/png")

    except Exception as e:
        # REFUND: Jika terjadi error pada proses AI
        cursor.execute("UPDATE users SET credits = credits + 3 WHERE username = ?", (username,))
        conn.commit()
        return {"error": str(e)}

@app.get("/api/proxy/image")
async def proxy_image(url: str):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
        "Referer": "https://www.tiktok.com/", # <--- WAJIB: Biar dikira dari TikTok asli
        "Accept-Language": "en-US,en;q=0.9"
    }
    try:
        # Gunakan stream=True agar hemat RAM
        resp = requests.get(url, headers=headers, stream=True, timeout=15)
        
        # Kirim balik ke React dengan header yang tepat
        return StreamingResponse(
            resp.iter_content(chunk_size=1024), 
            media_type=resp.headers.get("Content-Type", "image/webp")
        )
    except Exception as e:
        return {"error": str(e)}

# ==========================================
# PROXY DOWNLOAD (SUDAH DINAMIS MP4 / JPG)
# ==========================================
@app.get("/api/proxy/download")
async def proxy_download(
    url: str, 
    username: str = Depends(get_credit_checker(3)) # <--- Biaya 3 kredit saat download
):
    log_activity(f"Proxy Download oleh {username}")
    try:
        resp = requests.get(url, stream=True, timeout=30)
        
        # 1. Intip tipe file asli dari server
        content_type = resp.headers.get("Content-Type", "")
        
        # 2. Tentukan ekstensi berdasarkan tipe file
        ext = "mp4" # Default
        if "image" in content_type:
            ext = "jpg"
            
        # 3. Beri nama file yang dinamis
        headers = {"Content-Disposition": f"attachment; filename=Omni_Media.{ext}"}
        
        return StreamingResponse(resp.iter_content(chunk_size=4096), headers=headers)
        
    except Exception as e:
        # REFUND: Jika download gagal (misal link mati), kembalikan kreditnya
        cursor.execute("UPDATE users SET credits = credits + 3 WHERE username = ?", (username,))
        conn.commit()
        return {"error": str(e)}
    
    
@app.get("/api/tools/tiktok")
async def tiktok_tool(url: str):
    log_activity("TikTok Downloader")
    # Menggunakan API V1 sesuai yang kamu kirim
    api_url = f"https://api.vreden.my.id/api/v1/download/tiktok?url={url}"
    response = requests.get(api_url)
    return response.json()

@app.get("/api/tools/youtube")
async def youtube_downloader(url: str):
    log_activity("YouTube Downloader")
    try:
        api_url = f"https://api.vreden.my.id/api/v1/download/youtube/video?url={url}&quality=720"
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0"}
        
        response = requests.get(api_url, headers=headers, timeout=40)
        res_json = response.json()

        if res_json.get("status") == True:
            result = res_json.get("result", {})
            metadata = result.get("metadata", {})
            download_info = result.get("download", {})

            # LOGIKA BARU: Cek apakah bisa didownload atau error konversi
            is_downloadable = download_info.get("status") == True
            video_url = download_info.get("url", "") if is_downloadable else ""
            download_msg = "" if is_downloadable else download_info.get("message", "Video dilindungi / gagal dikonversi")

            # Format angka Views agar cantik (misal: 247.273.837)
            views_raw = metadata.get("views", 0)
            views_formatted = f"{views_raw:,}".replace(",", ".") if views_raw else "0"

            return {
                "status": "success",
                "title": metadata.get("title", "YouTube Video"),
                "author": metadata.get("author", {}).get("name", "Creator"),
                "video_url": video_url, 
                "cover": metadata.get("thumbnail", ""),
                "duration": metadata.get("timestamp", "00:00"),
                "views": f"{views_formatted} Views",
                "download_error": download_msg
            }
        else:
            return {"status": "error", "message": "Gagal mengambil data dari API Vreden."}
            
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.get("/api/tools/ig")
async def ig_downloader(url: str):
    log_activity("Instagram Downloader")
    try:
        api_url = f"https://api.vreden.my.id/api/v1/download/instagram?url={url}"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0"
        }
        
        response = requests.get(api_url, headers=headers, timeout=30)
        res_json = response.json()

        if res_json.get("status") == True:
            result = res_json.get("result", {})
            
            # 1. Ambil Caption untuk dijadikan Judul (Potong jika kepanjangan)
            caption_text = result.get("caption", {}).get("text", "Instagram Post")
            title = caption_text[:60] + "..." if len(caption_text) > 60 else caption_text
            
            # 2. Ambil Username
            author = result.get("profile", {}).get("username", "ig_user")
            
            # 3. Ambil Data Media (Array)
            media_data = result.get("data", [])
            if not media_data:
                return {"status": "error", "message": "Media tidak ditemukan atau akun di-private."}
            
            # Kita ambil media pertama dari postingan tersebut
            first_media = media_data[0]

            return {
                "status": "success",
                "title": title,
                "author": f"@{author}",
                "video_url": first_media.get("url", ""), 
                "cover": first_media.get("thumb", "")
            }
        else:
            return {"status": "error", "message": "Gagal mengambil data IG dari server."}
            
    except Exception as e:
        print(f"ERROR IG: {str(e)}")
        return {"status": "error", "message": str(e)}

@app.get("/api/tools/threads")
async def threads_downloader(url: str):
    log_activity("Threads Downloader")
    try:
        api_url = f"https://api.vreden.my.id/api/v1/download/threads?url={url}"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0"
        }
        
        response = requests.get(api_url, headers=headers, timeout=30)
        res_json = response.json()

        if res_json.get("status") == True:
            result = res_json.get("result", {})
            media_list = result.get("media", [])
            
            if not media_list:
                return {"status": "error", "message": "Media tidak ditemukan pada link ini."}
            
            # Kita ambil media pertama dari post Threads tersebut
            first_media = media_list[0]

            return {
                "status": "success",
                "title": "Threads Post", # API Vreden tidak memberikan teks caption
                "author": "Threads User", # API Vreden tidak memberikan nama user
                "video_url": first_media.get("url", ""), 
                "cover": first_media.get("thumb", "")
            }
        else:
            return {"status": "error", "message": "Gagal mengambil data Threads dari server."}
            
    except Exception as e:
        print(f"ERROR THREADS: {str(e)}")
        return {"status": "error", "message": str(e)}

@app.get("/api/tools/animagine")
async def generate_image(
    prompt: str,
    username: str = Depends(get_credit_checker(5)) # <--- Biaya 5 kredit
):
    log_activity(f"Animagine AI oleh {username}")
    try:
        # Panggil API Vreden
        api_url = f"https://api.vreden.my.id/api/v1/artificial/animagine?prompt={prompt}"
        headers = {"User-Agent": "Mozilla/5.0"}
        
        # Timeout 60 detik karena AI butuh waktu untuk "menggambar"
        response = requests.get(api_url, headers=headers, timeout=60)
        res_json = response.json()

        if res_json.get("status") == True:
            result = res_json.get("result", {})
            image_data = result.get("image", {})
            
            return {
                "status": "success",
                "image_url": image_data.get("results", ""),
                "prompt_used": result.get("prompt", ""),
                "resolution": result.get("resolution", ""),
                "model": result.get("model", {}).get("name", "Animagine XL")
            }
        else:
            # REFUND: Jika API luar gagal memberikan gambar, kembalikan kredit user
            cursor.execute("UPDATE users SET credits = credits + 5 WHERE username = ?", (username,))
            conn.commit()
            return {"status": "error", "message": "Gagal generate gambar dari server AI."}
            
    except Exception as e:
        # REFUND: Jika terjadi error koneksi atau timeout, kembalikan kredit user
        cursor.execute("UPDATE users SET credits = credits + 5 WHERE username = ?", (username,))
        conn.commit()
        print(f"ERROR ANIMAGINE: {str(e)}")
        return {"status": "error", "message": f"Koneksi terputus: {str(e)}"}
    
@app.get("/api/tools/deepai")
async def generate_image_deepai(
    prompt: str, 
    shape: str = "square", 
    model: str = "future-architecture-generator",
    # TAMBAHKAN INI: Potong 5 kredit di awal
    username: str = Depends(get_credit_checker(5)) 
):
    # Sekarang log_activity bisa mencatat siapa yang menggunakan
    log_activity(f"DeepAI Art oleh {username}: {prompt[:20]}...")
    
    try:
        api_url = f"https://api.vreden.my.id/api/v1/artificial/deepai/text2img?prompt={prompt}&shape={shape}&model={model}"
        headers = {"User-Agent": "Mozilla/5.0"}
        
        response = requests.get(api_url, headers=headers, timeout=60)
        res_json = response.json()

        if res_json.get("status") == True:
            result = res_json.get("result", {})
            image_url = result.get("output_url", "")
            
            if not image_url:
                # OPTIONAL: Kembalikan kredit jika gambar gagal dibuat
                # cursor.execute("UPDATE users SET credits = credits + 5 WHERE username = ?", (username,))
                # conn.commit()
                return {"status": "error", "message": "Server DeepAI sibuk, gambar gagal dibuat."}

            return {
                "status": "success",
                "image_url": image_url,
                "prompt_used": prompt,
                "model": model,
                "shape": shape
            }
        else:
            # OPTIONAL: Refund kredit jika gagal dari sisi server API
            # cursor.execute("UPDATE users SET credits = credits + 5 WHERE username = ?", (username,))
            # conn.commit()
            return {"status": "error", "message": "Gagal generate gambar dari server DeepAI."}
            
    except Exception as e:
        print(f"ERROR DEEPAI: {str(e)}")
        # OPTIONAL: Refund kredit jika terjadi crash/error koneksi
        # cursor.execute("UPDATE users SET credits = credits + 5 WHERE username = ?", (username,))
        # conn.commit()
        return {"status": "error", "message": f"Terjadi kesalahan: {str(e)}"}
    
@app.get("/api/tools/screenshot")
async def web_screenshot(
    url: str, 
    type: str = "phone",
    username: str = Depends(get_credit_checker(2)) # <--- Biaya 2 kredit
):
    log_activity(f"Web Screenshot oleh {username}")
    try:
        # Pastikan user memasukkan http/https
        if not url.startswith("http"):
            url = "https://" + url
            
        api_url = f"https://api.vreden.my.id/api/v1/tools/screenshot?url={url}&type={type}"
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0"}
        
        response = requests.get(api_url, headers=headers, stream=True, timeout=30)
        
        # Cek apakah API memberikan respon sukses (gambar)
        if response.status_code == 200:
            return StreamingResponse(
                response.iter_content(chunk_size=4096), 
                media_type=response.headers.get("Content-Type", "image/png")
            )
        else:
            # REFUND: Jika API Vreden gagal mengambil screenshot
            cursor.execute("UPDATE users SET credits = credits + 2 WHERE username = ?", (username,))
            conn.commit()
            return {"error": "Gagal mengambil screenshot dari server luar."}
            
    except Exception as e:
        # REFUND: Jika terjadi error koneksi atau timeout
        cursor.execute("UPDATE users SET credits = credits + 2 WHERE username = ?", (username,))
        conn.commit()
        print(f"ERROR SCREENSHOT: {str(e)}")
        return {"error": f"Koneksi terputus: {str(e)}"}

@app.post("/api/vqa")
async def visual_question_answering(
    image: UploadFile = File(...), 
    question: str = Form(...),
    # POTONG 2 KREDIT: Harga hemat sesuai permintaan Wilson
    username: str = Depends(get_credit_checker(2)) 
):
    log_activity(f"OmniVision oleh {username}: {question}")
    
    try:
        # Baca file image dari request
        image_data = Image.open(io.BytesIO(await image.read())).convert("RGB")
        
        # Proses menggunakan model ViLT (pindahkan logika dari app.py Wilson)
        inputs = processor(image_data, question, return_tensors="pt")
        
        with torch.no_grad():
            outputs = model_vilt(**inputs) # Gunakan model_vilt yang sudah di-load di atas
            
        idx = outputs.logits.argmax(-1).item()
        answer = model_vilt.config.id2label[idx]
        
        return {"status": "success", "answer": answer}
        
    except Exception as e:
        # Jika sistem error, balikin kreditnya (Refund)
        cursor.execute("UPDATE users SET credits = credits + 2 WHERE username = ?", (username,))
        conn.commit()
        return {"status": "error", "message": str(e)}
    


@app.post("/api/reconstruct")
async def process_reconstruction(
    source: UploadFile = File(...), 
    target: UploadFile = File(...),
    username: str = Depends(get_credit_checker(10))
):
    # 1. Gunakan 'await .read()' untuk FastAPI, bukan request.files
    file1 = await source.read()
    file2 = await target.read()

    img_source = cv2.imdecode(np.frombuffer(file1, np.uint8), cv2.IMREAD_COLOR)
    img_target = cv2.imdecode(np.frombuffer(file2, np.uint8), cv2.IMREAD_COLOR)

    if img_source is None or img_target is None:
        return {"status": "error", "message": "Format gambar tidak didukung"}

    size = 150 
    img_s = cv2.resize(img_source, (size, size))
    img_t = cv2.resize(img_target, (size, size))
    
    img_s = cv2.cvtColor(img_s, cv2.COLOR_BGR2RGB)
    img_t_rgb = cv2.cvtColor(img_t, cv2.COLOR_BGR2RGB)

    # --- PROSES AI DEPTH ESTIMATION (MiDaS) ---
    # Gunakan 'with torch.no_grad()' agar tidak berat di RAM
    input_batch = transform(img_t).to(device)
    with torch.no_grad():
        prediction = midas(input_batch)
        depth_map = torch.nn.functional.interpolate(
            prediction.unsqueeze(1),
            size=(size, size), # Pastikan size sesuai resize kita
            mode="bicubic",
            align_corners=False,
        ).squeeze()
    
    depth_map = depth_map.cpu().numpy()
    depth_min, depth_max = depth_map.min(), depth_map.max()
    depth_map = (depth_map - depth_min) / (depth_max - depth_min) if depth_max > depth_min else depth_map

    # --- MAPPING PIXEL ---
    source_pixels = img_s.reshape(-1, 3)
    source_brightness = np.sum(source_pixels, axis=1)
    source_sorted_indices = np.argsort(source_brightness)
    sorted_source_pixels = source_pixels[source_sorted_indices]

    target_pixels = img_t_rgb.reshape(-1, 3)
    target_brightness = np.sum(target_pixels, axis=1)
    target_sorted_indices = np.argsort(target_brightness)

    pixel_data = [None] * (size * size)
    scale_factor = 0.05 

    for i in range(len(target_sorted_indices)):
        target_idx = target_sorted_indices[i]
        y_coord = target_idx // size
        x_coord = target_idx % size
        
        r, g, b = sorted_source_pixels[i].tolist()
        depth_val = depth_map[y_coord, x_coord]

        pixel_data[target_idx] = {
            "x": float((x_coord - size/2) * scale_factor),
            "y": float(-(y_coord - size/2) * scale_factor),
            "z": float(depth_val * 3.5),
            "r": int(r), "g": int(g), "b": int(b)
        }

    # 2. Kembalikan langsung list/dict, FastAPI otomatis mengubahnya jadi JSON
    log_activity(f"3D Recon oleh {username}")
    return pixel_data


@app.get("/api/stats")
async def get_server_stats():
    cpu_usage = psutil.cpu_percent(interval=0.1)
    ram = psutil.virtual_memory()
    ram_usage = f"{ram.used / (1024**3):.1f} GB"
    
    yolo_status = "Sedang Memproses" if is_ai_active else "Standby"

    return {
        "status": "success",
        "data": {
            "cpu": f"{cpu_usage}%",
            "ram": ram_usage,
            "yolo": yolo_status,
            "network": "Terkoneksi"
        }
    }

@app.delete("/api/users/{user_id}")
async def delete_user(user_id: int):
    try:
        cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
        conn.commit()
        return {"status": "success"}
    except Exception as e:
        return {"status": "error", "message": str(e)}
    
@app.get("/api/admin/trends")
async def get_usage_trends():
    cursor.execute("""
        SELECT date(timestamp) as day, COUNT(*) 
        FROM activity_logs 
        WHERE timestamp >= date('now', '-6 days')
        GROUP BY day 
        ORDER BY day
    """)
    daily_rows = cursor.fetchall()
    
    cursor.execute("""
        SELECT feature, COUNT(*) 
        FROM activity_logs 
        GROUP BY feature
    """)
    feature_rows = cursor.fetchall()

    import datetime
    today = datetime.date.today()
    labels_hari = [(today - datetime.timedelta(days=i)).strftime('%Y-%m-%d') for i in range(6, -1, -1)]
    data_harian_dict = {row[0]: row[1] for row in daily_rows}
    data_harian = [data_harian_dict.get(day, 0) for day in labels_hari]

    labels_fitur = [row[0] for row in feature_rows] if feature_rows else ["Belum ada data"]
    data_fitur = [row[1] for row in feature_rows] if feature_rows else [0]

    return {
        "status": "success",
        "data": {
            "labels_hari": labels_hari,
            "data_harian": data_harian,
            "labels_fitur": labels_fitur,
            "data_fitur": data_fitur
        }
    }


def convert_to_degrees(value):
    try:
        d = float(value[0])
        m = float(value[1])
        s = float(value[2])
        return d + (m / 60.0) + (s / 3600.0)
    except:
        return 0.0

@app.post("/api/metadata")
async def get_image_metadata(
    file: UploadFile = File(...),
    username: str = Depends(get_credit_checker(1))
):
    try:
        contents = await file.read()
        img = Image.open(io.BytesIO(contents))
        exif_data = img._getexif()
        
        if not exif_data:
            return {"status": "warning", "message": "Metadata tidak ditemukan."}

        parsed = {}
        # Loop untuk mengekstrak data
        for tag_id, value in exif_data.items():
            tag = TAGS.get(tag_id, tag_id)
            if tag == "GPSInfo":
                lat_ref = value.get(1)
                lat_val = value.get(2)
                lon_ref = value.get(3)
                lon_val = value.get(4)

                if lat_val and lon_val:
                    lat = convert_to_degrees(lat_val)
                    if lat_ref != 'N': lat = -lat
                    
                    lon = convert_to_degrees(lon_val)
                    if lon_ref != 'E': lon = -lon

                    # Masukkan data ke dalam dictionary 'parsed' agar terbaca di React
                    parsed["lat"] = lat
                    parsed["lon"] = lon
                    parsed["maps_url"] = f"https://www.google.com/maps?q={lat},{lon}"
            
            elif tag in ["Make", "Model", "DateTime"]:
                parsed[tag] = str(value)

        # Mengirim objek parsed yang sudah berisi lat, lon, dan maps_url
        return {"status": "success", "data": parsed}

    except Exception as e:
        return {"status": "error", "message": str(e)}


@app.post("/api/stegano/encode")
async def stegano_encode(
    image: UploadFile = File(...),
    message: str = Form(...),
    username: str = Depends(get_credit_checker(3)) # Biaya 3 kredit
):
    log_activity(f"Stegano Encode oleh {username}")
    try:
        # Baca gambar sebagai array Numpy
        contents = await image.read()
        nparr = np.frombuffer(contents, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

        # Tambahkan "Delimiter" (Tanda Berhenti) agar AI tahu di mana pesan berakhir
        secret_message = message + "#####"
        binary_msg = text_to_binary(secret_message)
        msg_len = len(binary_msg)

        # Ratakan (flatten) array gambar agar mudah diedit bit-nya
        flat_img = img.flatten()
        
        if msg_len > len(flat_img):
            return {"error": "Pesan terlalu panjang untuk ukuran gambar ini!"}

        # Ganti bit paling kecil (LSB) dengan bit pesan kita
        for i in range(msg_len):
            # flat_img[i] & ~1 (menghapus bit terakhir), lalu di-OR dengan bit pesan
            flat_img[i] = (flat_img[i] & ~1) | int(binary_msg[i])

        # Bentuk kembali array menjadi dimensi gambar semula
        encoded_img = flat_img.reshape(img.shape)

        # WAJIB format PNG agar kompresi tidak merusak pesan (Lossless)
        _, buffer = cv2.imencode('.png', encoded_img)
        return Response(content=buffer.tobytes(), media_type="image/png")

    except Exception as e:
        return {"error": f"Gagal menyembunyikan pesan: {str(e)}"}

@app.post("/api/stegano/decode")
async def stegano_decode(
    image: UploadFile = File(...),
    username: str = Depends(get_credit_checker(2)) # Biaya 2 kredit
):
    log_activity(f"Stegano Decode oleh {username}")
    try:
        contents = await image.read()
        nparr = np.frombuffer(contents, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

        flat_img = img.flatten()
        
        # Ekstrak bit terakhir dari setiap piksel
        binary_data = [str(flat_img[i] & 1) for i in range(len(flat_img))]
        all_bits = "".join(binary_data)
        
        # Pecah menjadi blok 8-bit lalu ubah ke karakter ASCII
        decoded_chars = [chr(int(all_bits[i:i+8], 2)) for i in range(0, len(all_bits), 8)]
        full_message = "".join(decoded_chars)

        # Cari Delimiter kita tadi
        if "#####" in full_message:
            secret = full_message.split("#####")[0]
            return {"status": "success", "message": secret}
        else:
            return {"status": "error", "message": "Tidak ada pesan rahasia di gambar ini, atau gambar telah terkompresi."}

    except Exception as e:
        return {"status": "error", "message": "Gagal membaca gambar."}
    
@app.post("/api/crypto/encrypt")
async def encrypt_text(
    message: str = Form(...), 
    key: str = Form(...),
    username: str = Depends(get_credit_checker(1))
):
    try:
        f = Fernet(generate_safe_key(key))
        token = f.encrypt(message.encode())
        return {"status": "success", "result": token.decode()}
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/api/crypto/decrypt")
async def decrypt_text(
    token: str = Form(...), 
    key: str = Form(...),
    username: str = Depends(get_credit_checker(1))
):
    try:
        f = Fernet(generate_safe_key(key))
        decrypted = f.decrypt(token.encode())
        return {"status": "success", "result": decrypted.decode()}
    except Exception:
        return {"status": "error", "message": "Kunci salah atau data korup!"}

@app.put("/api/users/{user_id}/credits")
async def update_user_credits(user_id: int, data: CreditUpdate):
    try:
        cursor.execute("UPDATE users SET credits = ? WHERE id = ?", (data.credits, user_id))
        conn.commit()
        
        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="User tidak ditemukan")
            
        return {"status": "success", "message": f"Kredit berhasil diperbarui"}
    except Exception as e:
        return {"status": "error", "message": str(e)}
    
@app.on_event("shutdown")
def shutdown_event():
    global camera
    if camera is not None:
        camera.release()
    # Matikan MediaPipe saat FastAPI mati
    selfie_seg.close()
    hands.close()

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)