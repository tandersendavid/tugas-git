import React, { useState, useEffect, useRef } from 'react';
import { Send, User, Bot, Loader2, Copy, Check, Menu, Sun, Moon, Mic, Volume2, VolumeX, X, ImageIcon } from 'lucide-react';
import axios from 'axios';
import ReactMarkdown from 'react-markdown';
import './App.css';
import toast, { Toaster } from 'react-hot-toast';
import clickSound from './prabowo.mp3';
import Auth from './components/Auth';

// IMPORT KOMPONEN YANG BARU DIBUAT
import Sidebar from './components/Sidebar';
import NeuralVision from './components/NeuralVision';
import FaceSwap from './components/Faceswap';
import VirtualBackground from './components/VirtualBackground';
import FaceAnalytics from './components/FaceAnalytics';
import GestureControl from './components/GestureControl';
import Upscaler from './components/Upscaler';
import Unblur from './components/Unblur';
import Colorizer from './components/Colorizer';
import BgRemover from './components/BgRemover';
import SocialDownloader from './components/SocialDownloader';
import Animagine from './components/Animagine';
import DeepAI from './components/DeepAI';
import WebScreenshot from './components/WebScreenshot';
import VoiceChanger from './components/VoiceChanger';
import Monochromatic from './components/Monochromatic';
import AdminStats from './components/AdminStats';
import AdminUsers from './components/AdminUsers';
import AdminTrends from './components/AdminTrends';
import LandingPage from './components/LandingPage';
import ReconstructionView from './components/ReconstructionView';
import OmniVision from './components/OmniVision';
import MetadataTracker from './components/MetadataTracker';
import Steganography from './components/Steganography';
import Cryptography from './components/Cryptography';
import WhacAMole from './components/WhacAMole';


// IMPORT STYLES
import { 
  containerStyle, mainStyle, headerStyle, scrollArea, chatContentContainer, 
  msgRowStyle, avatarStyle, bubbleWrapper, roleHeader, copyBtn, loadingBubble, 
  dotStyle, inputSection, inputBox, inputField, sendBtn 
} from './styles/themeStyles';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(!!localStorage.getItem('omni_token'));
  const [activeTab, setActiveTab] = useState('chat');
  const [isSidebarOpen, setIsSidebarOpen] = useState(window.innerWidth > 768);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState(null);
  const [hoveredSessionId, setHoveredSessionId] = useState(null);

  const [isDarkMode, setIsDarkMode] = useState(() => localStorage.getItem('omni_theme') === 'dark');
  const [allSessions, setAllSessions] = useState([]); 
  const [sessionId, setSessionId] = useState(Date.now()); 
  const [chatHistory, setChatHistory] = useState([{ role: 'ai', content: 'Halo! Saya **Omni AI v1.7**. Saya siap menjadi asisten bot Anda!' }]);
  const [selectedImage, setSelectedImage] = useState(null);

  const [isJarvisMode, setIsJarvisMode] = useState(false); // Mode AI Berbicara
  const [isListening, setIsListening] = useState(false); // Indikator Mic menyala

  const [showLanding, setShowLanding] = useState(() => {
    return !localStorage.getItem('omni_token');
  });

  const chatEndRef = useRef(null);

  useEffect(() => {
    const currentUser = localStorage.getItem('omni_user');
    if (!currentUser) return;

    // Gunakan template literal untuk kunci unik
    const savedSessions = localStorage.getItem(`omni_sessions_${currentUser}`);
    if (savedSessions) {
      const parsed = JSON.parse(savedSessions);
      setAllSessions(parsed);
      // Muat sesi terakhir jika ada
      if (parsed.length > 0) {
        setChatHistory(parsed[0].data);
        setSessionId(parsed[0].id);
      }
    }
  }, [isAuthenticated]);

  useEffect(() => {
    const currentUser = localStorage.getItem('omni_user');
    if (!currentUser) return;

    if (allSessions.length > 0) {
      localStorage.setItem(`omni_sessions_${currentUser}`, JSON.stringify(allSessions)); // <--- Simpan per user
    } else {
      localStorage.removeItem(`omni_sessions_${currentUser}`);
    }
  }, [allSessions]);

  useEffect(() => localStorage.setItem('omni_theme', isDarkMode ? 'dark' : 'light'), [isDarkMode]);
  useEffect(() => chatEndRef.current?.scrollIntoView({ behavior: "smooth" }), [chatHistory, isLoading]);

  const theme = {
    bg: isDarkMode ? '#0f172a' : '#ffffff',
    sidebar: isDarkMode ? '#1e293b' : '#f9fafb',
    text: isDarkMode ? '#f8fafc' : '#1f2937',
    subText: isDarkMode ? '#94a3b8' : '#6b7280',
    border: isDarkMode ? '#334155' : '#e5e7eb',
    inputBg: isDarkMode ? '#1e293b' : '#f3f4f6',
    bubbleAi: isDarkMode ? '#1e293b' : '#f3f4f6',
    accent: '#2563eb',
    activeHistory: isDarkMode ? '#334155' : '#e5e7eb',
    visionCard: isDarkMode ? '#1e293b' : '#f3f4f6'
  };

  const copyToClipboard = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const startNewChat = () => {
    setChatHistory([{ role: 'ai', content: 'Sesi baru dimulai. Ada yang bisa saya bantu?' }]);
    setSessionId(Date.now()); 
  };

  const loadSession = (session) => {
    setChatHistory(session.data);
    setSessionId(session.id); 
  };

  const clearAllHistory = () => {
    if (window.confirm("Yakin ingin menghapus semua riwayat percakapan?")) {
      setAllSessions([]);
      startNewChat();
    }
  };
  
  const toggleTheme = () => {
    setIsDarkMode((prev) => !prev); // Ganti state tema
    
    const soundEffect = new Audio(clickSound);
    soundEffect.volume = 0.05; 
    soundEffect.play().catch((err) => console.log("Gagal putar suara:", err));
  };

  const deleteSingleSession = (e, idToDelete) => {
    e.stopPropagation(); 
    const updatedSessions = allSessions.filter(s => s.id !== idToDelete);
    setAllSessions(updatedSessions);
    if (sessionId === idToDelete) {
      updatedSessions.length > 0 ? loadSession(updatedSessions[0]) : startNewChat();
    }
  };

  const generateTitle = async (firstMessage) => {
    try {
      const prompt = `Berikan SATU frasa singkat (2-5 kata) untuk merangkum topik ini: "${firstMessage}". JANGAN gunakan kata pembuka.`;
      const res = await axios.post(
        'https://mtztf49c-8000.asse.devtunnels.ms/api/chat', 
        { message: prompt },
        {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('omni_token')}`
          }
        }
      );
      let title = res.data.reply.replace(/["'*_]/g, '').trim();
      return title.length > 30 ? title.substring(0, 30) + "..." : title;
    } catch (err) { return firstMessage.substring(0, 20) + "..."; }
  };

  const toggleJarvisMode = () => {
    if (isJarvisMode) {
      // Jika Jarvis sedang nyala lalu dimatikan, paksa browser untuk langsung BUNGKAM!
      window.speechSynthesis.cancel();
    }
    setIsJarvisMode(!isJarvisMode);
  };

  const handleSend = async () => {
    // Jangan kirim kalau input kosong DAN tidak ada gambar
    if ((!input.trim() && !selectedImage) || isLoading) return; 

    const currentInput = input;
    const currentImage = selectedImage;

    // Buat objek riwayat chat untuk ditampilkan di UI layar
    const userMsg = { 
      role: 'user', 
      content: currentInput || "Tolong jelaskan gambar ini.", // Teks default jika hanya kirim gambar
      image: currentImage ? URL.createObjectURL(currentImage) : null 
    };
    
    const newHistory = [...chatHistory, userMsg];
    setChatHistory(newHistory);
    
    // Reset kolom chat agar siap dipakai lagi
    setInput('');
    setSelectedImage(null); 
    setIsLoading(true);

    try {
      // PERUBAHAN UTAMA: Gunakan FormData
      const formData = new FormData();
      formData.append('message', currentInput || "Jelaskan isi dari gambar yang saya kirimkan."); 
      if (currentImage) {
        formData.append('image', currentImage);
      }

      const res = await axios.post(
        'https://mtztf49c-8000.asse.devtunnels.ms/api/chat', 
        formData, // Mengirim formData, bukan JSON biasa
        {
          headers: {
            'Content-Type': 'multipart/form-data', // Wajib untuk kirim file
            'Authorization': `Bearer ${localStorage.getItem('omni_token')}`
          }
        }
      );
      
      const aiReply = res.data.reply;
      const aiMsg = { role: 'ai', content: aiReply };
      
      if (isJarvisMode) {
        speakText(aiReply);
      }

      const updatedHistory = [...newHistory, aiMsg];
      setChatHistory(updatedHistory);
      
      const sessionExists = allSessions.find(s => s.id === sessionId);
      if (!sessionExists) {
        const aiTitle = await generateTitle(currentInput || "Analisis Gambar");
        setAllSessions(prev => [{ id: sessionId, title: aiTitle, data: updatedHistory }, ...prev]);
      } else {
        setAllSessions(prev => prev.map(s => s.id === sessionId ? { ...s, data: updatedHistory } : s));
      }
    } catch (err) {
      if (err.response && err.response.status === 403) {
        toast.error("Kredit habis! Jatah harian 50/hari sudah terpakai.");
      } else {
        toast.error("Gagal mendapatkan respon dari server.");
      }
      setChatHistory(prev => [...prev, { role: 'ai', content: '### Koneksi Gagal\nPeriksa Backend.' }]);
    } finally { 
      setIsLoading(false); 
    }
  };

  const handleMicClick = () => {
    // Gunakan pengecekan ganda untuk Chrome Laptop & HP
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
      toast.error("Browser Anda tidak mendukung fitur Mic. Gunakan Google Chrome.");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'id-ID'; 
    recognition.interimResults = false;
    recognition.continuous = false; // Biar otomatis berhenti setelah kamu diam

    recognition.onstart = () => {
      console.log("Mic Aktif...");
      setIsListening(true);
    };

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      console.log("Hasil Suara:", transcript);
      setInput(transcript); // Pastikan nama statenya 'setInput' bukan 'setInputMessage'
    };

    recognition.onerror = (event) => {
      console.error("Kesalahan Mic:", event.error);
      setIsListening(false);
      toast.error("Mic Error: " + event.error + ". Pastikan izin mic sudah diberikan.");
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    try {
      recognition.start();
    } catch (e) {
      console.log("Recognition sudah berjalan");
    }
  };

  // ==========================================
  // FITUR 2: AI MEMBACAKAN BALASAN (SPEAKER)
  // ==========================================
  const speakText = (text) => {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel(); // Hentikan suara sebelumnya jika ada
    
    // Hapus simbol markdown (*, #, `) agar robot tidak membacanya sebagai tanda baca aneh
    const cleanText = text.replace(/[*#_`]/g, ''); 
    
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = 'id-ID';
    utterance.rate = 1.05; // Sedikit dicepatkan agar terdengar lebih pintar
    
    window.speechSynthesis.speak(utterance);
  };
  

  if (showLanding && !isAuthenticated) {
    return <LandingPage onEnter={() => setShowLanding(false)} />;
  }

  // Jika tombol "Masuk ke Portal" ditekan, tampilkan form Login
  if (!isAuthenticated) {
    return <Auth theme={theme} onLoginSuccess={() => setIsAuthenticated(true)} />;
  }

  const handleLogout = () => {
    if (window.confirm("Yakin ingin keluar dari Omni AI?")) {
      localStorage.removeItem('omni_token');
      localStorage.removeItem('omni_user');
      localStorage.removeItem('omni_role');

      setAllSessions([]); 
      setChatHistory([{ role: 'ai', content: 'Halo! Silakan login untuk memulai.' }]);
      
      setIsAuthenticated(false);
      setActiveTab('chat');
    }
  };

  const currentUsername = localStorage.getItem('omni_user') || 'User';

  return (
    <div className="omni-container" style={{ ...containerStyle, backgroundColor: theme.bg, color: theme.text }}>
      
      {/* SIDEBAR COMPONENT */}
      <Sidebar 
        theme={theme}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        allSessions={allSessions}
        sessionId={sessionId}
        startNewChat={startNewChat}
        loadSession={loadSession}
        clearAllHistory={clearAllHistory}
        deleteSingleSession={deleteSingleSession}
        hoveredSessionId={hoveredSessionId}
        setHoveredSessionId={setHoveredSessionId}
        isDarkMode={isDarkMode}
        setIsDarkMode={toggleTheme}
        isSidebarOpen={isSidebarOpen}
        setIsSidebarOpen={setIsSidebarOpen}
        handleLogout={handleLogout}
        username={currentUsername}
      />

      {isSidebarOpen && <div className="mobile-overlay" onClick={() => setIsSidebarOpen(false)}></div>}

      {/* MAIN SECTION */}
      <main className="omni-main" style={mainStyle}>
        <header className="omni-header" style={{ ...headerStyle, borderBottom: `1px solid ${theme.border}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>

          {/* Kiri: Hamburger & Judul */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
            <button 
              className="hamburger-btn" 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              style={{ 
                background: 'none', 
                border: 'none', 
                color: theme.text, 
                cursor: 'pointer', 
                padding: 0,
                transition: 'transform 1.5s ease',
                transform: isSidebarOpen ? 'rotate(90deg)' : 'rotate(0deg)'
              }}
            >
              {isSidebarOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
            <h2 style={{ fontSize: '12px', fontWeight: '600', color: theme.subText, margin: 0 }}>Omni NODE v1.7</h2>
          </div>

          {/* Kanan: Tombol Dark Mode (Khusus Layar HP) */}
          <button className="mobile-dark-btn" onClick={toggleTheme} style={{ background: 'none', border: 'none', color: theme.text, cursor: 'pointer', padding: 0, display: 'flex', alignItems: 'center' }}>
            {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>

        </header>

        {/* TAB CHAT */}
        {activeTab === 'chat' && (
          <>
            <div style={scrollArea}>
              <div style={chatContentContainer}>
                {chatHistory.map((msg, i) => (
                  <div key={i} style={msgRowStyle(msg.role)}>
                    <div style={avatarStyle(msg.role, theme)}><Bot size={16}/></div>
                    <div style={bubbleWrapper(msg.role)}>
                      <div style={roleHeader(msg.role, theme)}>
                        <span>{msg.role === 'user' ? 'ANDA' : 'OMNI AI'}</span>
                        {msg.role === 'ai' && <button onClick={() => copyToClipboard(msg.content, i)} style={copyBtn}>{copiedId === i ? <Check size={14} color="#10b981"/> : <Copy size={14} color={theme.subText}/>}</button>}
                      </div>
                      <div style={{ fontSize: '15px', lineHeight: '1.6', color: theme.text }}>
                        {/* Render gambar jika msg punya properti image */}
                        {msg.image && (
                          <img 
                            src={msg.image} 
                            alt="User Upload" 
                            style={{ maxWidth: '250px', borderRadius: '8px', marginBottom: '10px', display: 'block' }} 
                          />
                        )}
                        <ReactMarkdown>{msg.content}</ReactMarkdown>
                      </div>
                    </div>
                  </div>
                ))}
                {isLoading && ( <div style={msgRowStyle('ai')}><div style={avatarStyle('ai', theme)}><Bot size={16}/></div><div style={bubbleWrapper('ai')}><div style={loadingBubble(theme)}><div style={dotStyle(theme)}/><div style={{...dotStyle(theme), animationDelay: '0.2s'}}/><div style={{...dotStyle(theme), animationDelay: '0.4s'}}/></div></div></div> )}
                <div ref={chatEndRef} style={{ height: '50px' }} />
              </div>
            </div>

            <div className="omni-input-section" style={{ ...inputSection, borderTop: `1px solid ${theme.border}`, backgroundColor: theme.bg }}>
  
            {/* PREVIEW GAMBAR SEBELUM DIKIRIM (Muncul di atas kolom teks) */}
              {selectedImage && (
                <div style={{ padding: '10px 15px', borderBottom: `1px solid ${theme.border}` }}>
                  <div style={{ position: 'relative', display: 'inline-block' }}>
                    <img 
                      src={URL.createObjectURL(selectedImage)} 
                      alt="preview" 
                      style={{ height: '60px', borderRadius: '8px', border: `2px solid ${theme.accent}` }} 
                    />
                    <button 
                      onClick={() => setSelectedImage(null)}
                      style={{ position: 'absolute', top: '-8px', right: '-8px', background: '#ef4444', color: 'white', borderRadius: '50%', border: 'none', cursor: 'pointer', padding: '3px' }}
                    >
                      <X size={12} />
                    </button>
                  </div>
                </div>
              )}

              <div style={{ ...inputBox(isLoading, theme), display: 'flex', alignItems: 'center', gap: '8px', padding: '0 15px' }}>
                
                {/* 1. TOMBOL TOGGLE JARVIS (AUTO-SPEAK) */}
                <button 
                  onClick={toggleJarvisMode}
                  style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', padding: '5px', color: isJarvisMode ? '#10b981' : theme.subText, transition: '0.2s' }}
                  title={isJarvisMode ? "Mode Jarvis: Aktif" : "Mode Jarvis: Mati"}
                >
                  {isJarvisMode ? <Volume2 size={20} /> : <VolumeX size={20} />}
                </button>

                {/* TOMBOL UPLOAD GAMBAR BARU */}
                <input
                  type="file"
                  id="chat-image-upload"
                  accept="image/*"
                  style={{ display: 'none' }}
                  onChange={(e) => {
                    if(e.target.files && e.target.files[0]) setSelectedImage(e.target.files[0]);
                  }}
                />
                <label htmlFor="chat-image-upload" style={{ cursor: 'pointer', color: selectedImage ? theme.accent : theme.subText, display: 'flex', alignItems: 'center', padding: '5px' }}>
                  <ImageIcon size={20} />
                </label>

                {/* 2. KOLOM INPUT TEKS */}
                <input 
                  value={input} 
                  onChange={(e) => setInput(e.target.value)} 
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()} 
                  placeholder={isListening ? "Mendengarkan..." : (selectedImage ? "Ketik prompt gambar..." : "Tulis pesan...")} 
                  style={{ ...inputField, color: theme.text, flex: 1, border: 'none', outline: 'none', backgroundColor: 'transparent' }} 
                  disabled={isLoading} 
                />

                {/* 3. TOMBOL MIC (SPEECH TO TEXT) */}
                <button 
                  onClick={handleMicClick}
                  style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', padding: '5px', color: isListening ? '#ef4444' : theme.subText, transition: '0.2s' }}
                  disabled={isLoading}
                  title="Bicara dengan Mic"
                >
                  <Mic size={20} className={isListening ? "animate-pulse" : ""} />
                </button>

                {/* 4. TOMBOL SEND */}
                <button 
                  onClick={handleSend} 
                  style={{ ...sendBtn(isLoading, theme), minWidth: '40px', height: '40px', borderRadius: '10px', display: 'flex', justifyContent: 'center', alignItems: 'center' }} 
                  disabled={isLoading}
                > 
                  {isLoading ? <Loader2 size={18} className="animate-spin" color={theme.subText}/> : <Send size={18} color="white" />} 
                </button>

              </div>
          </div>
          </>
        )}

        {/* TAB VISION COMPONENT */}
        {activeTab === 'vision' && <NeuralVision theme={theme} />}
        {activeTab === 'swap' && <FaceSwap theme={theme} />}
        {activeTab === 'vb' && <VirtualBackground theme={theme} />}
        {activeTab === 'analytics' && <FaceAnalytics theme={theme} />}
        {activeTab === 'gesture' && <GestureControl theme={theme} />}
        {activeTab === 'upscale' && <Upscaler theme={theme} />}
        {activeTab === 'unblur' && <Unblur theme={theme} />}
        {activeTab === 'colorizer' && <Colorizer theme={theme} />}
        {activeTab === 'bgremover' && <BgRemover theme={theme} />}
        {activeTab === 'monochrome' && <Monochromatic theme={theme} />}
        {activeTab === 'animagine' && <Animagine theme={theme} />}
        {activeTab === 'deepai' && <DeepAI theme={theme} />}
        {activeTab === 'webscreenshot' && <WebScreenshot theme={theme} />}
        {activeTab === 'voicechanger' && <VoiceChanger theme={theme} />}
        {activeTab === 'reconstruction' && <ReconstructionView theme={theme} />}
        {activeTab === 'omni_vision' && <OmniVision theme={theme} />}
        {activeTab === 'metadata' && <MetadataTracker theme={theme} />}
        {activeTab === 'steganography' && <Steganography theme={theme} />}
        {activeTab === 'cryptography' && <Cryptography theme={theme} />}
        {activeTab === 'whac_a_mole' && <WhacAMole theme={theme} />}


        {activeTab === 'tiktok' && <SocialDownloader theme={theme} type="tiktok" />}
        {activeTab === 'youtube' && <SocialDownloader theme={theme} type="youtube" />}
        {activeTab === 'instagram' && <SocialDownloader theme={theme} type="instagram" />}
        {activeTab === 'threads' && <SocialDownloader theme={theme} type="threads" />}

        {activeTab === 'admin_stats' && <AdminStats theme={theme} />}
        {activeTab === 'admin_users' && <AdminUsers theme={theme} />}
        {activeTab === 'admin_trends' && <AdminTrends theme={theme} />}


          </main>
          <Toaster position="top-center" reverseOrder={false} />
            </div>
  );
}

export default App;