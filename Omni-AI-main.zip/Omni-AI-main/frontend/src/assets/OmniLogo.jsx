import React from 'react';

const OmniLogo = ({ className = "w-16 h-16" }) => {
  return (
    <svg 
      viewBox="0 0 100 100" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg" 
      className={className}
    >
      <circle 
        cx="50" 
        cy="50" 
        r="40" 
        stroke="url(#grad1)" 
        strokeWidth="7" 
        strokeDasharray="190 61" 
        strokeLinecap="round" 
        transform="rotate(130 50 50)" 
      />
      
      <circle 
        cx="50" 
        cy="50" 
        r="24" 
        stroke="url(#grad2)" 
        strokeWidth="6" 
        strokeDasharray="90 60" 
        strokeLinecap="round" 
        transform="rotate(-45 50 50)" 
      />
      
      <circle 
        cx="50" 
        cy="50" 
        r="10" 
        fill="url(#grad1)" 
      />
      
      <defs>
        <linearGradient 
          id="grad1" 
          x1="0" 
          y1="0" 
          x2="100" 
          y2="100" 
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#06b6d4" />
          <stop offset="1" stopColor="#3b82f6" />
        </linearGradient>
        
        <linearGradient 
          id="grad2" 
          x1="100" 
          y1="0" 
          x2="0" 
          y2="100" 
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#3b82f6" />
          <stop offset="1" stopColor="#0891b2" />
        </linearGradient>
      </defs>
    </svg>
  );
};

export default OmniLogo;