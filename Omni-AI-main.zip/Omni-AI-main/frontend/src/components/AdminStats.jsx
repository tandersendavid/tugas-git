import React, { useState, useEffect } from 'react';
import { Activity, Cpu, Database, Network } from 'lucide-react';
import axios from 'axios';

function AdminStats({ theme }) {
  const [stats, setStats] = useState({
    cpu: 'Loading...',
    ram: 'Loading...',
    yolo: 'Loading...',
    network: 'Loading...'
  });

  useEffect(() => {
    fetchStats();
    const interval = setInterval(fetchStats, 3000);
    return () => clearInterval(interval);
  }, []);

  const fetchStats = async () => {
    try {
      const response = await axios.get('https://mtztf49c-8000.asse.devtunnels.ms/api/stats');
      if (response.data.status === 'success') {
        setStats(response.data.data);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const statCard = {
    backgroundColor: theme.visionCard,
    border: `1px solid ${theme.border}`,
    borderRadius: '15px',
    padding: '20px',
    display: 'flex',
    flexDirection: 'column',
    gap: '10px'
  };

  return (
    <div style={{ padding: '30px', color: theme.text, overflowY: 'auto', height: '100%' }}>
      <h2 style={{ fontSize: '28px', marginBottom: '20px' }}>Statistik Server Omni</h2>
      
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '20px' }}>
        
        <div style={statCard}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ color: theme.subText, fontSize: '14px' }}>Status YOLOv8</span>
            <Activity size={20} color="#10b981" />
          </div>
          <span style={{ fontSize: '24px' }}>{stats.yolo}</span>
        </div>

        <div style={statCard}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ color: theme.subText, fontSize: '14px' }}>Beban CPU</span>
            <Cpu size={20} color="#0ea5e9" />
          </div>
          <span style={{ fontSize: '24px' }}>{stats.cpu}</span>
        </div>

        <div style={statCard}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ color: theme.subText, fontSize: '14px' }}>Penggunaan RAM</span>
            <Database size={20} color="#f59e0b" />
          </div>
          <span style={{ fontSize: '24px' }}>{stats.ram}</span>
        </div>

        <div style={statCard}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ color: theme.subText, fontSize: '14px' }}>Koneksi Jaringan</span>
            <Network size={20} color="#8b5cf6" />
          </div>
          <span style={{ fontSize: '24px' }}>{stats.network}</span>
        </div>

      </div>
    </div>
  );
}

export default AdminStats;