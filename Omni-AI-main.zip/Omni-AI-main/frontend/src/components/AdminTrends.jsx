import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Line, Doughnut } from 'react-chartjs-2';
import { BarChart3 } from 'lucide-react';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

function AdminTrends({ theme }) {
  const [trendData, setTrendData] = useState(null);

  useEffect(() => {
    fetchTrends();
  }, []);

  const fetchTrends = async () => {
    try {
      const response = await axios.get('https://mtztf49c-8000.asse.devtunnels.ms/api/admin/trends');
      if (response.data.status === 'success') {
        setTrendData(response.data.data);
      }
    } catch (error) {
      console.error(error);
    }
  };

  if (!trendData) {
    return <div style={{ padding: '30px', color: theme.text }}>Memuat data visualisasi...</div>;
  }

  const lineChartData = {
    labels: trendData.labels_hari,
    datasets: [
      {
        label: 'Total Interaksi Harian',
        data: trendData.data_harian,
        borderColor: theme.accent,
        backgroundColor: theme.accent + '80',
        tension: 0.4,
      },
    ],
  };

  const doughnutChartData = {
    labels: trendData.labels_fitur,
    datasets: [
      {
        data: trendData.data_fitur,
        backgroundColor: [
          '#3b82f6', // Blue
          '#10b981', // Emerald
          '#f59e0b', // Amber
          '#8b5cf6', // Violet
          '#ec4899', // Pink
          '#ef4444', // Red
          '#06b6d4', // Cyan
          '#f97316', // Orange
          '#14b8a6', // Teal
          '#6366f1', // Indigo
          '#84cc16', // Lime
          '#a855f7', // Purple
          '#d946ef', // Fuchsia
          '#0ea5e9', // Sky
          '#22c55e', // Green
        ],
        hoverOffset: 40,
        borderColor: theme.visionCard,
        borderWidth: 2,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        labels: { color: theme.text },
      },
    },
    scales: {
      x: {
        ticks: { color: theme.subText },
        grid: { color: theme.border },
      },
      y: {
        ticks: { color: theme.subText },
        grid: { color: theme.border },
      },
    },
  };

  const doughnutOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'right',
        labels: { color: theme.text },
      },
    },
  };

  return (
    <div style={{ padding: '30px', color: theme.text, overflowY: 'auto', height: '100%' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '15px', marginBottom: '30px' }}>
        <BarChart3 size={28} color={theme.accent} />
        <h2 style={{ fontSize: '28px', margin: 0, fontWeight: 'normal' }}>Visualisasi Tren Penggunaan</h2>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '20px' }}>
        
        <div style={{ backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`, borderRadius: '15px', padding: '20px', height: '350px', display: 'flex', flexDirection: 'column' }}>
          <h3 style={{ margin: '0 0 20px 0', fontWeight: 'normal', fontSize: '16px', color: theme.subText }}>Aktivitas Pengguna 7 Hari Terakhir</h3>
          <div style={{ flex: 1, position: 'relative' }}>
            <Line data={lineChartData} options={chartOptions} />
          </div>
        </div>

        <div style={{ backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`, borderRadius: '15px', padding: '20px', height: '350px', display: 'flex', flexDirection: 'column' }}>
          <h3 style={{ margin: '0 0 20px 0', fontWeight: 'normal', fontSize: '16px', color: theme.subText }}>Distribusi Penggunaan Fitur AI</h3>
          <div style={{ flex: 1, position: 'relative' }}>
            <Doughnut data={doughnutChartData} options={doughnutOptions} />
          </div>
        </div>

      </div>
    </div>
  );
}

export default AdminTrends;