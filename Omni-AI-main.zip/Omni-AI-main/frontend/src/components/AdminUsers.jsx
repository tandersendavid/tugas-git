import React, { useState, useEffect } from 'react';
import { Users, Trash2, Coins, Save } from 'lucide-react';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';

function AdminUsers({ theme }) {
  const [users, setUsers] = useState([]);
  const [editingCredits, setEditingCredits] = useState({}); // State untuk menampung input kredit sementara

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await axios.get('https://mtztf49c-8000.asse.devtunnels.ms/api/users');
      if (response.data.status === 'success') {
        setUsers(response.data.data);
      }
    } catch (error) {
      console.error(error);
      toast.error("Gagal mengambil data pengguna");
    }
  };

  // Fungsi untuk update kredit ke database
  const handleUpdateCredits = async (id, username) => {
    const newCredits = editingCredits[id];
    
    if (newCredits === undefined) return; // Jika tidak ada perubahan, jangan kirim

    try {
      const response = await axios.put(`https://mtztf49c-8000.asse.devtunnels.ms/api/users/${id}/credits`, {
        credits: parseInt(newCredits)
      });

      if (response.data.status === 'success') {
        toast.success(`Kredit ${username} berhasil diperbarui!`);
        fetchUsers(); // Refresh data
      } else {
        toast.error(response.data.message);
      }
    } catch (error) {
      console.error(error);
      toast.error("Gagal memperbarui kredit");
    }
  };

  const handleDeleteUser = async (id, username) => {
    if (window.confirm(`Yakin ingin menghapus akun ${username}?`)) {
      try {
        const response = await axios.delete(`https://mtztf49c-8000.asse.devtunnels.ms/api/users/${id}`);
        if (response.data.status === 'success') {
          toast.success("User berhasil dihapus");
          setUsers(users.filter(user => user.id !== id));
        } else {
          toast.error(response.data.message);
        }
      } catch (error) {
        console.error(error);
      }
    }
  };

  return (
    <div style={{ padding: '30px', color: theme.text, overflowY: 'auto', height: '100%' }}>
      <Toaster />
      <div style={{ display: 'flex', alignItems: 'center', gap: '15px', marginBottom: '30px' }}>
        <Users size={28} color={theme.accent} />
        <h2 style={{ fontSize: '28px', margin: 0 }}>Manajemen Pengguna</h2>
      </div>

      <div style={{ backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`, borderRadius: '15px', overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
          <thead>
            <tr style={{ backgroundColor: theme.sidebar, borderBottom: `1px solid ${theme.border}` }}>
              <th style={{ padding: '15px', color: theme.subText, fontWeight: 'normal' }}>ID</th>
              <th style={{ padding: '15px', color: theme.subText, fontWeight: 'normal' }}>Username</th>
              <th style={{ padding: '15px', color: theme.subText, fontWeight: 'normal' }}>Peran</th>
              <th style={{ padding: '15px', color: theme.subText, fontWeight: 'normal' }}>Kredit</th>
              <th style={{ padding: '15px', color: theme.subText, fontWeight: 'normal', textAlign: 'right' }}>Aksi</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id} style={{ borderBottom: `1px solid ${theme.border}` }}>
                <td style={{ padding: '15px' }}>{user.id}</td>
                <td style={{ padding: '15px' }}>{user.username}</td>
                <td style={{ padding: '15px' }}>
                  {user.role === 'admin' ? (
                    <span style={{ backgroundColor: '#06b6d420', color: '#06b6d4', padding: '5px 10px', borderRadius: '20px', fontSize: '12px' }}>Admin</span>
                  ) : (
                    <span style={{ backgroundColor: '#64748b20', color: '#94a3b8', padding: '5px 10px', borderRadius: '20px', fontSize: '12px' }}>User</span>
                  )}
                </td>
                
                {/* KOLOM KREDIT BARU */}
                <td style={{ padding: '15px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <input 
                      type="number"
                      defaultValue={user.credits}
                      onChange={(e) => setEditingCredits({ ...editingCredits, [user.id]: e.target.value })}
                      style={{
                        width: '70px',
                        backgroundColor: 'transparent',
                        border: `1px solid ${theme.border}`,
                        color: theme.text,
                        borderRadius: '5px',
                        padding: '5px'
                      }}
                    />
                    <button 
                      onClick={() => handleUpdateCredits(user.id, user.username)}
                      style={{ background: 'none', border: 'none', cursor: 'pointer' }}
                    >
                      <Save size={16} color={theme.accent} />
                    </button>
                  </div>
                </td>

                <td style={{ padding: '15px', textAlign: 'right' }}>
                  <button 
                    onClick={() => handleDeleteUser(user.id, user.username)}
                    disabled={user.role === 'admin'}
                    style={{ background: 'none', border: 'none', cursor: user.role === 'admin' ? 'not-allowed' : 'pointer', opacity: user.role === 'admin' ? 0.5 : 1 }}
                  >
                    <Trash2 size={18} color="#ef4444" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default AdminUsers;