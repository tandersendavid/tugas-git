import React, { useState } from 'react';
import { Sparkles, Loader2, Image as ImageIcon, Download, Settings } from 'lucide-react';
import axios from 'axios';
import { scrollArea, visionCard, visionCardHeader, actionBtn } from '../styles/themeStyles';
import toast, { Toaster } from 'react-hot-toast';

function Animagine({ theme }) {
  const [prompt, setPrompt] = useState('');
  const [data, setData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const API_BASE = "https://mtztf49c-8000.asse.devtunnels.ms"; 

  const handleGenerate = async () => {
    if (!prompt) return;
    setIsLoading(true);
    setData(null);

    try {
      // PENAMBAHAN TOKEN PADA AXIOS GET
      const response = await axios.get(
        `${API_BASE}/api/tools/animagine?prompt=${encodeURIComponent(prompt)}`,
        {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('omni_token')}`
          }
        }
      );
      
      if (response.data.status === 'success') {
        setData(response.data);
      } else {
        toast.error("Gagal memproses gambar. Coba prompt lain atau tunggu sebentar.");
      }
    } catch (error) {
      console.error(error);
      
      // LOGIKA PENANGANAN ERROR KREDIT HABIS
      if (error.response && error.response.status === 403) {
        toast.error("Kredit habis! Jatah 50/hari sudah terpakai.");
      } else {
        toast.error("Gagal terhubung ke Backend AI.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={scrollArea}>
      <div style={{ maxWidth: '800px', margin: '0 auto', padding: '30px' }}>
        <div style={{...visionCard, backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`}}>
          
          <div style={visionCardHeader}>
            <Sparkles size={24} color={theme.accent}/>
            <div>
              <h3 style={{fontSize: '18px', margin: 0, color: theme.text}}>Anime AI Generator</h3>
              <p style={{fontSize: '13px', color: theme.subText, margin: '2px 0 0 0'}}>Powered by Animagine XL 3.1</p>
            </div>
          </div>

          <div style={{ padding: '20px 0', display: 'flex', flexDirection: 'column', gap: '15px' }}>
            <textarea 
              placeholder="Deskripsikan gambar yang ingin kamu buat dalam bahasa Inggris..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={3}
              style={{
                width: '100%', padding: '15px', borderRadius: '10px',
                border: `2px solid ${theme.border}`, backgroundColor: theme.bg,
                color: theme.text, outline: 'none', fontSize: '14px', resize: 'vertical'
              }}
            />

            <button 
              onClick={handleGenerate}
              disabled={isLoading || !prompt}
              style={{
                ...actionBtn(false, theme), backgroundColor: theme.accent,
                width: '100%', padding: '12px', opacity: (isLoading || !prompt) ? 0.6 : 1,
                cursor: (isLoading || !prompt) ? 'not-allowed' : 'pointer',
                display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '10px',
                fontWeight: 'bold', fontSize: '15px'
              }}
            >
              {isLoading ? (
                <>
                  <Loader2 className="animate-spin" size={20} /> 
                  <span>AI Sedang Menggambar (Mungkin butuh 10-30 detik)...</span>
                </>
              ) : (
                <>
                  <ImageIcon size={20} /> 
                  <span>Generate Gambar (5 Kredit)</span>
                </>
              )}
            </button>
          </div>

          {data && (
            <div style={{ 
              marginTop: '10px', padding: '20px', borderRadius: '12px', 
              backgroundColor: theme.bg, border: `1px solid ${theme.border}`,
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '20px', 
              animation: 'fadeIn 0.5s ease'
            }}>
              
              <img 
                src={data.image_url} 
                alt="Generated AI Art"
                style={{ width: '100%', maxHeight: '500px', objectFit: 'contain', borderRadius: '8px', boxShadow: '0 4px 15px rgba(0,0,0,0.2)' }} 
              />
              
              <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', fontSize: '13px', color: theme.subText }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: '5px', backgroundColor: theme.border, padding: '5px 10px', borderRadius: '5px' }}>
                    <Settings size={14} /> {data.model}
                  </span>
                  <span style={{ display: 'flex', alignItems: 'center', gap: '5px', backgroundColor: theme.border, padding: '5px 10px', borderRadius: '5px' }}>
                    <ImageIcon size={14} /> {data.resolution}
                  </span>
                </div>

                {/* PROXY DOWNLOAD JUGA BUTUH TOKEN (3 Kredit) */}
                <a 
                  href={`${API_BASE}/api/proxy/download?url=${encodeURIComponent(data.image_url)}&token=${localStorage.getItem('omni_token')}`}
                  style={{
                    ...actionBtn(false, theme), textDecoration: 'none', display: 'flex', justifyContent: 'center', gap: '8px',
                    backgroundColor: '#10b981', color: 'white', padding: '12px 20px', fontWeight: 'bold', width: '100%', marginTop: '10px'
                  }}
                >
                  <Download size={18} /> Download Gambar (3 Kredit)
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default Animagine;