import React, { useState } from 'react';
import { User, Lock, ArrowRight, Loader2 } from 'lucide-react';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
import { visionCard, actionBtn } from '../styles/themeStyles';
import OmniLogo from '../assets/OmniLogo';

function Auth({ theme, onLoginSuccess }) {
  const [isLoginMode, setIsLoginMode] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const API_BASE = "https://mtztf49c-8000.asse.devtunnels.ms";

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!username || !password) {
      toast.error('Username dan password tidak boleh kosong!');
      return;
    }

    const toastId = toast.loading(isLoginMode ? 'Mencoba masuk...' : 'Mendaftarkan akun...');
    setIsLoading(true);
    const endpoint = isLoginMode ? '/api/login' : '/api/register';

    try {
      const response = await axios.post(`${API_BASE}${endpoint}`, {
        username: username,
        password: password
      });

      if (response.data.status === 'success') {
        toast.success(isLoginMode ? 'Login berhasil!' : 'Registrasi berhasil! Silakan login.', { id: toastId });
        
        if (isLoginMode) {
          localStorage.setItem('omni_token', response.data.token);
          localStorage.setItem('omni_user', response.data.username);
          localStorage.setItem('omni_role', response.data.role);
          
          setTimeout(() => {
            onLoginSuccess(response.data.username);
          }, 1000);
        } else {
          setIsLoginMode(true); 
          setPassword('');
        }
      } else {
        toast.error(response.data.message, { id: toastId });
      }
    } catch (error) {
      console.error(error);
      toast.error('Terjadi kesalahan koneksi ke server.', { id: toastId });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center', backgroundColor: theme.bg, padding: '20px' }}>
      
      <Toaster 
        position="top-center" 
        toastOptions={{
          style: {
            background: theme.bg,
            color: theme.text,
            border: `1px solid ${theme.border}`,
          }
        }} 
      />

      <div style={{ ...visionCard, backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`, maxWidth: '400px', width: '100%', padding: '40px 30px', textAlign: 'center' }}>
        
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '20px' }}>
          <OmniLogo className="w-16 h-16" />
        </div>
        
        <h2 style={{ color: theme.text, margin: '0 0 10px 0', fontSize: '24px' }}>Omni AI Portal</h2>
        <p style={{ color: theme.subText, margin: '0 0 30px 0', fontSize: '14px' }}>
          {isLoginMode ? "Silakan masuk untuk melanjutkan" : "Buat akun baru Anda"}
        </p>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
          <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
            <User size={18} color={theme.subText} style={{ position: 'absolute', left: '15px' }} />
            <input 
              type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)}
              style={{ width: '100%', padding: '12px 15px 12px 45px', borderRadius: '10px', border: `2px solid ${theme.border}`, backgroundColor: theme.bg, color: theme.text, outline: 'none' }}
            />
          </div>

          <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
            <Lock size={18} color={theme.subText} style={{ position: 'absolute', left: '15px' }} />
            <input 
              type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)}
              style={{ width: '100%', padding: '12px 15px 12px 45px', borderRadius: '10px', border: `2px solid ${theme.border}`, backgroundColor: theme.bg, color: theme.text, outline: 'none' }}
            />
          </div>

          <button 
            type="submit" disabled={isLoading}
            style={{ ...actionBtn(false, theme), backgroundColor: theme.accent, width: '100%', padding: '15px', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '10px', marginTop: '10px', opacity: isLoading ? 0.7 : 1 }}
          >
            {isLoading ? <Loader2 className="animate-spin" size={20} /> : (isLoginMode ? "Masuk Sistem" : "Daftar Sekarang")}
            {!isLoading && <ArrowRight size={18} />}
          </button>
        </form>

        <p style={{ color: theme.subText, marginTop: '25px', fontSize: '14px' }}>
          {isLoginMode ? "Belum punya akun? " : "Sudah punya akun? "}
          <span 
            onClick={() => { setIsLoginMode(!isLoginMode); setPassword(''); }}
            style={{ color: theme.accent, cursor: 'pointer', textDecoration: 'underline' }}
          >
            {isLoginMode ? "Daftar di sini" : "Login di sini"}
          </span>
        </p>
      </div>
    </div>
  );
}

export default Auth;