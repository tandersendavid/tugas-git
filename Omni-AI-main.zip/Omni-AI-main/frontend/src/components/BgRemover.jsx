import React, { useState } from 'react';
import { Eraser, Upload, Download, Loader2 } from 'lucide-react';
import axios from 'axios';
import { scrollArea, visionCard, visionCardHeader, actionBtn } from '../styles/themeStyles';
import toast from 'react-hot-toast';

function BgRemover({ theme }) {
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [resultUrl, setResultUrl] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // Sesuaikan dengan URL backend kamu
  const API_BASE = "https://mtztf49c-8000.asse.devtunnels.ms";

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      // Membersihkan memori dari URL blob sebelumnya agar tidak leak
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      if (resultUrl) URL.revokeObjectURL(resultUrl);

      const file = e.target.files[0];
      setSelectedFile(file);
      setPreviewUrl(URL.createObjectURL(file));
      setResultUrl(null);
    }
  };

  const handleProcess = async () => {
    if (!selectedFile) return;
    setIsLoading(true);
    
    const formData = new FormData();
    formData.append('file', selectedFile);

    try {
      const response = await axios.post(
        `${API_BASE}/api/remove-bg`,
        formData,
        { 
          responseType: 'blob',
          headers: {
            // Mengirim token untuk validasi kredit di backend
            'Authorization': `Bearer ${localStorage.getItem('omni_token')}`
          }
        }
      );
      
      // Mengubah hasil blob dari server menjadi URL yang bisa ditampilkan di <img>
      const url = URL.createObjectURL(response.data);
      setResultUrl(url);
      toast.success("Background berhasil dihapus!");
      
    } catch (error) {
      console.error("Error details:", error);
      if (error.response && error.response.status === 403) {
        toast.error("Kredit habis atau tidak cukup!");
      } else if (error.response && error.response.status === 401) {
        toast.error("Sesi habis, silakan login kembali.");
      } else {
        toast.error("Gagal terhubung ke server AI.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={scrollArea}>
      <div style={{ maxWidth: '800px', margin: '0 auto', padding: '30px' }}>
        <div style={{...visionCard, backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`}}>
          
          <div style={visionCardHeader}>
            <Eraser size={24} color={theme.accent}/>
            <div>
              <h3 style={{fontSize: '18px', margin: 0, color: theme.text}}>AI Background Remover</h3>
              <p style={{fontSize: '13px', color: theme.subText, margin: '2px 0 0 0'}}>Hapus latar belakang foto secara otomatis menggunakan AI.</p>
            </div>
          </div>

          <div style={{ padding: '20px 0', display: 'flex', flexDirection: 'column', gap: '20px', alignItems: 'center' }}>
            <input 
              type="file" 
              accept="image/*" 
              onChange={handleFileChange} 
              id="bg-upload" 
              style={{ display: 'none' }} 
            />
            
            <label htmlFor="bg-upload" style={{...actionBtn(false, theme), cursor: 'pointer', display: 'flex', gap: '10px', padding: '10px 20px'}}>
              <Upload size={18} /> {selectedFile ? "Ganti Foto" : "Pilih Foto"}
            </label>

            <div style={{ display: 'flex', width: '100%', gap: '20px', justifyContent: 'center', flexWrap: 'wrap' }}>
              {/* Preview Foto Asli */}
              {previewUrl && (
                <div style={{ flex: 1, minWidth: '250px', textAlign: 'center' }}>
                  <p style={{ color: theme.text, marginBottom: '10px', fontSize: '14px' }}>Original</p>
                  <img src={previewUrl} alt="Original" style={{ width: '100%', borderRadius: '8px', border: `1px solid ${theme.border}`, maxHeight: '300px', objectFit: 'contain' }} />
                </div>
              )}

              {/* Loading State */}
              {isLoading && (
                <div style={{ flex: 1, minWidth: '250px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '200px' }}>
                   <Loader2 size={40} color={theme.accent} className="animate-spin" />
                   <p style={{ marginTop: '15px', color: theme.text, fontWeight: '500' }}>Sedang Memproses...</p>
                </div>
              )}

              {/* Hasil Transparan */}
              {resultUrl && !isLoading && (
                <div style={{ flex: 1, minWidth: '250px', textAlign: 'center' }}>
                  <p style={{ color: theme.accent, marginBottom: '10px', fontSize: '14px', fontWeight: 'bold' }}>Hasil (PNG Transparan)</p>
                  
                  {/* Container dengan efek Checkerboard untuk menunjukkan transparansi */}
                  <div style={{ 
                    backgroundImage: 'linear-gradient(45deg, #808080 25%, transparent 25%), linear-gradient(-45deg, #808080 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #808080 75%), linear-gradient(-45deg, transparent 75%, #808080 75%)',
                    backgroundSize: '20px 20px',
                    backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px',
                    backgroundColor: '#eee',
                    borderRadius: '8px',
                    padding: '10px',
                    minHeight: '150px',
                    display: 'flex',
                    alignItems: 'center'
                  }}>
                    <img src={resultUrl} alt="Result" style={{ width: '100%', display: 'block', maxHeight: '300px', objectFit: 'contain' }} />
                  </div>

                  {/* Tombol Download Langsung dari Blob URL */}
                  <a 
                    href={resultUrl} 
                    download="Omni_NoBG.png" 
                    style={{
                      ...actionBtn(false, theme), 
                      display: 'inline-flex', 
                      marginTop: '15px', 
                      gap: '8px', 
                      padding: '10px 20px', 
                      textDecoration: 'none',
                      backgroundColor: '#10b981',
                      color: 'white',
                      width: '100%',
                      justifyContent: 'center'
                    }}
                  >
                    <Download size={18} /> Simpan ke Perangkat
                  </a>
                </div>
              )}
            </div>
          </div>

          {/* Tombol Eksekusi */}
          {selectedFile && !isLoading && !resultUrl && (
            <button 
              onClick={handleProcess} 
              style={{...actionBtn(false, theme), backgroundColor: theme.accent, width: '100%', padding: '14px', fontSize: '16px', fontWeight: 'bold'}}
            >
              <Eraser size={20}/> Mulai Hapus Background (3 Kredit)
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export default BgRemover;