import React, { useState } from 'react';
import { Palette, Upload, Download, Loader2 } from 'lucide-react';
import axios from 'axios';
import { scrollArea, visionCard, visionCardHeader, actionBtn } from '../styles/themeStyles';
import toast from 'react-hot-toast';

function Colorizer({ theme }) {
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [colorizedUrl, setColorizedUrl] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // Sesuaikan dengan URL backend kamu
  const API_BASE = "https://mtztf49c-8000.asse.devtunnels.ms";

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      // Membersihkan memori dari URL blob sebelumnya
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      if (colorizedUrl) URL.revokeObjectURL(colorizedUrl);

      const file = e.target.files[0];
      setSelectedFile(file);
      setPreviewUrl(URL.createObjectURL(file));
      setColorizedUrl(null);
    }
  };

  const handleColorize = async () => {
    if (!selectedFile) return;
    setIsLoading(true);
    
    const formData = new FormData();
    formData.append('file', selectedFile);

    try {
      const response = await axios.post(
        `${API_BASE}/api/colorize`,
        formData,
        { 
          responseType: 'blob',
          headers: {
            // MENYISIPKAN TOKEN UNTUK VALIDASI KREDIT (3 KREDIT)
            'Authorization': `Bearer ${localStorage.getItem('omni_token')}`
          }
        }
      );
      
      const url = URL.createObjectURL(response.data);
      setColorizedUrl(url);
      toast.success("Foto berhasil diwarnai!");

    } catch (error) {
      console.error("Colorizer Error:", error);
      if (error.response && error.response.status === 403) {
        toast.error("Kredit tidak cukup! Jatah harian 50 kredit.");
      } else if (error.response && error.response.status === 401) {
        toast.error("Sesi habis, silakan login kembali.");
      } else {
        toast.error("Gagal mewarnai foto.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={scrollArea}>
      <div style={{ maxWidth: '800px', margin: '0 auto', padding: '30px' }}>
        <div style={{...visionCard, backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`}}>
          
          <div style={visionCardHeader}>
            <Palette size={24} color={theme.accent}/>
            <div>
              <h3 style={{fontSize: '18px', margin: 0, color: theme.text}}>AI Image Colorizer</h3>
              <p style={{fontSize: '13px', color: theme.subText, margin: '2px 0 0 0'}}>Berikan warna pada foto lama atau hitam-putih kamu secara instan.</p>
            </div>
          </div>

          <div style={{ padding: '20px 0', display: 'flex', flexDirection: 'column', gap: '20px', alignItems: 'center' }}>
            <input 
              type="file" 
              accept="image/*" 
              onChange={handleFileChange} 
              id="color-upload" 
              style={{ display: 'none' }} 
            />
            
            <label htmlFor="color-upload" style={{...actionBtn(false, theme), cursor: 'pointer', display: 'flex', gap: '10px', padding: '10px 20px'}}>
              <Upload size={18} /> {selectedFile ? "Ganti Foto" : "Pilih Foto B&W"}
            </label>

            <div style={{ display: 'flex', width: '100%', gap: '20px', justifyContent: 'center', flexWrap: 'wrap' }}>
              {previewUrl && (
                <div style={{ flex: 1, minWidth: '250px', textAlign: 'center' }}>
                  <p style={{ color: theme.text, marginBottom: '10px', fontSize: '14px' }}>B&W (Original)</p>
                  <img src={previewUrl} alt="B&W" style={{ width: '100%', borderRadius: '8px', border: `1px solid ${theme.border}`, maxHeight: '350px', objectFit: 'contain' }} />
                </div>
              )}

              {isLoading && (
                <div style={{ flex: 1, minWidth: '250px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '200px' }}>
                   <Loader2 size={40} color={theme.accent} className="animate-spin" />
                   <p style={{ marginTop: '15px', color: theme.text, fontWeight: '500' }}>Menganalisa Warna...</p>
                </div>
              )}

              {colorizedUrl && !isLoading && (
                <div style={{ flex: 1, minWidth: '250px', textAlign: 'center' }}>
                  <p style={{ color: theme.accent, marginBottom: '10px', fontSize: '14px', fontWeight: 'bold' }}>Hasil (Colorized)</p>
                  <img src={colorizedUrl} alt="Colorized" style={{ width: '100%', borderRadius: '8px', border: `2px solid ${theme.accent}`, maxHeight: '350px', objectFit: 'contain' }} />
                  
                  {/* DOWNLOAD LANGSUNG DARI BLOB (GRATIS) */}
                  <a 
                    href={colorizedUrl} 
                    download="Omni_Colorized.png" 
                    style={{
                      ...actionBtn(false, theme), 
                      display: 'inline-flex', 
                      marginTop: '15px', 
                      gap: '8px', 
                      padding: '10px 20px', 
                      textDecoration: 'none',
                      backgroundColor: '#10b981',
                      color: 'white',
                      width: '100%',
                      justifyContent: 'center'
                    }}
                  >
                    <Download size={18} /> Simpan Foto
                  </a>
                </div>
              )}
            </div>
          </div>

          {selectedFile && !isLoading && !colorizedUrl && (
            <button 
              onClick={handleColorize} 
              style={{...actionBtn(false, theme), backgroundColor: theme.accent, width: '100%', padding: '14px', fontSize: '16px', fontWeight: 'bold'}}
            >
              <Palette size={20}/> Warnai Sekarang (3 Kredit)
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export default Colorizer;