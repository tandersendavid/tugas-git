import React, { useState } from 'react';
import { ShieldCheck, Lock, Unlock, Copy, RefreshCw } from 'lucide-react';
import axios from 'axios';
import { scrollArea, visionCard, visionCardHeader, actionBtn } from '../styles/themeStyles';
import toast from 'react-hot-toast';

function Cryptography({ theme }) {
  const [text, setText] = useState("");
  const [secretKey, setSecretKey] = useState("");
  const [result, setResult] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const API_BASE_LOCAL = "http://localhost:8000";

  const handleAction = async (type) => {
    if (!text || !secretKey) return toast.error("Isi pesan dan kunci rahasia!");
    setIsLoading(true);

    const formData = new FormData();
    formData.append(type === 'encrypt' ? 'message' : 'token', text);
    formData.append('key', secretKey);

    try {
      const res = await axios.post(`${API_BASE_LOCAL}/api/crypto/${type}`, formData, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('omni_token')}` }
      });

      if (res.data.status === 'success') {
        setResult(res.data.result);
        toast.success(type === 'encrypt' ? "Pesan berhasil diacak!" : "Pesan berhasil dibuka!");
      } else {
        toast.error(res.data.message);
      }
    } catch (error) {
      toast.error("Gagal terhubung ke server.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={scrollArea}>
      <div style={{ maxWidth: '800px', margin: '0 auto', padding: '30px' }}>
        <div style={{...visionCard, backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`}}>
          <div style={visionCardHeader}>
            <ShieldCheck size={24} color={theme.accent}/>
            <div>
              <h3 style={{color: theme.text, margin: 0}}>Omni Cryptography</h3>
              <p style={{color: theme.subText, fontSize: '13px'}}>Enkripsi AES standar militer untuk pesan teks Anda.</p>
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '15px', marginTop: '20px' }}>
            <textarea 
              placeholder="Masukkan teks biasa atau kode enkripsi di sini..."
              value={text}
              onChange={(e) => setText(e.target.value)}
              style={{ width: '100%', padding: '15px', borderRadius: '10px', backgroundColor: theme.bg, color: theme.text, border: `1px solid ${theme.border}`, minHeight: '120px' }}
            />

            <div style={{ display: 'flex', gap: '10px' }}>
              <input 
                type="password"
                placeholder="Masukkan Kunci Rahasia (Password)"
                value={secretKey}
                onChange={(e) => setSecretKey(e.target.value)}
                style={{ flex: 1, padding: '12px', borderRadius: '10px', backgroundColor: theme.bg, color: theme.text, border: `1px solid ${theme.border}` }}
              />
            </div>

            <div style={{ display: 'flex', gap: '10px' }}>
              <button onClick={() => handleAction('encrypt')} style={{...actionBtn(false, theme), flex: 1, backgroundColor: theme.accent}}>
                <Lock size={18} style={{marginRight: '8px'}}/> Encrypt
              </button>
              <button onClick={() => handleAction('decrypt')} style={{...actionBtn(false, theme), flex: 1, backgroundColor: '#10b981'}}>
                <Unlock size={18} style={{marginRight: '8px'}}/> Decrypt
              </button>
            </div>

            {result && (
              <div style={{ marginTop: '20px', padding: '20px', backgroundColor: theme.bg, borderRadius: '10px', border: `2px dashed ${theme.accent}`, position: 'relative' }}>
                <p style={{ fontSize: '11px', color: theme.accent, fontWeight: 'bold', marginBottom: '10px' }}>HASIL PROSES:</p>
                <p style={{ color: theme.text, wordBreak: 'break-all', fontFamily: 'monospace' }}>{result}</p>
                <button 
                  onClick={() => { navigator.clipboard.writeText(result); toast.success("Salin ke clipboard!"); }}
                  style={{ position: 'absolute', top: '10px', right: '10px', background: 'none', border: 'none', color: theme.subText, cursor: 'pointer' }}
                >
                  <Copy size={16} />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Cryptography;