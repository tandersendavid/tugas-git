import React, { useState } from 'react';
import { Sparkles, Loader2, Image as ImageIcon, Download, Settings, Layers } from 'lucide-react';
import axios from 'axios';
import { scrollArea, visionCard, visionCardHeader, actionBtn } from '../styles/themeStyles';
import toast from 'react-hot-toast';

function DeepAI({ theme }) {
  const [prompt, setPrompt] = useState('');
  const [shape, setShape] = useState('square');
  const [modelType, setModelType] = useState('future-architecture-generator');
  const [data, setData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // Gunakan URL DevTunnels kamu
  const API_BASE = "https://mtztf49c-8000.asse.devtunnels.ms"; 

  const handleGenerate = async () => {
    if (!prompt) return;
    setIsLoading(true);
    setData(null);

    try {
      // PENAMBAHAN TOKEN PADA REQUEST GET
      const response = await axios.get(
        `${API_BASE}/api/tools/deepai?prompt=${encodeURIComponent(prompt)}&shape=${shape}&model=${modelType}`,
        {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('omni_token')}`
          }
        }
      );
      
      if (response.data.status === 'success') {
        setData(response.data);
        toast.success("Art berhasil dibuat!");
      } else {
        toast.error("Gagal memproses gambar: " + response.data.message);
      }
    } catch (error) {
      console.error(error);
      if (error.response && error.response.status === 403) {
        toast.error("Kredit habis! Jatah harian 50 kredit.");
      } else {
        toast.error("Gagal terhubung ke Backend AI.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={scrollArea}>
      <div style={{ maxWidth: '800px', margin: '0 auto', padding: '30px' }}>
        <div style={{...visionCard, backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`}}>
          
          <div style={visionCardHeader}>
            <Layers size={24} color={theme.accent}/>
            <div>
              <h3 style={{fontSize: '18px', margin: 0, color: theme.text}}>DeepAI Studio</h3>
              <p style={{fontSize: '13px', color: theme.subText, margin: '2px 0 0 0'}}>Multiple Art Styles & Architectures</p>
            </div>
          </div>

          <div style={{ padding: '20px 0', display: 'flex', flexDirection: 'column', gap: '15px' }}>
            
            <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
              <select 
                value={modelType} 
                onChange={(e) => setModelType(e.target.value)}
                style={{ flex: 1, padding: '10px', borderRadius: '8px', border: `1px solid ${theme.border}`, backgroundColor: theme.bg, color: theme.text }}
              >
                <option value="future-architecture-generator">Future Architecture</option>
                <option value="cute-creature-generator">Cute Creature</option>
                <option value="fantasy-world-generator">Fantasy World</option>
              </select>

              <select 
                value={shape} 
                onChange={(e) => setShape(e.target.value)}
                style={{ flex: 1, padding: '10px', borderRadius: '8px', border: `1px solid ${theme.border}`, backgroundColor: theme.bg, color: theme.text }}
              >
                <option value="square">Square (1:1)</option>
                <option value="portrait">Portrait (Potret)</option>
                <option value="landscape">Landscape (Pemandangan)</option>
              </select>
            </div>

            <textarea 
              placeholder="Deskripsikan imajinasimu dalam bahasa Inggris..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={3}
              style={{
                width: '100%', padding: '15px', borderRadius: '10px',
                border: `2px solid ${theme.border}`, backgroundColor: theme.bg,
                color: theme.text, outline: 'none', fontSize: '14px', resize: 'vertical'
              }}
            />

            <button 
              onClick={handleGenerate}
              disabled={isLoading || !prompt}
              style={{
                ...actionBtn(false, theme), backgroundColor: theme.accent,
                width: '100%', padding: '12px', opacity: (isLoading || !prompt) ? 0.6 : 1,
                cursor: (isLoading || !prompt) ? 'not-allowed' : 'pointer',
                display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '10px',
                fontWeight: 'bold', fontSize: '15px'
              }}
            >
              {isLoading ? (
                <>
                  <Loader2 className="animate-spin" size={20} /> 
                  <span>Membangun Dimensi...</span>
                </>
              ) : (
                <>
                  <Sparkles size={20} /> 
                  <span>Generate Art (5 Kredit)</span>
                </>
              )}
            </button>
          </div>

          {data && (
            <div style={{ 
              marginTop: '10px', padding: '20px', borderRadius: '12px', 
              backgroundColor: theme.bg, border: `1px solid ${theme.border}`,
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '20px', 
              animation: 'fadeIn 0.5s ease'
            }}>
              
              <img 
                src={data.image_url}
                onContextMenu={(e) => e.preventDefault()}
                alt="Generated DeepAI Art"
                style={{ width: '100%', maxHeight: '500px', objectFit: 'contain', borderRadius: '8px', boxShadow: '0 4px 15px rgba(0,0,0,0.2)' }} 
              />
              
              <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', fontSize: '13px', color: theme.subText }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: '5px', backgroundColor: theme.border, padding: '5px 10px', borderRadius: '5px' }}>
                    <Settings size={14} /> Model: {data.model}
                  </span>
                  <span style={{ display: 'flex', alignItems: 'center', gap: '5px', backgroundColor: theme.border, padding: '5px 10px', borderRadius: '5px' }}>
                    <ImageIcon size={14} /> Shape: {data.shape}
                  </span>
                </div>
                
                <p style={{ fontSize: '13px', color: theme.subText, fontStyle: 'italic', margin: '5px 0' }}>
                  <strong>Prompt:</strong> {data.prompt_used}
                </p>

                {/* PENAMBAHAN PARAMETER TOKEN DI URL DOWNLOAD (3 Kredit) */}
                <a 
                  href={`${API_BASE}/api/proxy/download?url=${encodeURIComponent(data.image_url)}&token=${localStorage.getItem('omni_token')}`}
                  style={{
                    ...actionBtn(false, theme), textDecoration: 'none', display: 'flex', justifyContent: 'center', gap: '8px',
                    backgroundColor: '#10b981', color: 'white', padding: '12px 20px', fontWeight: 'bold', width: '100%', marginTop: '10px'
                  }}
                >
                  <Download size={18} /> Download Gambar (3 Kredit)
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default DeepAI;