import React, { useState, useEffect } from 'react';
import { UserCheck, Power } from 'lucide-react';
import axios from 'axios';
import { 
  scrollArea, visionCard, visionCardHeader, 
  videoStreamWrapper, videoStreamImg, actionBtn
} from '../styles/themeStyles';
import toast from 'react-hot-toast';

function FaceAnalytics({ theme }) {
  const [isStreamActive, setIsStreamActive] = useState(false);

  // URL Backend kamu
  const API_BASE_TUNNEL = "https://mtztf49c-8000.asse.devtunnels.ms";
  const API_BASE_LOCAL = "http://localhost:8000";

  // Membersihkan stream saat pindah halaman
  useEffect(() => {
    return () => { 
      axios.post(`${API_BASE_TUNNEL}/api/vision/stop`, {}, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('omni_token')}` }
      }).catch(() => {}); 
    };
  }, []);

  const toggleStream = async () => {
    if (isStreamActive) {
      setIsStreamActive(false);
      try {
        await axios.post(`${API_BASE_TUNNEL}/api/vision/stop`, {}, {
          headers: { 'Authorization': `Bearer ${localStorage.getItem('omni_token')}` }
        });
      } catch (e) { console.error("Gagal menghentikan stream"); }
    } else {
      // Sebelum menyalakan stream, kita pastikan token ada
      if (!localStorage.getItem('omni_token')) {
        toast.error("Silakan login kembali.");
        return;
      }
      setIsStreamActive(true);
      toast.success("Memulai Analisa (Biaya: 5 Kredit)");
    }
  };

  return (
    <div style={scrollArea}>
      <div style={{ maxWidth: '800px', margin: '0 auto', padding: '30px' }}>
        <div style={{...visionCard, backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`}}>
          <div style={visionCardHeader}>
            <UserCheck size={24} color={theme.accent}/>
            <div>
              <h3 style={{fontSize: '18px', margin: 0, color: theme.text}}>Real-time Face Analytics</h3>
              <p style={{fontSize: '13px', color: theme.subText, margin: '2px 0 0 0'}}>AI memprediksi umur dan jenis kelamin kamu secara instan.</p>
            </div>
          </div>
          
          <div style={{...videoStreamWrapper, border: `2px solid ${isStreamActive ? theme.accent : theme.border}`, backgroundColor: '#000', display: 'flex', justifyContent: 'center', alignItems: 'center', overflow: 'hidden', borderRadius: '12px'}}>
            {isStreamActive ? (
              /* PENTING: Mengirim token lewat URL karena tag <img> tidak mendukung headers */
              <img 
                src={`${API_BASE_LOCAL}/api/vision/stream_analytics?token=${localStorage.getItem('omni_token')}`} 
                alt="AI Analytics" 
                style={videoStreamImg} 
                onError={() => {
                  toast.error("Gagal memuat stream. Pastikan backend lokal berjalan.");
                  setIsStreamActive(false);
                }}
              />
            ) : (
              <div style={{ color: 'white', textAlign: 'center', padding: '50px' }}>
                <UserCheck size={48} color={theme.subText} style={{ marginBottom: '10px' }}/>
                <p style={{ color: theme.subText }}>Kamera tidak aktif.</p>
              </div>
            )}
          </div>

          <button 
            onClick={toggleStream} 
            style={{...actionBtn(false, theme), backgroundColor: isStreamActive ? '#ef4444' : theme.accent, width: '100%', marginTop: '20px', padding: '14px', fontWeight: 'bold'}}
          >
            <Power size={18} style={{ marginRight: '8px' }}/> 
            {isStreamActive ? "Matikan Analisa" : "Mulai Analisa Wajah (5 Kredit)"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default FaceAnalytics;