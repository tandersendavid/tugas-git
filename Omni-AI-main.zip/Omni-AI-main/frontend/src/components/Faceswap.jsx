import React, { useState } from 'react';
import { UploadCloud, Image as ImageIcon, Loader2, Download, Sparkles} from 'lucide-react';
import axios from 'axios';
import { 
  scrollArea, visionCard, visionCardHeader, swapContainer, uploadGrid, 
  uploadBox, previewImg, actionBtn, resultContainer, resultImg 
} from '../styles/themeStyles';
import toast from 'react-hot-toast';

function Faceswap({ theme }) {
  const [sourceImg, setSourceImg] = useState(null);
  const [targetImg, setTargetImg] = useState(null);
  const [sourcePreview, setSourcePreview] = useState(null);
  const [targetPreview, setTargetPreview] = useState(null);
  const [resultImgUrl, setResultImgUrl] = useState(null);
  const [isSwapping, setIsSwapping] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const API_BASE = "https://mtztf49c-8000.asse.devtunnels.ms";

  const handleImageChange = (e, type) => {
    const file = e.target.files[0];
    if (!file) return;

    const previewUrl = URL.createObjectURL(file);
    if (type === 'source') {
      if (sourcePreview) URL.revokeObjectURL(sourcePreview);
      setSourceImg(file);
      setSourcePreview(previewUrl);
    } else {
      if (targetPreview) URL.revokeObjectURL(targetPreview);
      setTargetImg(file);
      setTargetPreview(previewUrl);
    }
    setResultImgUrl(null);
    setErrorMsg('');
  };

  const handleSwapFaces = async () => {
    if (!sourceImg || !targetImg) return;
    
    setIsSwapping(true);
    setErrorMsg('');
    setResultImgUrl(null);

    const formData = new FormData();
    formData.append('source_img', sourceImg);
    formData.append('target_img', targetImg);

    try {
      const res = await axios.post(`${API_BASE}/api/faceswap`, formData, {
        headers: { 
          'Content-Type': 'multipart/form-data',
          'Authorization': `Bearer ${localStorage.getItem('omni_token')}`
        },
        responseType: 'blob' 
      });

      // Validasi jika respons bukan gambar (error JSON yang dibungkus Blob)
      if (res.data.type === 'application/json') {
        const textData = await res.data.text();
        const json = JSON.parse(textData);
        setErrorMsg(json.error || 'Gagal memproses wajah.');
        setIsSwapping(false);
        return;
      }

      const imageUrl = URL.createObjectURL(res.data);
      setResultImgUrl(imageUrl);
      toast.success("Wajah berhasil ditukar!");
    } catch (err) {
      if (err.response && err.response.status === 403) {
        setErrorMsg('Kredit tidak cukup! Fitur ini membutuhkan 3 kredit.');
        toast.error("Kredit habis!");
      } else {
        setErrorMsg('Koneksi ke server gagal. Pastikan Backend aktif.');
      }
    } finally {
      setIsSwapping(false);
    }
  };

  return (
    <div style={scrollArea}>
      <div style={swapContainer}>
        <div style={{...visionCard, backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`}}>
          <div style={visionCardHeader}>
            <ImageIcon size={24} color={theme.accent}/>
            <div>
              <h3 style={{fontSize: '18px', margin: 0, color: theme.text}}>AI Face Swapper</h3>
              <p style={{fontSize: '13px', color: theme.subText, margin: '2px 0 0 0'}}>Tukar wajah secara instan menggunakan model InsightFace.</p>
            </div>
          </div>

          <div style={uploadGrid}>
            <label style={uploadBox(theme)}>
              <input type="file" accept="image/*" onChange={(e) => handleImageChange(e, 'source')} style={{ display: 'none' }} />
              {sourcePreview ? (
                <img src={sourcePreview} alt="Source" style={previewImg} />
              ) : (
                <>
                  <UploadCloud size={32} color={theme.subText} style={{ marginBottom: '10px' }}/>
                  <span style={{ fontSize: '14px', fontWeight: '600', color: theme.text }}>Upload Foto Wajah</span>
                  <span style={{ fontSize: '11px', color: theme.subText, marginTop: '5px' }}>(Wajah Sumber)</span>
                </>
              )}
            </label>

            <label style={uploadBox(theme)}>
              <input type="file" accept="image/*" onChange={(e) => handleImageChange(e, 'target')} style={{ display: 'none' }} />
              {targetPreview ? (
                <img src={targetPreview} alt="Target" style={previewImg} />
              ) : (
                <>
                  <UploadCloud size={32} color={theme.subText} style={{ marginBottom: '10px' }}/>
                  <span style={{ fontSize: '14px', fontWeight: '600', color: theme.text }}>Upload Foto Target</span>
                  <span style={{ fontSize: '11px', color: theme.subText, marginTop: '5px' }}>(Foto Tujuan)</span>
                </>
              )}
            </label>
          </div>

          {errorMsg && (
            <div style={{ backgroundColor: '#fee2e2', color: '#ef4444', padding: '10px', borderRadius: '8px', marginTop: '15px', fontSize: '13px', textAlign: 'center', border: '1px solid #f87171' }}>
              {errorMsg}
            </div>
          )}

          <button 
            onClick={handleSwapFaces} 
            disabled={!sourceImg || !targetImg || isSwapping} 
            style={{ ...actionBtn(!sourceImg || !targetImg || isSwapping, theme), marginTop: '20px' }}
          >
            {isSwapping ? <><Loader2 size={18} className="animate-spin"/> AI Sedang Bekerja...</> : <><Sparkles size={18}/> Tukar Wajah (3 Kredit)</>}
          </button>

          {resultImgUrl && (
            <div style={resultContainer}>
              <h4 style={{ color: 'white', margin: '0 0 10px 0' }}>Hasil Pertukaran:</h4>
              <img src={resultImgUrl} alt="Swapped Result" style={resultImg} />
              {/* DOWNLOAD LANGSUNG DARI BLOB (GRATIS) */}
              <a 
                href={resultImgUrl} 
                download="Omni_FaceSwap_Result.jpg" 
                style={{ 
                  color: '#60a5fa', 
                  textDecoration: 'none', 
                  fontSize: '14px', 
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: '5px',
                  marginTop: '10px',
                  justifyContent: 'center'
                }}
              >
                <Download size={16}/> Simpan Hasil
              </a>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}

export default Faceswap;