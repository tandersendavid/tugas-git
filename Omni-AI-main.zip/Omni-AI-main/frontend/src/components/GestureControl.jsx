import React, { useState, useEffect } from 'react';
import { Hand, Power } from 'lucide-react';
import axios from 'axios';
import { 
  scrollArea, visionCard, visionCardHeader, 
  videoStreamWrapper, videoStreamImg, actionBtn
} from '../styles/themeStyles';
import toast from 'react-hot-toast';

function GestureControl({ theme }) {
  const [isStreamActive, setIsStreamActive] = useState(false);

  // URL Backend
  const API_BASE_TUNNEL = "https://mtztf49c-8000.asse.devtunnels.ms";
  const API_BASE_LOCAL = "http://localhost:8000";

  // Pastikan mematikan kamera & proses di backend saat pindah tab/halaman
  useEffect(() => {
    return () => { 
      axios.post(`${API_BASE_TUNNEL}/api/vision/stop`, {}, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('omni_token')}` }
      }).catch(() => {}); 
    };
  }, []);

  const toggleStream = async () => {
    const token = localStorage.getItem('omni_token');

    if (isStreamActive) {
      setIsStreamActive(false);
      try {
        await axios.post(`${API_BASE_TUNNEL}/api/vision/stop`, {}, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
      } catch (e) {
        console.error("Gagal menghentikan stream gesture");
      }
    } else {
      if (!token) {
        toast.error("Silakan login kembali.");
        return;
      }
      setIsStreamActive(true);
      toast.success("Sensor Tangan Aktif (Biaya: 3 Kredit)");
    }
  };

  return (
    <div style={scrollArea}>
      <div style={{ maxWidth: '800px', margin: '0 auto', padding: '30px' }}>
        <div style={{...visionCard, backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`}}>
          
          <div style={visionCardHeader}>
            <Hand size={24} color={theme.accent}/>
            <div>
              <h3 style={{fontSize: '18px', margin: 0, color: theme.text}}>Interactive Gesture Control</h3>
              <p style={{fontSize: '13px', color: theme.subText, margin: '2px 0 0 0'}}>
                Kendali AI menggunakan gerakan tangan secara real-time.
              </p>
            </div>
          </div>
          
          <div style={{...videoStreamWrapper, border: `2px solid ${isStreamActive ? theme.accent : theme.border}`, backgroundColor: '#000', display: 'flex', justifyContent: 'center', alignItems: 'center', overflow: 'hidden', borderRadius: '12px'}}>
            {isStreamActive ? (
              /* MENYISIPKAN TOKEN LEWAT URL UNTUK VALIDASI KREDIT STREAMING */
              <img 
                src={`${API_BASE_LOCAL}/api/vision/stream_gesture?token=${localStorage.getItem('omni_token')}`} 
                alt="Gesture Stream" 
                style={videoStreamImg} 
                onError={() => {
                  toast.error("Gagal memuat sensor. Pastikan backend lokal berjalan.");
                  setIsStreamActive(false);
                }}
              />
            ) : (
              <div style={{ color: 'white', textAlign: 'center', padding: '50px' }}>
                <Hand size={48} color={theme.subText} style={{ marginBottom: '10px' }}/>
                <p style={{ color: theme.subText }}>Sensor sedang mati.</p>
              </div>
            )}
          </div>

          <button 
            onClick={toggleStream} 
            style={{...actionBtn(false, theme), backgroundColor: isStreamActive ? '#ef4444' : theme.accent, width: '100%', marginTop: '20px', padding: '14px', fontWeight: 'bold'}}
          >
            <Power size={18} style={{ marginRight: '8px' }}/> 
            {isStreamActive ? "Matikan Sensor Tangan" : "Aktifkan Sensor Tangan (3 Kredit)"}
          </button>
          
        </div>
      </div>
    </div>
  );
}

export default GestureControl;