import React, { useRef, useMemo, useLayoutEffect } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Camera, Layers3, Sparkles, ArrowRight } from 'lucide-react';
import { Canvas, useFrame } from '@react-three/fiber';
import { TrackballControls } from '@react-three/drei';
import * as THREE from 'three';

// Komponen 3D: Latar Belakang Jaringan Saraf
function NeuralBackground3D() {
  const groupRef = useRef();
  const meshRef = useRef();
  const linesRef = useRef();

  const particleCount = 250; 
  const prominentDotCount = 125; 

  const [positions, matrices, colors] = useMemo(() => {
    const pos = [];
    const mat = [];
    const cols = [];
    
    const tempMatrix = new THREE.Matrix4();
    const tempPosition = new THREE.Vector3();
    
    const colorWhite = new THREE.Color('#ffffff'); 
    const colorBlue = new THREE.Color('#3b82f6');  
    const colorLightBlue = new THREE.Color('#93c5fd'); 

    for (let i = 0; i < particleCount; i++) {
      // 1. KITA PERLEBAR jangkauan sebarannya (X, Y, Z)
      // X dari 14 jadi 20, Y dari 10 jadi 15 agar lebih menyebar ke pinggir
      const x = (Math.random() - 0.5) * 20; 
      const y = (Math.random() - 0.5) * 15; 
      const z = (Math.random() - 0.5) * 10; 
      
      // 2. HAPUS LOGIKA 'FACTOR' (Vortex Killer)
      // Kita tidak lagi memaksa titik luar untuk ditarik ke pusat
      tempPosition.set(x, y, z);
      pos.push(tempPosition.x, tempPosition.y, tempPosition.z);

      const isProminent = Math.random() > 0.8;
      const scale = isProminent ? 0.4 : 0.15; 

      tempMatrix.makeScale(scale, scale, scale);
      tempMatrix.setPosition(tempPosition);
      mat.push(tempMatrix.clone());

      if (isProminent) {
        cols.push(Math.random() > 0.5 ? colorWhite : colorBlue);
      } else {
        cols.push(colorLightBlue); 
      }
    }

    return [pos, mat, cols];
  }, [particleCount]);

  useLayoutEffect(() => {
    if (meshRef.current) {
      matrices.forEach((matrix, i) => {
        meshRef.current.setMatrixAt(i, matrix);
        meshRef.current.setColorAt(i, colors[i]); 
      });
      meshRef.current.instanceMatrix.needsUpdate = true;
      if (meshRef.current.instanceColor) {
        meshRef.current.instanceColor.needsUpdate = true;
      }
    }
  }, [matrices, colors]);

  const linesGeometry = useMemo(() => {
    const geometryPos = [];
    
    for (let i = 0; i < prominentDotCount; i++) {
      for (let j = i + 1; j < prominentDotCount; j++) {
        const dx = positions[i * 3] - positions[j * 3];
        const dy = positions[i * 3 + 1] - positions[j * 3 + 1];
        const dz = positions[i * 3 + 2] - positions[j * 3 + 2];
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        if (dist < 4.0) {
          geometryPos.push(
            positions[i * 3], positions[i * 3 + 1], positions[i * 3 + 2],
            positions[j * 3], positions[j * 3 + 1], positions[j * 3 + 2]
          );
        }
      }
    }
    
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(geometryPos, 3));
    return geometry;
  }, [positions]);

  useFrame((state, delta) => {
    if (groupRef.current) {
      groupRef.current.rotation.y += delta * 0.05;
      groupRef.current.rotation.x += delta * 0.02;
    }
  });

  return (
    <group ref={groupRef} scale={1.5}>
      <instancedMesh ref={meshRef} args={[null, null, particleCount]}>
        <sphereGeometry args={[1, 16, 16]} />
        {/* HANYA BARIS INI YANG BERUBAH: Menambahkan efek Additive Blending dan Transparansi */}
        <meshBasicMaterial 
          toneMapped={false} 
          transparent={true} 
          opacity={0.8} 
          blending={THREE.AdditiveBlending} 
        />
      </instancedMesh>

      <lineSegments ref={linesRef} geometry={linesGeometry}>
        <lineBasicMaterial color="#60a5fa" transparent opacity={0.4} linewidth={2} />
      </lineSegments>
    </group>
  );
}

// Komponen Utama
function LandingPage({ onEnter }) {
  const scrollRef = useRef(null);
  const touchStartRef = useRef(0); // State untuk melacak posisi awal sentuhan jari

  // GPU Scroll Opacity Framer Motion
  const { scrollYProgress } = useScroll({ container: scrollRef });
  const bgOpacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);

  const fadeUp = {
    hidden: { opacity: 0, y: 50 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: "easeOut" } }
  };

  // Kartu Kaca (Glassmorphism)
  const textContainerStyle = {
    padding: '40px',
    borderRadius: '20px',
    backgroundColor: 'rgba(15, 23, 42, 0.4)', 
    backdropFilter: 'blur(10px)', 
    border: '1px solid rgba(148, 163, 184, 0.1)', 
    boxShadow: '0px 10px 40px rgba(0,0,0,0.3)',
    textShadow: '0px 2px 2px rgba(0,0,0,0.9), 0px 4px 10px rgba(0,0,0,0.8)', 
    maxWidth: '700px',
    width: '90%', // Tambahan: Agar responsif di HP, tidak mentok ke pinggir layar
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '15px',
    pointerEvents: 'auto' // PENTING UNTUK MOBILE: Mengizinkan kartu untuk di-scroll dengan mulus
  };

  const sectionStyle = {
    minHeight: '100vh',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    padding: '20px',
    textAlign: 'center',
    color: '#f8fafc',
  };

  // Fungsi penangkap sentuhan manual (jika pengguna menggeser di luar area kartu)
  const handleTouchStart = (e) => {
    touchStartRef.current = e.touches[0].clientY;
  };

  const handleTouchMove = (e) => {
    if (scrollRef.current) {
      const touchY = e.touches[0].clientY;
      const deltaY = touchStartRef.current - touchY;
      scrollRef.current.scrollTop += deltaY;
      touchStartRef.current = touchY; // Update posisi
    }
  };

  return (
    <div 
      ref={scrollRef}
      style={{ backgroundColor: '#0f172a', fontFamily: 'Montserrat, sans-serif', overflowX: 'hidden', height: '100vh', overflowY: 'auto', position: 'relative' }}
    >
      
      {/* LAPISAN BELAKANG: KANVAS 3D */}
      <motion.div 
        style={{ 
          position: 'fixed', 
          top: 0, 
          left: 0, 
          width: '100vw', 
          height: '100vh', 
          zIndex: 0,
          opacity: bgOpacity 
        }}
        onWheel={(e) => {
          if (scrollRef.current) scrollRef.current.scrollTop += e.deltaY;
        }}
        // PENTING UNTUK MOBILE: Bypass sentuhan jari
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
      >
        <Canvas 
          camera={{ position: [0, 0, 12] }}
          // 1. Beri tahu browser untuk fokus ke performa tinggi
          gl={{ 
            powerPreference: "high-performance",
            antialias: false, // Mematikan penghalusan pinggiran (mengurangi beban GPU 30%)
            stencil: false,
            depth: true 
          }}
          // 2. Gunakan mode 'demand' jika animasi tidak terlalu kompleks (opsional)
          // frameloop="demand" 
        >
          <ambientLight intensity={0.5} />
          <NeuralBackground3D /> 
          <TrackballControls noZoom noPan />
        </Canvas>
      </motion.div>

      {/* LAPISAN DEPAN: KONTEN TEKS */}
      <div style={{ position: 'relative', zIndex: 1, pointerEvents: 'none' }}>
        
        {/* SECTION 1: HERO */}
        <motion.div style={sectionStyle} initial="hidden" whileInView="visible" viewport={{ once: false, amount: 0.5 }} variants={fadeUp}>
          <div style={textContainerStyle}>
            <h1 style={{ fontSize: 'clamp(40px, 8vw, 64px)', margin: '0 0 10px 0', letterSpacing: '-2px', fontWeight: '800' }}>Omni AI Node</h1>
            <p style={{ fontSize: 'clamp(16px, 4vw, 20px)', color: '#cbd5e1', maxWidth: '600px', lineHeight: '1.6' }}>
              Platform Kecerdasan Buatan Terpadu. Menggabungkan model bahasa besar, pemrosesan citra saraf, dan kendali berbasis gestur dalam satu antarmuka mulus.
            </p>
            <p style={{ marginTop: '40px', fontSize: '14px', color: '#94a3b8', animation: 'bounce 2s infinite' }}>
              ↓ Gulir ke bawah untuk menjelajah ↓
            </p>
          </div>
        </motion.div>

        {/* SECTION 2: NEURAL VISION */}
        <motion.div style={sectionStyle} initial="hidden" whileInView="visible" viewport={{ once: false, amount: 0.5 }} variants={fadeUp}>
          <div style={textContainerStyle}>
            <Camera size={64} color="#10b981" style={{ marginBottom: '15px', filter: 'drop-shadow(0px 0px 10px rgba(16,185,129,0.5))' }} />
            <h2 style={{ fontSize: 'clamp(28px, 6vw, 42px)', margin: '0 0 10px 0', fontWeight: '700' }}>Mata yang Mampu Memahami</h2>
            <p style={{ fontSize: 'clamp(16px, 4vw, 20px)', color: '#cbd5e1', maxWidth: '600px', lineHeight: '1.6' }}>
              Didukung oleh <strong style={{ color: '#10b981' }}>YOLOv8</strong>. Sistem kami mendeteksi objek, membaca gestur tangan, dan menganalisis wajah secara real-time langsung dari peramban Anda.
            </p>
          </div>
        </motion.div>

        {/* SECTION 3: CREATIVE STUDIO */}
        <motion.div style={sectionStyle} initial="hidden" whileInView="visible" viewport={{ once: false, amount: 0.5 }} variants={fadeUp}>
          <div style={textContainerStyle}>
            <Layers3 size={64} color="#f59e0b" style={{ marginBottom: '15px', filter: 'drop-shadow(0px 0px 10px rgba(245,158,11,0.5))' }} />
            <h2 style={{ fontSize: 'clamp(28px, 6vw, 42px)', margin: '0 0 10px 0', fontWeight: '700' }}>Manipulasi Realitas</h2>
            <p style={{ fontSize: 'clamp(16px, 4vw, 20px)', color: '#cbd5e1', maxWidth: '600px', lineHeight: '1.6' }}>
              Dari <em>Virtual Background</em> tanpa layar hijau hingga pertukaran wajah presisi tinggi menggunakan model <em>InsightFace</em>. Batasnya hanya imajinasi Anda.
            </p>
          </div>
        </motion.div>

        {/* SECTION 4: CALL TO ACTION (CTA) */}
        <motion.div style={sectionStyle} initial="hidden" whileInView="visible" viewport={{ once: false, amount: 0.5 }} variants={fadeUp}>
          <div style={textContainerStyle}>
            <Sparkles size={64} color="#8b5cf6" style={{ marginBottom: '15px', filter: 'drop-shadow(0px 0px 10px rgba(139,92,246,0.5))' }} />
            <h2 style={{ fontSize: 'clamp(28px, 6vw, 42px)', margin: '0 0 20px 0', fontWeight: '700' }}>Siap Memulai?</h2>
            <button 
              onClick={onEnter}
              style={{
                display: 'flex', alignItems: 'center', gap: '10px', padding: '15px 40px', 
                backgroundColor: '#2563eb', color: 'white', border: 'none', borderRadius: '30px', 
                fontSize: '20px', fontWeight: 'bold', cursor: 'pointer', transition: '0.3s',
                boxShadow: '0px 10px 30px rgba(37, 99, 235, 0.4)'
              }}
              onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#1d4ed8'}
              onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#2563eb'}
            >
              Masuk ke Portal Omni <ArrowRight size={24} />
            </button>
          </div>
        </motion.div>

      </div>

      <style>
        {`
          @keyframes bounce {
            0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
            40% { transform: translateY(-10px); }
            60% { transform: translateY(-5px); }
          }
        `}
      </style>
    </div>
  );
}

export default LandingPage;