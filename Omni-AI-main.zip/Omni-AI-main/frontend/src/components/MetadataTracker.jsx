import React, { useState } from 'react';
import { Focus, Loader2, MapPin, Camera, Clock, ShieldCheck } from 'lucide-react';
import axios from 'axios';
import { scrollArea, visionCard, visionCardHeader, actionBtn } from '../styles/themeStyles';
import toast from 'react-hot-toast';

function MetadataTracker({ theme }) {
  const [previewUrl, setPreviewUrl] = useState(null);
  const [metadata, setMetadata] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // --- TAMBAHAN URL BASE SEPERTI DI FACE ANALYTICS ---
  const API_BASE_TUNNEL = "https://mtztf49c-8000.asse.devtunnels.ms";
  const API_BASE_LOCAL = "http://localhost:8000";
  
  // Gunakan LOCAL untuk upload agar super cepat saat testing di laptop
  // Jika nanti diakses dari HP, kamu bisa ganti ini ke API_BASE_TUNNEL
  const CURRENT_API = API_BASE_LOCAL; 

  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setPreviewUrl(URL.createObjectURL(file));
    setIsLoading(true);
    setMetadata(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      // --- MENGGUNAKAN CURRENT_API DI SINI ---
      const res = await axios.post(`${CURRENT_API}/api/metadata`, formData, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('omni_token')}` }
      });

      if (res.data.status === 'success') {
        setMetadata(res.data.data);
        toast.success("Metadata berhasil dilacak!");
      } else {
        toast.error(res.data.message);
      }
    } catch (error) {
      toast.error("Gagal terhubung ke server. Pastikan backend lokal berjalan.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={scrollArea}>
      <div style={{ maxWidth: '800px', margin: '0 auto', padding: '30px' }}>
        <div style={{...visionCard, backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`}}>
          <div style={visionCardHeader}>
            <Focus size={24} color={theme.accent}/>
            <div>
              <h3 style={{color: theme.text, margin: 0}}>Omni Metadata Tracker</h3>
              <p style={{color: theme.subText, fontSize: '13px', margin: '2px 0 0 0'}}>Lacak GPS, Kamera, dan Waktu asli foto.</p>
            </div>
          </div>

          <input type="file" id="metaUpload" hidden onChange={handleFileChange} />
          <button 
            onClick={() => document.getElementById('metaUpload').click()} 
            style={{...actionBtn(false, theme), width: '100%', marginBottom: '20px', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '10px'}}
          >
            {isLoading ? <><Loader2 className="animate-spin" /> Menganalisis File...</> : "Pilih Foto untuk Dilacak"}
          </button>

          {metadata && (
            <div style={{ display: 'grid', gap: '15px', marginTop: '10px' }}>
                <InfoRow icon={<Camera />} label="Device" value={`${metadata.Make || '-'} ${metadata.Model || ''}`} theme={theme} />
                <InfoRow icon={<Clock />} label="Waktu Asli" value={metadata.DateTime || 'Tidak diketahui'} theme={theme} />
                
                {/* TAMPILAN MINI MAP INTERAKTIF */}
                {metadata.lat && metadata.lon ? (
                  <div style={{ 
                    marginTop: '5px', 
                    borderRadius: '12px', 
                    overflow: 'hidden', 
                    border: `1px solid ${theme.border}`,
                    backgroundColor: theme.bg
                  }}>
                    {/* Header Peta */}
                    <div style={{ padding: '10px 15px', borderBottom: `1px solid ${theme.border}`, display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <MapPin size={16} color="#ef4444" />
                      <span style={{ fontSize: '13px', fontWeight: 'bold', color: theme.text }}>Titik Lokasi Pengambilan Foto</span>
                    </div>
                    
                    {/* Iframe Google Maps */}
                    <iframe
                        width="100%"
                        height="250"
                        frameBorder="0"
                        scrolling="no"
                        marginHeight="0"
                        marginWidth="0"
                        src={`https://maps.google.com/maps?q=${metadata.lat},${metadata.lon}&z=16&output=embed`}
                        style={{ display: 'block', pointerEvents: 'auto' }}
                        title="Lokasi Foto"
                        ></iframe>

                    {/* Tombol Buka di Google Maps Asli */}
                    <a 
                      href={metadata.maps_url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      style={{ 
                        display: 'block', 
                        textAlign: 'center', 
                        padding: '12px', 
                        backgroundColor: theme.accent, 
                        color: 'white', 
                        textDecoration: 'none', 
                        fontWeight: 'bold',
                        fontSize: '14px',
                        transition: 'filter 0.2s'
                      }}
                      onMouseOver={(e) => e.currentTarget.style.filter = 'brightness(1.1)'}
                      onMouseOut={(e) => e.currentTarget.style.filter = 'brightness(1)'}
                    >
                      Buka di Aplikasi Google Maps →
                    </a>
                  </div>
                ) : (
                  <InfoRow icon={<MapPin />} label="GPS Data" value="Tidak ada lokasi" theme={theme} />
                )}

              {/* PRIVACY SUGGESTION */}
              <div style={{ 
                padding: '15px', 
                backgroundColor: theme.bg, 
                borderRadius: '10px', 
                borderLeft: `4px solid ${metadata.lat ? '#ef4444' : '#10b981'}` 
              }}>
                <div style={{ display: 'flex', gap: '10px', color: theme.text }}>
                  <ShieldCheck size={18} color={metadata.lat ? '#ef4444' : '#10b981'} />
                  <span style={{ fontSize: '13px', fontWeight: 'bold' }}>Privacy Suggestion:</span>
                </div>
                <p style={{ fontSize: '12px', color: theme.subText, marginTop: '5px' }}>
                  {metadata.lat 
                    ? "Foto ini mengandung koordinat GPS yang sangat presisi. Sebaiknya hapus metadata sebelum mengunggahnya ke ruang publik untuk menjaga privasi Anda." 
                    : "Foto ini aman dari pelacakan lokasi. Tidak ada data koordinat GPS yang ditemukan di dalam file."}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function InfoRow({ icon, label, value, theme }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '15px', padding: '15px', backgroundColor: theme.bg, borderRadius: '10px', border: `1px solid ${theme.border}` }}>
      <div style={{ color: theme.accent }}>{icon}</div>
      <div>
        <div style={{ fontSize: '11px', color: theme.subText, fontWeight: 'bold' }}>{label}</div>
        <div style={{ fontSize: '14px', color: theme.text, fontWeight: '500' }}>{value}</div>
      </div>
    </div>
  );
}

export default MetadataTracker;