import React, { useState, useRef } from 'react';
import { Image as ImageIcon, Loader2, Download, Trash2, Contrast } from 'lucide-react';
import { scrollArea, visionCard, visionCardHeader, actionBtn } from '../styles/themeStyles';
import toast from 'react-hot-toast';

function Monochromatic({ theme }) {
  const [originalImage, setOriginalImage] = useState(null);
  const [monoImage, setMonoImage] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef(null);
  const canvasRef = useRef(null);

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file && file.type.startsWith('image/')) {
      setIsLoading(true);
      setMonoImage(null); 
      
      const reader = new FileReader();
      reader.onload = (e) => {
        setOriginalImage(e.target.result);
        processToMonochrome(e.target.result);
      };
      reader.readAsDataURL(file);
    } else {
      toast.error("Mohon unggah file gambar yang valid.");
    }
  };

  const processToMonochrome = (imageSrc) => {
    const img = new Image();
    img.onload = () => {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');

      canvas.width = img.width;
      canvas.height = img.height;

      ctx.drawImage(img, 0, 0);

      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imageData.data;

      // Logika Grayscale menggunakan rumus Luminositas
      for (let i = 0; i < data.length; i += 4) {
        const gray = 0.2126 * data[i] + 0.7152 * data[i + 1] + 0.0722 * data[i + 2];
        data[i] = gray;     // Red
        data[i + 1] = gray; // Green
        data[i + 2] = gray; // Blue
      }

      ctx.putImageData(imageData, 0, 0);
      setMonoImage(canvas.toDataURL('image/png'));
      setIsLoading(false);
      toast.success("Filter Classic diterapkan!");
    };
    img.src = imageSrc;
  };

  const handleClear = () => {
    setOriginalImage(null);
    setMonoImage(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div style={scrollArea}>
      <div style={{ maxWidth: '900px', margin: '0 auto', padding: '30px' }}>
        <div style={{...visionCard, backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`}}>
          
          <div style={visionCardHeader}>
            <Contrast size={24} color={theme.accent}/>
            <div>
              <h3 style={{fontSize: '18px', margin: 0, color: theme.text}}>Classic Monochrome</h3>
              <p style={{fontSize: '13px', color: theme.subText, margin: '2px 0 0 0'}}>Ubah gambar Anda menjadi karya seni hitam putih yang elegan secara instan.</p>
            </div>
          </div>

          <div style={{ padding: '20px 0', display: 'flex', flexDirection: 'column', gap: '20px', alignItems: 'center' }}>
            
            <input 
              type="file" 
              accept="image/*" 
              ref={fileInputRef} 
              onChange={handleFileChange} 
              style={{ display: 'none' }} 
            />

            {!originalImage ? (
              <button 
                onClick={() => fileInputRef.current.click()}
                style={{
                  ...actionBtn(false, theme), backgroundColor: theme.accent,
                  padding: '15px 30px', borderRadius: '50px', display: 'flex', gap: '10px', fontWeight: 'bold'
                }}
              >
                <ImageIcon size={20} /> Unggah Gambar
              </button>
            ) : (
              <button 
                onClick={handleClear}
                style={{
                  ...actionBtn(false, theme), backgroundColor: 'transparent', border: `2px solid #ef4444`, color: '#ef4444',
                  padding: '10px 20px', display: 'flex', gap: '8px', fontWeight: 'bold'
                }}
              >
                <Trash2 size={18} /> Ganti Gambar
              </button>
            )}

            {(originalImage || isLoading) && (
              <div style={{ width: '100%', display: 'flex', gap: '20px', flexWrap: 'wrap', animation: 'fadeIn 0.5s ease' }}>
                
                <div style={{ flex: 1, minWidth: '300px', padding: '15px', borderRadius: '10px', backgroundColor: theme.bg, border: `1px solid ${theme.border}` }}>
                  <span style={{ fontSize: '13px', color: theme.subText, marginBottom: '10px', display: 'block' }}>Asli:</span>
                  <img src={originalImage} alt="Original" style={{ width: '100%', maxHeight: '400px', objectFit: 'contain', borderRadius: '8px' }} />
                </div>

                <div style={{ flex: 1, minWidth: '300px', padding: '15px', borderRadius: '10px', backgroundColor: theme.bg, border: `1px solid ${theme.border}`, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                  <span style={{ fontSize: '13px', color: theme.text, fontWeight: 'bold', marginBottom: '10px', display: 'block', width: '100%' }}>Hasil (Client-Side):</span>
                  
                  {isLoading ? (
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '10px', color: theme.subText }}>
                      <Loader2 className="animate-spin" size={30} />
                      <span>Memproses...</span>
                    </div>
                  ) : monoImage && (
                    <>
                      <img src={monoImage} alt="Monochrome" style={{ width: '100%', maxHeight: '400px', objectFit: 'contain', borderRadius: '8px', marginBottom: '15px' }} />
                      
                      <a 
                        href={monoImage} 
                        download="Omni_Monochrome.png"
                        style={{
                          ...actionBtn(false, theme), textDecoration: 'none', display: 'flex', justifyContent: 'center', gap: '8px',
                          backgroundColor: '#10b981', color: 'white', padding: '12px 20px', fontWeight: 'bold', width: '100%'
                        }}
                      >
                        <Download size={18} /> Simpan Gambar (Gratis)
                      </a>
                    </>
                  )}
                </div>
              </div>
            )}

            <canvas ref={canvasRef} style={{ display: 'none' }} />

          </div>
        </div>
      </div>
    </div>
  );
}

export default Monochromatic;