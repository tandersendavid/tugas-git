import React, { useState, useEffect } from 'react';
import { Camera, Power } from 'lucide-react';
import axios from 'axios';
import { 
  scrollArea, visionCard, visionCardHeader, 
  videoStreamWrapper, videoStreamImg, visionDisclaimer, actionBtn
} from '../styles/themeStyles';
import toast from 'react-hot-toast';

function NeuralVision({ theme }) {
  const [isStreamActive, setIsStreamActive] = useState(false);

  // URL Backend
  const API_BASE_TUNNEL = "https://mtztf49c-8000.asse.devtunnels.ms";
  const API_BASE_LOCAL = "http://localhost:8000";

  // LOGIKA AUTO-CLEANUP: Saat user pindah tab, otomatis matikan kamera backend
  useEffect(() => {
    return () => {
      axios.post(`${API_BASE_TUNNEL}/api/vision/stop`, {}, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('omni_token')}` }
      }).catch(() => {});
    };
  }, []);

  const toggleStream = async () => {
    const token = localStorage.getItem('omni_token');

    if (isStreamActive) {
      setIsStreamActive(false);
      try {
        await axios.post(`${API_BASE_TUNNEL}/api/vision/stop`, {}, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
      } catch (e) {
        console.error("Gagal menghentikan stream YOLO");
      }
    } else {
      // Validasi Token sebelum memulai
      if (!token) {
        toast.error("Silakan login kembali.");
        return;
      }
      setIsStreamActive(true);
      toast.success("Memulai Deteksi YOLOv8 (Biaya: 5 Kredit)");
    }
  };

  return (
    <div style={scrollArea}>
      <div style={visionContainerStyle}>
        <div style={{...visionCard, backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`}}>
          
          <div style={visionCardHeader}>
            <Camera size={24} color={theme.accent}/>
            <div>
              <h3 style={{fontSize: '18px', margin: 0, color: theme.text}}>Neural Vision Stream</h3>
              <p style={{fontSize: '13px', color: theme.subText, margin: '2px 0 0 0'}}>Real-time object detection powered by YOLOv8.</p>
            </div>
          </div>
          
          <div style={{...videoStreamWrapper, border: `2px solid ${isStreamActive ? '#10b981' : theme.border}`, backgroundColor: '#000', display: 'flex', justifyContent: 'center', alignItems: 'center', overflow: 'hidden', borderRadius: '12px'}}>
            {isStreamActive ? (
              /* MENYISIPKAN TOKEN LEWAT URL UNTUK VALIDASI KREDIT STREAMING */
              <img 
                src={`${API_BASE_LOCAL}/api/vision/stream?token=${localStorage.getItem('omni_token')}`} 
                alt="YOLOv8 Live Stream" 
                style={videoStreamImg}
                onError={() => {
                  toast.error("Gagal memuat stream. Pastikan backend berjalan.");
                  setIsStreamActive(false);
                }}
              />
            ) : (
              <div style={{ color: 'white', textAlign: 'center', padding: '50px' }}>
                <Power size={48} color="#ef4444" style={{ marginBottom: '10px' }}/>
                <p>Kamera Dijeda.<br/>RAM & CPU Aman.</p>
              </div>
            )}
          </div>

          <button 
            onClick={toggleStream} 
            style={{...actionBtn(false, theme), backgroundColor: isStreamActive ? '#ef4444' : '#10b981', width: '100%', marginTop: '20px', padding: '14px', fontWeight: 'bold'}}
          >
            <Power size={18} style={{marginRight: '8px'}}/> 
            {isStreamActive ? "Matikan AI & Kamera" : "Mulai Deteksi AI (5 Kredit)"}
          </button>
          
          <p style={visionDisclaimer}>Omni Node v3. Model: yolov8n.pt. Inference runs locally.</p>
        </div>
      </div>
    </div>
  );
}

const visionContainerStyle = { maxWidth: '800px', margin: '0 auto', padding: '30px', display: 'flex', justifyContent: 'center' };
export default NeuralVision;