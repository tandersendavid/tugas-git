import React, { useState } from 'react';
import { ScanSearch, Loader2, Image as ImageIcon, Cpu, Languages, HelpCircle } from 'lucide-react';
import axios from 'axios';
import { scrollArea, visionCard, visionCardHeader, actionBtn } from '../styles/themeStyles';
import toast from 'react-hot-toast';

function OmniVision({ theme }) {
  const [selectedImage, setSelectedImage] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // Pastikan API_BASE mengarah ke port FastAPI (8000) agar sistem kredit jalan
  const API_BASE = "https://mtztf49c-8000.asse.devtunnels.ms"; 

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Membersihkan memori dari preview sebelumnya (Optimization)
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      
      setSelectedImage(file);
      setPreviewUrl(URL.createObjectURL(file));
      setAnswer(null); // Reset jawaban saat ganti gambar
    }
  };

  const handleIdentify = async () => {
    if (!selectedImage || !question) {
      toast.error("Pilih foto dan ketik pertanyaan dulu!");
      return;
    }

    setIsLoading(true);
    setAnswer(null);

    const formData = new FormData();
    formData.append('image', selectedImage);
    formData.append('question', question);

    try {
      // Mengirim request ke endpoint FastAPI dengan header Authorization
      const response = await axios.post(`${API_BASE}/api/vqa`, formData, {
        headers: { 
          'Content-Type': 'multipart/form-data',
          'Authorization': `Bearer ${localStorage.getItem('omni_token')}`
        }
      });

      if (response.data.status === 'success') {
        setAnswer(response.data.answer);
        toast.success("Analisis selesai! (2 Kredit terpotong)");
      } else {
        toast.error("AI gagal menganalisis gambar ini.");
      }
    } catch (error) {
      // Penanganan khusus jika kredit tidak cukup (Status 403)
      if (error.response && error.response.status === 403) {
        toast.error("Kredit tidak cukup! Butuh 2 kredit.");
      } else {
        console.error(error);
        toast.error("Gagal terhubung ke Backend Omni AI.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={scrollArea}>
      <div style={{ maxWidth: '800px', margin: '0 auto', padding: '30px' }}>
        <div style={{...visionCard, backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`}}>
          
          <div style={visionCardHeader}>
            <ScanSearch size={24} color={theme.accent}/>
            <div>
              <h3 style={{fontSize: '18px', margin: 0, color: theme.text}}>Omni Vision Inspector</h3>
              <p style={{fontSize: '13px', color: theme.subText, margin: '2px 0 0 0'}}>Visual Question Answering | ViLT Fine-tuned</p>
            </div>
          </div>

          <div style={{ padding: '20px 0', display: 'flex', flexDirection: 'column', gap: '15px' }}>
            
            {/* AREA UPLOAD GAMBAR */}
            <div 
              onClick={() => document.getElementById('visionUpload').click()}
              style={{
                width: '100%', height: '320px', borderRadius: '12px',
                border: `2px dashed ${theme.border}`, backgroundColor: theme.bg,
                display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center',
                cursor: 'pointer', overflow: 'hidden', transition: 'all 0.3s'
              }}
            >
              {previewUrl ? (
                <img src={previewUrl} alt="Preview" style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
              ) : (
                <>
                  <ImageIcon size={40} color={theme.subText} style={{ marginBottom: '10px' }} />
                  <p style={{ color: theme.subText, fontSize: '14px' }}>Klik untuk upload foto (Benda, Lokasi, dll)</p>
                </>
              )}
              <input id="visionUpload" type="file" hidden onChange={handleImageChange} accept="image/*" />
            </div>

            {/* INPUT PERTANYAAN */}
            <div style={{ position: 'relative', width: '100%' }}>
                <input 
                    type="text"
                    placeholder="Tanya AI: 'What brand is this?', 'What color is the car?'"
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    style={{
                      width: '100%', 
                      boxSizing: 'border-box', // Mencegah input melebar keluar
                      padding: '15px 15px 15px 45px', 
                      borderRadius: '10px',
                      border: `2px solid ${theme.border}`, 
                      backgroundColor: theme.bg,
                      color: theme.text, 
                      outline: 'none', 
                      fontSize: '14px'
                    }}
                />
                <HelpCircle size={18} color={theme.subText} style={{ position: 'absolute', left: '15px', top: '50%', transform: 'translateY(-50%)' }} />
            </div>

            {/* TOMBOL AKSI */}
            <button 
              onClick={handleIdentify}
              disabled={isLoading || !selectedImage || !question}
              style={{
                ...actionBtn(false, theme), 
                backgroundColor: theme.accent,
                width: '100%', 
                padding: '14px', 
                opacity: (isLoading || !selectedImage || !question) ? 0.6 : 1,
                cursor: (isLoading || !selectedImage || !question) ? 'not-allowed' : 'pointer',
                display: 'flex', 
                justifyContent: 'center', 
                alignItems: 'center', 
                gap: '10px',
                fontWeight: 'bold'
              }}
            >
              {isLoading ? (
                <>
                  <Loader2 className="animate-spin" size={20} /> 
                  <span>Menganalisis...</span>
                </>
              ) : (
                <>
                  <Cpu size={20} /> 
                  <span>Mulai Identifikasi (2 Kredit)</span>
                </>
              )}
            </button>
          </div>

          {/* AREA HASIL RESPONS AI */}
          {answer && (
            <div style={{ 
              marginTop: '10px', padding: '25px', borderRadius: '12px', 
              backgroundColor: theme.bg, border: `1px solid ${theme.border}`,
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '15px', 
              animation: 'fadeIn 0.5s ease', borderLeft: `5px solid ${theme.accent}`
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', width: '100%' }}>
                <Languages size={18} color={theme.accent} />
                <span style={{ fontSize: '12px', fontWeight: 'bold', color: theme.subText }}>AI RESPONSE:</span>
              </div>
              
              <h2 style={{ 
                fontSize: '32px', margin: '5px 0', color: theme.text, 
                textTransform: 'uppercase', letterSpacing: '1px', fontWeight: '900', textAlign: 'center'
              }}>
                {answer}
              </h2>

              <p style={{ fontSize: '13px', color: theme.subText, fontStyle: 'italic' }}>
                Berdasarkan analisis visual mendalam terhadap foto yang diunggah.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default OmniVision;