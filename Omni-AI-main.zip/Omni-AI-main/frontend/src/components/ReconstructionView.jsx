import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Environment } from '@react-three/drei';
import { UploadCloud, Layers3, Loader2, Sparkles, Box, Layout, Download, Move, Zap } from 'lucide-react';
import * as THREE from 'three';
import axios from 'axios';
import { 
  scrollArea, visionCard, visionCardHeader, swapContainer, uploadGrid, 
  uploadBox, previewImg, actionBtn 
} from '../styles/themeStyles';
import toast from 'react-hot-toast';

// --- OBJEK GLOBAL UNTUK OPTIMASI PERFORMANCE ---
const tempObject = new THREE.Object3D();
const tempColor = new THREE.Color();

function SolidSurface({ data, viewMode, forceRadius, forceIntensity }) {
  const meshRef = useRef();
  const numInstances = data.length;

  const [targets3D, targets2D, colors] = useMemo(() => {
    const t3D = new Float32Array(numInstances * 3);
    const t2D = new Float32Array(numInstances * 3);
    const cols = new Float32Array(numInstances * 3);

    data.forEach((p, i) => {
      t3D[i * 3] = p.x; t3D[i * 3 + 1] = p.y; t3D[i * 3 + 2] = p.z;
      t2D[i * 3] = p.x; t2D[i * 3 + 1] = p.y; t2D[i * 3 + 2] = 0;
      cols[i * 3] = p.r / 255; cols[i * 3 + 1] = p.g / 255; cols[i * 3 + 2] = p.b / 255;
    });
    return [t3D, t2D, cols];
  }, [data]);

  useEffect(() => {
    if (meshRef.current) {
      for (let i = 0; i < numInstances; i++) {
        tempObject.position.set((Math.random() - 0.5) * 40, (Math.random() - 0.5) * 40, (Math.random() - 0.5) * 40);
        tempObject.updateMatrix();
        meshRef.current.setMatrixAt(i, tempObject.matrix);
        tempColor.setRGB(colors[i * 3], colors[i * 3 + 1], colors[i * 3 + 2]);
        meshRef.current.setColorAt(i, tempColor);
      }
      meshRef.current.instanceMatrix.needsUpdate = true;
      if (meshRef.current.instanceColor) meshRef.current.instanceColor.needsUpdate = true;
    }
  }, [data, colors, numInstances]);

  useFrame((state) => {
    if (meshRef.current) {
      const activeTarget = viewMode === '3d' ? targets3D : targets2D;
      const { mouse, viewport } = state;
      const mouseX = (mouse.x * viewport.width) / 2;
      const mouseY = (mouse.y * viewport.height) / 2;

      for (let i = 0; i < numInstances; i++) {
        meshRef.current.getMatrixAt(i, tempObject.matrix);
        tempObject.matrix.decompose(tempObject.position, tempObject.quaternion, tempObject.scale);
        
        const dx = tempObject.position.x - mouseX;
        const dy = tempObject.position.y - mouseY;
        const distance = Math.sqrt(dx * dx + dy * dy);

        let tx = activeTarget[i * 3];
        let ty = activeTarget[i * 3 + 1];
        let tz = activeTarget[i * 3 + 2];

        if (distance < forceRadius) {
          const force = (forceRadius - distance) / forceRadius;
          tx += dx * force * forceIntensity; 
          ty += dy * force * forceIntensity;
          tz += force * (forceIntensity * 0.5);
        }

        tempObject.position.x += (tx - tempObject.position.x) * 0.08;
        tempObject.position.y += (ty - tempObject.position.y) * 0.08;
        tempObject.position.z += (tz - tempObject.position.z) * 0.08;
        
        tempObject.updateMatrix();
        meshRef.current.setMatrixAt(i, tempObject.matrix);
      }
      meshRef.current.instanceMatrix.needsUpdate = true;
    }
  });

  return (
    <instancedMesh ref={meshRef} args={[null, null, numInstances]} castShadow receiveShadow>
      <boxGeometry args={[0.051, 0.051, 0.051]} />
      <meshStandardMaterial roughness={0.4} metalness={0.1} />
    </instancedMesh>
  );
}

function ReconstructionView({ theme }) {
  const [sourceImg, setSourceImg] = useState(null);
  const [targetImg, setTargetImg] = useState(null);
  const [sourcePreview, setSourcePreview] = useState(null);
  const [targetPreview, setTargetPreview] = useState(null);
  const [data, setData] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [viewMode, setViewMode] = useState('3d'); 
  const [errorMsg, setErrorMsg] = useState('');
  const [forceIntensity, setForceIntensity] = useState(5);
  const [forceRadius, setForceRadius] = useState(2.5); 

  const API_BASE = "https://mtztf49c-8000.asse.devtunnels.ms";

  const handleImageChange = (e, type) => {
    const file = e.target.files[0];
    if (!file) return;
    const previewUrl = URL.createObjectURL(file);
    if (type === 'source') {
      if (sourcePreview) URL.revokeObjectURL(sourcePreview);
      setSourceImg(file);
      setSourcePreview(previewUrl);
    } else {
      if (targetPreview) URL.revokeObjectURL(targetPreview);
      setTargetImg(file);
      setTargetPreview(previewUrl);
    }
    setData([]); 
    setErrorMsg('');
  };

  const handleProcess = async () => {
    if (!sourceImg || !targetImg) return;
    setIsProcessing(true);
    setErrorMsg('');
    setData([]);

    const formData = new FormData();
    formData.append('source', sourceImg);
    formData.append('target', targetImg);

    try {
      const res = await axios.post(`${API_BASE}/api/reconstruct`, formData, {
        headers: { 
          'Content-Type': 'multipart/form-data',
          'Authorization': `Bearer ${localStorage.getItem('omni_token')}` 
        }
      });
      setData(res.data);
      setViewMode('3d'); 
      toast.success("Rekonstruksi Berhasil! (10 Kredit)");
    } catch (err) {
      if (err.response && err.response.status === 403) {
        setErrorMsg('Kredit tidak cukup! Butuh 10 kredit untuk proses 3D ini.');
        toast.error("Kredit Habis!");
      } else {
        setErrorMsg('Terjadi kesalahan pada server AI.');
      }
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    const canvas = document.querySelector('canvas');
    if (!canvas) return;
    try {
      const dataURL = canvas.toDataURL("image/png");
      const link = document.createElement('a');
      link.download = `Omni_3D_Cloud_${Date.now()}.png`;
      link.href = dataURL;
      link.click();
    } catch (err) {
      toast.error("Gagal menyimpan gambar.");
    }
  };

  return (
    <div style={scrollArea}>
      <div style={swapContainer}>
        <div style={{...visionCard, backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`}}>
          <div style={visionCardHeader}>
            <Layers3 size={24} color={theme.accent}/>
            <div>
              <h3 style={{fontSize: '18px', margin: 0, color: theme.text}}>Neural Reconstruction</h3>
              <p style={{fontSize: '13px', color: theme.subText, margin: '2px 0 0 0'}}>3D Depth Estimation | AI Solid Mosaic</p>
            </div>
          </div>

          <div style={uploadGrid}>
            <label style={uploadBox(theme)}>
              <input type="file" accept="image/*" onChange={(e) => handleImageChange(e, 'source')} style={{ display: 'none' }} />
              {sourcePreview ? <img src={sourcePreview} alt="Source" style={previewImg} /> : (
                <div style={{textAlign: 'center'}}>
                  <UploadCloud size={32} color={theme.subText} style={{ marginBottom: '10px' }}/>
                  <span style={{ fontSize: '14px', color: theme.text, display: 'block' }}>Penyedia Warna</span>
                </div>
              )}
            </label>

            <label style={uploadBox(theme)}>
              <input type="file" accept="image/*" onChange={(e) => handleImageChange(e, 'target')} style={{ display: 'none' }} />
              {targetPreview ? <img src={targetPreview} alt="Target" style={previewImg} /> : (
                <div style={{textAlign: 'center'}}>
                  <UploadCloud size={32} color={theme.subText} style={{ marginBottom: '10px' }}/>
                  <span style={{ fontSize: '14px', color: theme.text, display: 'block' }}>Penyedia Bentuk</span>
                </div>
              )}
            </label>
          </div>

          {errorMsg && (
            <div style={{ backgroundColor: '#fee2e2', color: '#ef4444', padding: '10px', borderRadius: '8px', marginTop: '15px', fontSize: '12px', textAlign: 'center' }}>
              {errorMsg}
            </div>
          )}

          <button 
            onClick={handleProcess} 
            disabled={!sourceImg || !targetImg || isProcessing} 
            style={{ ...actionBtn(!sourceImg || !targetImg || isProcessing, theme), marginTop: '20px', padding: '14px' }}
          >
            {isProcessing ? <><Loader2 size={18} className="animate-spin"/> Menghitung Sumbu Z...</> : <><Sparkles size={18}/> Mulai Rekonstruksi (10 Kredit)</>}
          </button>

          {data.length > 0 && (
            <div style={{ marginTop: '30px', width: '100%', height: '550px', backgroundColor: '#000', borderRadius: '12px', overflow: 'hidden', border: `1px solid ${theme.border}`, position: 'relative' }}>
              <div style={{ position: 'absolute', top: '15px', right: '15px', zIndex: 10, display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <div style={{ display: 'flex', gap: '8px', backgroundColor: 'rgba(0,0,0,0.8)', padding: '6px', borderRadius: '10px' }}>
                  <button onClick={handleDownload} style={{ padding: '6px 12px', borderRadius: '6px', border: 'none', cursor: 'pointer', backgroundColor: 'rgba(255,255,255,0.1)', color: 'white' }}><Download size={14}/></button>
                  <button onClick={() => setViewMode('2d')} style={{ padding: '6px 12px', borderRadius: '6px', border: 'none', cursor: 'pointer', fontSize: '11px', backgroundColor: viewMode === '2d' ? theme.accent : 'transparent', color: 'white' }}><Layout size={14}/> 2D</button>
                  <button onClick={() => setViewMode('3d')} style={{ padding: '6px 12px', borderRadius: '6px', border: 'none', cursor: 'pointer', fontSize: '11px', backgroundColor: viewMode === '3d' ? theme.accent : 'transparent', color: 'white' }}><Box size={14}/> 3D</button>
                </div>

                <div style={{ backgroundColor: 'rgba(0,0,0,0.8)', padding: '12px', borderRadius: '10px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <Move size={14} color={theme.subText}/>
                    <input type="range" min="0.5" max="8" step="0.1" value={forceRadius} onChange={(e) => setForceRadius(parseFloat(e.target.value))} style={{ flex: 1, accentColor: theme.accent }} />
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <Zap size={14} color={theme.subText}/>
                    <input type="range" min="1" max="20" step="0.5" value={forceIntensity} onChange={(e) => setForceIntensity(parseFloat(e.target.value))} style={{ flex: 1, accentColor: theme.accent }} />
                  </div>
                </div>
              </div>

              <Canvas shadows gl={{ preserveDrawingBuffer: true }} camera={{ position: [0, 0, 15], fov: 45 }}>
                <color attach="background" args={['#010409']} />
                <ambientLight intensity={0.7} />
                <directionalLight position={[10, 15, 5]} intensity={1.5} />
                <SolidSurface data={data} viewMode={viewMode} forceRadius={forceRadius} forceIntensity={forceIntensity} />
                <OrbitControls makeDefault />
              </Canvas>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default ReconstructionView;