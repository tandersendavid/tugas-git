import React, { useState } from 'react';
import { 
  MessageSquare, Camera, Sparkles, Plus, History, Trash2, Sun, Moon, 
  Image as ImageIcon, Layers3, X, UserCheck, Hand, Maximize, Focus, 
  Palette, Eraser, Share2, ChevronDown, ChevronRight, Video, Youtube, Instagram, Volume2, LogOut, BarChart3, Lock
} from 'lucide-react';
import axios from 'axios';
import { 
  sidebarStyle, logoArea, logoIcon, logoText, 
  newChatBtn, historySection, historyLabel, clearBtn, historyList, 
  historyItem, singleDeleteBtn, themeToggleStyle 
} from '../styles/themeStyles';



function Sidebar({ 
  theme, activeTab, setActiveTab, allSessions, sessionId, 
  startNewChat, loadSession, clearAllHistory, deleteSingleSession, 
  hoveredSessionId, setHoveredSessionId, isDarkMode, setIsDarkMode,
  isSidebarOpen, setIsSidebarOpen, handleLogout, username
}) {
  // State untuk mengontrol buka-tutup dropdown Social Tools
  const [isSocialOpen, setIsSocialOpen] = useState(false);
  const userRole = localStorage.getItem('omni_role') || 'user';
  const [credits, setCredits] = useState(0);

  // Helper fungsi untuk gaya item navigasi (biar konsisten)
  const getNavItemStyle = (isActive, isSubItem = false) => ({
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    padding: isSubItem ? '10px 15px 10px 45px' : '12px 15px',
    borderRadius: '10px',
    cursor: 'pointer',
    marginBottom: '5px',
    backgroundColor: isActive ? theme.accent + '20' : 'transparent',
    color: isActive ? theme.accent : theme.text,
    transition: 'all 0.3s ease',
    fontSize: isSubItem ? '13px' : '14px',
    fontWeight: isActive ? '600' : '400',
  });

  React.useEffect(() => {
    const fetchUserData = async () => {
      try {
        const token = localStorage.getItem('omni_token');
        if (!token) return;

        const res = await axios.get('https://mtztf49c-8000.asse.devtunnels.ms/api/user/me', {
          headers: { Authorization: `Bearer ${token}` }
        });
        setCredits(res.data.credits);
      } catch (err) {
        console.error("Gagal sinkronisasi kredit");
      }
    };

    fetchUserData();
    // Refresh otomatis setiap 1 menit agar saldo tetap sinkron
    const interval = setInterval(fetchUserData, 60000);
    return () => clearInterval(interval);
  }, []);

  return (
    <aside className={`omni-sidebar ${isSidebarOpen ? 'open' : ''}`} style={{ ...sidebarStyle, backgroundColor: theme.sidebar, borderRight: `1px solid ${theme.border}`, display: 'flex', flexDirection: 'column' }}>
      
      {/* LOGO & CLOSE BUTTON */}
      <div style={{ ...logoArea, justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <div style={logoIcon}><Sparkles size={18} color="white"/></div>
          <span style={{ ...logoText, color: theme.text }}>Omni AI</span>
        </div>
        <button className="close-sidebar-btn" onClick={() => setIsSidebarOpen(false)} style={{ background: 'none', border: 'none', color: theme.text, cursor: 'pointer' }}>
          <X size={24} />
        </button>
      </div>


      {/* MAIN NAVIGATION */}
      <nav className="omni-sidebar-nav" style={{ display: 'flex', flexDirection: 'column', gap: '5px', overflowY: 'auto', flex: 1, paddingBottom: '20px' }}>
        
        {/* Fitur AI Utama */}
        <div onClick={() => { setActiveTab('chat'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'chat')}>
          <MessageSquare size={18}/> <span>AI Chatbot</span>
        </div>
        <div onClick={() => { setActiveTab('vision'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'vision')}>
          <Camera size={18}/> <span>Neural Vision</span>
        </div>
        <div onClick={() => { setActiveTab('swap'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'swap')}>
          <ImageIcon size={18}/> <span>Face Swap AI</span>
        </div>
        <div onClick={() => { setActiveTab('vb'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'vb')}>
          <Layers3 size={18}/> <span>Studio Latar AI</span>
        </div>
        <div onClick={() => { setActiveTab('analytics'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'analytics')}>
          <UserCheck size={18} /> <span>Face Analytics</span>
        </div>
        <div onClick={() => { setActiveTab('gesture'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'gesture')}>
          <Hand size={18} /> <span>Gesture Control</span>
        </div>
        <div onClick={() => { setActiveTab('upscale'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'upscale')}>
          <Maximize size={18} /> <span>Image Upscaler</span>
        </div>
        <div onClick={() => { setActiveTab('unblur'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'unblur')}>
          <Focus size={18} /> <span>Image Unblur</span>
        </div>
        <div onClick={() => { setActiveTab('colorizer'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'colorizer')}>
          <Palette size={18} /> <span>Image Colorizer</span>
        </div>
        <div onClick={() => { setActiveTab('bgremover'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'bgremover')}>
          <Eraser size={18} /> <span>Background Remover</span>
        </div>
        <div onClick={() => { setActiveTab('monochrome'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'monochrome')}>
          <ImageIcon size={18} /> <span>Monochrome Converter</span>
        </div>
        <div onClick={() => { setActiveTab('animagine'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'animagine')}>
          <Sparkles size={18} /> <span>Animagine AI</span>
        </div>
        <div onClick={() => { setActiveTab('deepai'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'deepai')}>
          <Sparkles size={18} /> <span>DeepAI Art</span>
        </div>
        <div onClick={() => { setActiveTab('webscreenshot'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'webscreenshot')}>
          <Camera size={18} /> <span>Web Screenshot</span>
        </div>
        <div onClick={() => { setActiveTab('voicechanger'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'voicechanger')}>
          <Volume2 size={18} /> <span>AI Voice Changer</span>
        </div>
        <div onClick={() => { setActiveTab('reconstruction'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'reconstruction')}>
          <Layers3 size={18} /> <span>3D Reconstruction</span>
        </div>
        <div onClick={() => { setActiveTab('omni_vision'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'omni_vision')}>
          <Camera size={18} /> <span>Omni Vision</span>
        </div>
        <div onClick={() => { setActiveTab('metadata'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'metadata')}>
          <Focus size={18} /> <span>Metadata Tracker</span>
        </div>
        <div onClick={() => { setActiveTab('steganography'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'steganography')}>
          <Lock size={18} /> <span>Steganography</span>
        </div>
        <div onClick={() => { setActiveTab('cryptography'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'cryptography')}>
          <Lock size={18} /> <span>Cryptography</span>
        </div>
        <div onClick={() => { setActiveTab('whac_a_mole'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'whac_a_mole')}>
          <Hand size={18} /> <span>Whac-A-Mole AI</span>
        </div>


        {/* --- DROPDOWN: SOCIAL MEDIA DOWNLOADER --- */}
        <div 
          onClick={() => setIsSocialOpen(!isSocialOpen)} 
          style={{...getNavItemStyle(false), justifyContent: 'space-between'}}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <Share2 size={18} color={theme.accent} />
            <span>Social Downloader</span>
          </div>
          {isSocialOpen ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
        </div>

        {isSocialOpen && (
          <div style={{ paddingLeft: '10px', borderLeft: `1px solid ${theme.border}`, marginLeft: '25px', marginTop: '5px' }}>
            <div onClick={() => { setActiveTab('tiktok'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'tiktok', true)}>
              <Video size={14} /> <span>TikTok (No WM)</span>
            </div>
            <div onClick={() => { setActiveTab('youtube'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'youtube', true)}>
              <Youtube size={14} /> <span>YouTube Video</span>
            </div>
            <div onClick={() => { setActiveTab('instagram'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'instagram', true)}>
              <Instagram size={14} /> <span>Instagram Media</span>
            </div>
            <div onClick={() => { setActiveTab('threads'); setIsSidebarOpen(false); }} style={getNavItemStyle(activeTab === 'threads', true)}>
              <Instagram size={14} /> <span>Threads Media</span>
            </div>
          </div>
        )}
      </nav>

      {/* CHAT HISTORY SECTION (Hanya muncul jika tab Chat aktif) */}
      {activeTab === 'chat' && (
        <div className="omni-history" style={{...historySection, borderTop: `1px solid ${theme.border}`, paddingTop: '15px', marginBottom: '10px'}}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <p style={historyLabel}>HISTORY CHAT</p>
            {allSessions.length > 0 && (
              <button onClick={clearAllHistory} style={clearBtn(theme)} title="Hapus Semua Riwayat">
                <Trash2 size={14}/>
              </button>
            )}
          </div>
          
          <button onClick={startNewChat} style={newChatBtn(theme)}>
            <Plus size={18}/> <span>Chat Baru</span>
          </button>

          {/* AREA LIST HISTORY YANG BISA DI-SCROLL */}
          <div 
            className="history-scroll-area" 
            style={{ 
              ...historyList, 
              maxHeight: '220px', // Mengunci tinggi maksimal agar tidak mendesak ke bawah
              overflowY: 'auto',  // Memunculkan scroll otomatis
              paddingRight: '5px',
              marginTop: '10px'
            }}
          >
            {allSessions.map((s) => (
              <div key={s.id} onClick={() => loadSession(s)} onMouseEnter={() => setHoveredSessionId(s.id)} onMouseLeave={() => setHoveredSessionId(null)}
                style={{...historyItem(theme), backgroundColor: s.id === sessionId ? theme.activeHistory : 'transparent', fontWeight: s.id === sessionId ? '600' : '400', color: s.id === sessionId ? theme.text : theme.subText, borderLeft: s.id === sessionId ? `3px solid ${theme.accent}` : '3px solid transparent'}}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', overflow: 'hidden', flex: 1 }}>
                  <History size={14} color={s.id === sessionId ? theme.accent : theme.subText} style={{ flexShrink: 0 }}/> 
                  <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{s.title}</span>
                </div>
                {hoveredSessionId === s.id && <button onClick={(e) => deleteSingleSession(e, s.id)} style={singleDeleteBtn} title="Hapus riwayat"><Trash2 size={14} color="#ef4444" /></button>}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================== */}
      {/* AREA BAWAH: THEME TOGGLE, PROFIL & LOGOUT    */}
      {/* ========================================== */}
      <div style={{ marginTop: 'auto', borderTop: `1px solid ${theme.border}`, paddingTop: '15px' }}>
        
        {localStorage.getItem('omni_role') === 'admin' && (
          <div style={{ marginBottom: '15px', padding: '0 15px' }}>
            <p style={{ color: '#94a3b8', fontSize: '11px', margin: '0 0 8px 0', letterSpacing: '1px', fontWeight: 'bold' }}>ZONA ADMIN</p>
            
            <div 
              onClick={() => { setActiveTab('admin_stats'); setIsSidebarOpen(false); }} 
              style={getNavItemStyle(activeTab === 'admin_stats')}
            >
              <UserCheck size={16} /> <span>Statistik Server</span>
            </div>
            
            <div 
              onClick={() => { setActiveTab('admin_users'); setIsSidebarOpen(false); }} 
              style={getNavItemStyle(activeTab === 'admin_users')}
            >
              <Layers3 size={16} /> <span>Manajemen Pengguna</span>
            </div>

            <div 
              onClick={() => { setActiveTab('admin_trends'); setIsSidebarOpen(false); }} 
              style={getNavItemStyle(activeTab === 'admin_trends')}
            >
              <BarChart3 size={16} /> <span>Tren Penggunaan</span>
            </div>
          </div>
        )}

        {/* Tombol Tema */}
        <div className="desktop-theme-toggle" onClick={() => setIsDarkMode(!isDarkMode)} style={{...themeToggleStyle(theme), marginBottom: '15px', cursor: 'pointer'}}>
          {isDarkMode ? <Sun size={18} color="#fbbf24"/> : <Moon size={18} color="#2563eb"/>}
          <span>{isDarkMode ? 'Light' : 'Dark'} Mode</span>
        </div>

        {/* Info User */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '0 15px 15px 15px', color: theme.text }}>
          <div style={{ 
            width: '35px', height: '35px', borderRadius: '8px', 
            backgroundColor: theme.accent, display: 'flex', 
            justifyContent: 'center', alignItems: 'center', 
            color: 'white', fontWeight: 'bold', fontSize: '18px' 
          }}>
            {username ? username.charAt(0).toUpperCase() : 'U'}
          </div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <span style={{ fontSize: '14px', fontWeight: 'bold' }}>{username}</span>
            <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
              <span style={{ fontSize: '11px', color: '#10b981' }}>● Online</span>
              <span style={{ fontSize: '11px', color: theme.subText }}>•</span>
              <span style={{ fontSize: '11px', color: theme.accent, fontWeight: 'bold' }}>
                {credits} Credits
              </span>
            </div>
          </div>
        </div>

        {/* Tombol Keluar */}
        <button 
          onClick={handleLogout}
          style={{
            display: 'flex', alignItems: 'center', gap: '10px', width: '100%', 
            padding: '12px 15px', /* <-- Perbaikan di sini */
            backgroundColor: 'transparent', border: 'none', color: '#ef4444', cursor: 'pointer',
            fontWeight: 'bold', fontSize: '14px', transition: '0.2s', textAlign: 'left',
            marginTop: 'auto' /* Opsional: mendorong tombol ini ke bagian paling bawah sidebar */
          }}
          onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#ef444415'}
          onMouseOut={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
        >
          <LogOut size={18} /> Keluar (Log Out)
        </button>

      </div>
      
    </aside>
  );
}

export default Sidebar;