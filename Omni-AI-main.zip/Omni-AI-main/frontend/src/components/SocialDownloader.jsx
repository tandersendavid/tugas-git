import React, { useState, useEffect } from 'react';
import { Download, Link as LinkIcon, Loader2, Video, User, Music, Clock, AlertCircle, ShieldCheck } from 'lucide-react';
import axios from 'axios';
import { scrollArea, visionCard, visionCardHeader, actionBtn } from '../styles/themeStyles';
import toast, { Toaster } from 'react-hot-toast';

function SocialDownloader({ theme, type }) {
  const [url, setUrl] = useState('');
  const [data, setData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // Endpoint Backend (Sesuaikan dengan DevTunnels kamu)
  const API_BASE = "https://mtztf49c-8000.asse.devtunnels.ms";

  const titleMap = {
    tiktok: "TikTok No-WM Downloader",
    youtube: "YouTube Video Downloader",
    instagram: "Instagram Downloader",
    threads: "Threads Downloader"
  };

  // Reset state jika user pindah tab di Sidebar
  useEffect(() => {
    setData(null);
    setUrl('');
  }, [type]);

  const handleSearch = async () => {
    if (!url) return;
    setIsLoading(true);
    setData(null);

    try {
      // PENCARIAN GRATIS: Tidak mengirim header Authorization
      const endpoint = type === 'instagram' ? 'ig' : type;
      const response = await axios.get(`${API_BASE}/api/tools/${endpoint}?url=${encodeURIComponent(url)}`);
      
      if (response.data.status === true || response.data.status === 'success') {
        const res = response.data.result || response.data;
        
        let videoLink = "";
        let coverLink = res.cover || res.thumbnail || "";
        let authorName = res.author?.nickname || res.author || res.channel || "Creator";
        
        // Ekstraksi Link Video Asli dari Vreden API
        if (type === 'tiktok' && res.data && Array.isArray(res.data)) {
          const videoObj = res.data.find(d => d.type === "nowatermark" || d.type === "nowatermark_hd") || res.data[0];
          videoLink = videoObj.url;
        } else if (type === 'youtube') {
          videoLink = res.video_url || res.download?.url || "";
        } else {
          videoLink = res.video_url || res.url || "";
        }

        // Simpan Data ke State
        setData({
          title: res.title || "Video Content",
          author: authorName,
          cover: coverLink, 
          // BERBAYAR: Token disisipkan di URL agar Proxy bisa potong kredit saat diklik
          video_url: videoLink ? `${API_BASE}/api/proxy/download?url=${encodeURIComponent(videoLink)}&token=${localStorage.getItem('omni_token')}` : "",
          music_url: res.music_info?.url || null,
          duration: res.duration || null
        });

        toast.success("Hasil ditemukan! Klik download untuk menyimpan.");
      } else {
        toast.error("Gagal mengambil data. Pastikan link publik.");
      }
    } catch (error) {
      console.error(error);
      toast.error("Server tidak merespon. Cek DevTunnels.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={scrollArea}>
      <Toaster position="top-center" />
      <div style={{ maxWidth: '800px', margin: '0 auto', padding: '30px' }}>
        <div style={{...visionCard, backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`}}>
          
          <div style={visionCardHeader}>
            <div style={{ backgroundColor: theme.accent + '20', padding: '10px', borderRadius: '12px' }}>
              <Video size={24} color={theme.accent}/>
            </div>
            <div>
              <h3 style={{fontSize: '18px', margin: 0, color: theme.text}}>{titleMap[type]}</h3>
              <p style={{fontSize: '13px', color: theme.subText, margin: '2px 0 0 0'}}>Preview gratis, download menggunakan kredit.</p>
            </div>
          </div>

          <div style={{ padding: '20px 0', display: 'flex', flexDirection: 'column', gap: '15px' }}>
            <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
              <LinkIcon size={18} color={theme.subText} style={{ position: 'absolute', left: '15px' }} />
              <input 
                type="text"
                placeholder={`Tempel link ${type} di sini...`}
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                style={{
                  width: '100%', padding: '14px 15px 14px 45px', borderRadius: '12px',
                  border: `2px solid ${theme.border}`, backgroundColor: theme.bg,
                  color: theme.text, outline: 'none', fontSize: '14px', transition: 'all 0.3s'
                }}
              />
            </div>

            <button 
              onClick={handleSearch}
              disabled={isLoading || !url}
              style={{
                ...actionBtn(false, theme), backgroundColor: theme.accent,
                width: '100%', padding: '14px', opacity: (isLoading || !url) ? 0.6 : 1,
                cursor: (isLoading || !url) ? 'not-allowed' : 'pointer',
                display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '10px',
                fontSize: '15px', fontWeight: 'bold'
              }}
            >
              {isLoading ? <Loader2 className="animate-spin" size={20} /> : "Cari Konten"}
            </button>
          </div>

          {data && (
            <div style={{ 
              marginTop: '10px', padding: '20px', borderRadius: '16px', 
              backgroundColor: theme.bg, border: `1px solid ${theme.border}`,
              display: 'flex', gap: '25px', animation: 'fadeIn 0.5s ease', flexWrap: 'wrap'
            }}>
              
              <div style={{ position: 'relative' }}>
                <img 
                  src={data.cover} 
                  alt="Thumbnail"
                  referrerPolicy="no-referrer"
                  style={{ width: '140px', height: '200px', objectFit: 'cover', borderRadius: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.2)' }} 
                />
                {data.duration && (
                  <div style={{ position: 'absolute', bottom: '10px', right: '10px', backgroundColor: 'rgba(0,0,0,0.7)', color: 'white', padding: '2px 6px', borderRadius: '4px', fontSize: '10px', display: 'flex', alignItems: 'center', gap: '4px' }}>
                    <Clock size={10} /> {data.duration}
                  </div>
                )}
              </div>
              
              <div style={{ flex: 1, minWidth: '250px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                <h4 style={{ color: theme.text, margin: '0 0 10px 0', fontSize: '16px', lineHeight: '1.4' }}>{data.title}</h4>
                
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: theme.subText, fontSize: '14px', marginBottom: '25px' }}>
                  <User size={16} /> <span>{data.author}</span>
                  <span style={{ color: theme.border }}>•</span>
                  <ShieldCheck size={16} color="#22c55e" /> <span style={{ color: '#22c55e' }}>Verified Link</span>
                </div>

                <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                  {data.video_url ? (
                    <a 
                      href={data.video_url}
                      target="_blank"
                      rel="noreferrer"
                      style={{
                        ...actionBtn(false, theme), textDecoration: 'none', display: 'flex', gap: '8px',
                        backgroundColor: '#22c55e', color: 'white', padding: '12px 24px', fontWeight: 'bold',
                        boxShadow: '0 4px 14px rgba(34, 197, 94, 0.4)'
                      }}
                    >
                      <Download size={18} /> Simpan Video (3 Kredit)
                    </a>
                  ) : (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#ef4444', fontSize: '13px' }}>
                      <AlertCircle size={18} /> Gagal menghasilkan link download.
                    </div>
                  )}

                  {data.music_url && (
                    <a 
                      href={data.music_url} target="_blank" rel="noreferrer"
                      style={{
                        ...actionBtn(false, theme), textDecoration: 'none', display: 'flex', gap: '8px',
                        border: `1px solid ${theme.border}`, padding: '12px 20px', backgroundColor: 'transparent', color: theme.text
                      }}
                    >
                      <Music size={18} /> Audio Only
                    </a>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default SocialDownloader;