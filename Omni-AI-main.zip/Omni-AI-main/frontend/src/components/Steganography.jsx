import React, { useState } from 'react';
import { Lock, Unlock, Upload, Download, Loader2, ShieldAlert } from 'lucide-react';
import axios from 'axios';
import { scrollArea, visionCard, visionCardHeader, actionBtn } from '../styles/themeStyles';
import toast from 'react-hot-toast';

function Steganography({ theme }) {
  const [mode, setMode] = useState('encode'); // 'encode' atau 'decode'
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  
  // State untuk Encode
  const [secretMessage, setSecretMessage] = useState("");
  const [resultUrl, setResultUrl] = useState(null);
  
  // State untuk Decode
  const [decodedMessage, setDecodedMessage] = useState(null);
  
  const [isLoading, setIsLoading] = useState(false);
  const API_BASE_LOCAL = "http://localhost:8000";

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      setPreviewUrl(URL.createObjectURL(file));
      setResultUrl(null);
      setDecodedMessage(null);
    }
  };

  const handleProcess = async () => {
    if (!selectedFile) return toast.error("Pilih gambar terlebih dahulu!");
    setIsLoading(true);

    const formData = new FormData();
    formData.append(mode === 'encode' ? 'image' : 'image', selectedFile);
    
    try {
      if (mode === 'encode') {
        if (!secretMessage) return toast.error("Tulis pesan rahasianya!");
        formData.append('message', secretMessage);
        
        const res = await axios.post(`${API_BASE_LOCAL}/api/stegano/encode`, formData, {
          responseType: 'blob',
          headers: { 'Authorization': `Bearer ${localStorage.getItem('omni_token')}` }
        });
        
        setResultUrl(URL.createObjectURL(res.data));
        toast.success("Pesan berhasil disembunyikan!");
      } 
      else {
        const res = await axios.post(`${API_BASE_LOCAL}/api/stegano/decode`, formData, {
          headers: { 'Authorization': `Bearer ${localStorage.getItem('omni_token')}` }
        });
        
        if (res.data.status === 'success') {
          setDecodedMessage(res.data.message);
          toast.success("Pesan rahasia ditemukan!");
        } else {
          toast.error(res.data.message);
        }
      }
    } catch (error) {
      toast.error("Gagal memproses gambar.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={scrollArea}>
      <div style={{ maxWidth: '800px', margin: '0 auto', padding: '30px' }}>
        <div style={{...visionCard, backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`}}>
          
          <div style={visionCardHeader}>
            <Lock size={24} color={theme.accent}/>
            <div>
              <h3 style={{fontSize: '18px', margin: 0, color: theme.text}}>Omni Steganography</h3>
              <p style={{fontSize: '13px', color: theme.subText, margin: '2px 0 0 0'}}>Sisipkan pesan rahasia ke dalam piksel gambar (LSB Encryption).</p>
            </div>
          </div>

          {/* Toggle Mode */}
          <div style={{ display: 'flex', gap: '10px', marginTop: '20px' }}>
            <button 
              onClick={() => { setMode('encode'); setSelectedFile(null); setPreviewUrl(null); }}
              style={{ flex: 1, padding: '10px', borderRadius: '8px', border: 'none', cursor: 'pointer', fontWeight: 'bold', backgroundColor: mode === 'encode' ? theme.accent : theme.bg, color: mode === 'encode' ? '#fff' : theme.text }}
            >
              <Lock size={16} style={{ marginRight: '5px' }}/> Sembunyikan Pesan
            </button>
            <button 
              onClick={() => { setMode('decode'); setSelectedFile(null); setPreviewUrl(null); }}
              style={{ flex: 1, padding: '10px', borderRadius: '8px', border: 'none', cursor: 'pointer', fontWeight: 'bold', backgroundColor: mode === 'decode' ? '#10b981' : theme.bg, color: mode === 'decode' ? '#fff' : theme.text }}
            >
              <Unlock size={16} style={{ marginRight: '5px' }}/> Bongkar Pesan
            </button>
          </div>

          <div style={{ marginTop: '20px', display: 'flex', flexDirection: 'column', gap: '15px' }}>
            <input type="file" accept="image/*" onChange={handleFileChange} id="steg-upload" hidden />
            
            {previewUrl ? (
              <img src={previewUrl} alt="Preview" style={{ width: '100%', maxHeight: '300px', objectFit: 'contain', borderRadius: '8px', border: `1px solid ${theme.border}` }} />
            ) : (
              <label htmlFor="steg-upload" style={{ height: '200px', borderRadius: '8px', border: `2px dashed ${theme.border}`, display: 'flex', justifyContent: 'center', alignItems: 'center', cursor: 'pointer', color: theme.subText }}>
                <Upload size={24} style={{ marginRight: '10px' }}/> Klik untuk pilih foto aspal
              </label>
            )}

            {mode === 'encode' && (
              <textarea 
                placeholder="Tulis pesan rahasia Anda di sini..."
                value={secretMessage}
                onChange={(e) => setSecretMessage(e.target.value)}
                style={{ width: '100%', padding: '15px', borderRadius: '8px', border: `1px solid ${theme.border}`, backgroundColor: theme.bg, color: theme.text, minHeight: '100px', boxSizing: 'border-box' }}
              />
            )}

            <button 
              onClick={handleProcess} 
              disabled={isLoading || !selectedFile}
              style={{ ...actionBtn(false, theme), backgroundColor: mode === 'encode' ? theme.accent : '#10b981', width: '100%', padding: '14px', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '10px' }}
            >
              {isLoading ? <Loader2 className="animate-spin" /> : (mode === 'encode' ? "Suntikkan Pesan (3 Kredit)" : "Ekstrak Pesan (2 Kredit)")}
            </button>

            {/* HASIL ENCODE (DOWNLOAD) */}
            {resultUrl && mode === 'encode' && (
              <div style={{ textAlign: 'center', marginTop: '10px', padding: '15px', backgroundColor: '#fbbf2420', borderRadius: '8px', border: '1px solid #fbbf24' }}>
                <ShieldAlert size={24} color="#fbbf24" style={{ marginBottom: '10px' }}/>
                <p style={{ color: theme.text, fontSize: '14px', marginBottom: '15px' }}>
                  Pesan berhasil disuntikkan! <b>Penting:</b> Gambar harus dikirim sebagai <b>Dokumen (File)</b> agar pesan tidak rusak oleh kompresi WhatsApp.
                </p>
                <a href={resultUrl} download="Omni_Secret.png" style={{ display: 'inline-flex', padding: '10px 20px', backgroundColor: '#fbbf24', color: '#000', borderRadius: '8px', textDecoration: 'none', fontWeight: 'bold' }}>
                  <Download size={18} style={{ marginRight: '8px' }}/> Unduh Gambar Aman (.png)
                </a>
              </div>
            )}

            {/* HASIL DECODE */}
            {decodedMessage && mode === 'decode' && (
              <div style={{ padding: '20px', backgroundColor: '#10b98120', borderRadius: '8px', border: '1px solid #10b981' }}>
                <p style={{ fontSize: '12px', color: '#10b981', fontWeight: 'bold', marginBottom: '5px' }}>PESAN DITEMUKAN:</p>
                <p style={{ fontSize: '18px', color: theme.text, fontFamily: 'monospace' }}>{decodedMessage}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Steganography;