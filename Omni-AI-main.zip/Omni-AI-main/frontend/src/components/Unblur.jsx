import React, { useState, useEffect } from 'react';
import { Focus, Upload, Download, Loader2, Image as ImageIcon } from 'lucide-react';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
import { 
  scrollArea, 
  visionCard, 
  visionCardHeader, 
  actionBtn 
} from '../styles/themeStyles';

function Unblur({ theme }) {
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [unblurredUrl, setUnblurredUrl] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const API_BASE = "https://mtztf49c-8000.asse.devtunnels.ms";

  useEffect(() => {
    return () => {
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      if (unblurredUrl) URL.revokeObjectURL(unblurredUrl);
    };
  }, [previewUrl, unblurredUrl]);

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      setPreviewUrl(URL.createObjectURL(file));
      setUnblurredUrl(null); 
    }
  };

  const handleUnblur = async () => {
    if (!selectedFile) return;
    setIsLoading(true);
    
    const formData = new FormData();
    formData.append('file', selectedFile);

    try {
      const response = await axios.post(
        `${API_BASE}/api/unblur`,
        formData,
        { 
          responseType: 'blob',
          headers: { 'Authorization': `Bearer ${localStorage.getItem('omni_token')}` }
        }
      );
      
      const url = URL.createObjectURL(response.data);
      setUnblurredUrl(url);
      toast.success("Berhasil memperjelas! (3 Kredit)");
    } catch (error) {
      if (error.response && error.response.status === 403) {
        toast.error("Kredit habis!");
      } else {
        toast.error("Gagal terhubung ke server.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={scrollArea}>
      <Toaster position="top-center" />
      <div style={{ maxWidth: '800px', margin: '0 auto', padding: '30px' }}>
        <div style={{...visionCard, backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`}}>
          
          <div style={visionCardHeader}>
            <Focus size={24} color={theme.accent}/>
            <div>
              <h3 style={{fontSize: '18px', margin: 0, color: theme.text}}>AI Image Unblur</h3>
              <p style={{fontSize: '13px', color: theme.subText, margin: '2px 0 0 0'}}>3 Kredit per proses rekonstruksi piksel.</p>
            </div>
          </div>

          <div style={{ padding: '20px 0', display: 'flex', flexDirection: 'column', gap: '20px' }}>
            
            {/* PERBAIKAN LABEL UPLOAD: Dibuat seperti kotak OmniVision agar teks muncul */}
            <div 
              onClick={() => document.getElementById('unblur-upload').click()}
              style={{
                width: '100%', height: '100px', borderRadius: '12px',
                border: `2px dashed ${theme.border}`, backgroundColor: theme.bg,
                display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center',
                cursor: 'pointer', transition: 'all 0.3s'
              }}
            >
              <Upload size={24} color={theme.subText} style={{ marginBottom: '8px' }} />
              <span style={{ color: theme.text, fontSize: '14px', fontWeight: '600' }}>
                {selectedFile ? "Ganti Foto Buram" : "Klik untuk Pilih Foto Buram"}
              </span>
              <input type="file" id="unblur-upload" hidden onChange={handleFileChange} accept="image/*" />
            </div>

            {/* AREA PREVIEW & HASIL */}
            {(previewUrl || isLoading || unblurredUrl) && (
              <div style={{ display: 'flex', gap: '20px', justifyContent: 'center', flexWrap: 'wrap' }}>
                
                {previewUrl && (
                  <div style={{ flex: 1, minWidth: '250px', textAlign: 'center' }}>
                    <p style={{ color: theme.subText, marginBottom: '10px', fontSize: '12px', fontWeight: 'bold' }}>BEFORE</p>
                    <img src={previewUrl} alt="Original" style={{ width: '100%', borderRadius: '12px', border: `1px solid ${theme.border}` }} />
                  </div>
                )}

                {isLoading ? (
                  <div style={{ flex: 1, minWidth: '250px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                    <Loader2 size={40} color={theme.accent} className="animate-spin" />
                    <p style={{ marginTop: '15px', color: theme.text, fontWeight: '500' }}>Mempertajam...</p>
                  </div>
                ) : unblurredUrl ? (
                  <div style={{ flex: 1, minWidth: '250px', textAlign: 'center' }}>
                    <p style={{ color: theme.accent, marginBottom: '10px', fontSize: '12px', fontWeight: 'bold' }}>AFTER</p>
                    <img src={unblurredUrl} alt="Sharp" style={{ width: '100%', borderRadius: '12px', border: `2px solid ${theme.accent}` }} />
                    <a 
                      href={unblurredUrl} 
                      download="Omni_Unblurred.png" 
                      style={{ ...actionBtn(false, theme), backgroundColor: '#22c55e', color: 'white', marginTop: '15px', display: 'inline-flex', gap: '8px', textDecoration: 'none', padding: '10px 20px' }}
                    >
                      <Download size={18} /> Unduh Hasil
                    </a>
                  </div>
                ) : null}
              </div>
            )}

            {/* TOMBOL PROSES */}
            {selectedFile && !isLoading && !unblurredUrl && (
              <button 
                onClick={handleUnblur} 
                style={{ ...actionBtn(false, theme), backgroundColor: theme.accent, width: '100%', padding: '15px', fontWeight: 'bold', fontSize: '16px' }}
              >
                <Focus size={20} style={{ marginRight: '8px' }}/> Perjelas Sekarang (3 Kredit)
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Unblur;