import React, { useState, useEffect } from 'react';
import { Maximize, Upload, Download, Loader2, ImageIcon } from 'lucide-react';
import axios from 'axios';
import { scrollArea, visionCard, visionCardHeader, actionBtn } from '../styles/themeStyles';
import toast, { Toaster } from 'react-hot-toast';

function Upscaler({ theme }) {
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [upscaledUrl, setUpscaledUrl] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const API_BASE = "https://mtztf49c-8000.asse.devtunnels.ms";

  // Membersihkan URL objek untuk mencegah memory leak
  useEffect(() => {
    return () => {
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      if (upscaledUrl) URL.revokeObjectURL(upscaledUrl);
    };
  }, [previewUrl, upscaledUrl]);

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      setPreviewUrl(URL.createObjectURL(file));
      setUpscaledUrl(null);
    }
  };

  const handleUpscale = async () => {
    if (!selectedFile) return;
    setIsLoading(true);
    setUpscaledUrl(null);

    const formData = new FormData();
    formData.append('file', selectedFile);

    try {
      // PROSES KIRIM TOKEN & POTONG 2 KREDIT
      const response = await axios.post(
        `${API_BASE}/api/upscale`,
        formData,
        { 
          responseType: 'blob', // Penting untuk menerima data gambar biner
          headers: { 
            'Authorization': `Bearer ${localStorage.getItem('omni_token')}` 
          }
        }
      );
      
      const url = URL.createObjectURL(response.data);
      setUpscaledUrl(url);
      toast.success("Upscaling selesai! (2 Kredit terpotong)");
    } catch (error) {
      if (error.response && error.response.status === 403) {
        toast.error("Kredit tidak cukup! Butuh 2 kredit.");
      } else {
        toast.error("Gagal melakukan upscaling gambar.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={scrollArea}>
      <Toaster position="top-center" />
      <div style={{ maxWidth: '800px', margin: '0 auto', padding: '30px' }}>
        <div style={{...visionCard, backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`}}>
          
          <div style={visionCardHeader}>
            <Maximize size={24} color={theme.accent}/>
            <div>
              <h3 style={{fontSize: '18px', margin: 0, color: theme.text}}>Smart Image Upscaler</h3>
              <p style={{fontSize: '13px', color: theme.subText, margin: '2px 0 0 0'}}>
                Biaya: 2 Kredit per proses peningkatan resolusi AI.
              </p>
            </div>
          </div>

          <div style={{ padding: '20px 0', display: 'flex', flexDirection: 'column', gap: '20px' }}>
            
            {/* AREA UPLOAD */}
            <div 
              onClick={() => document.getElementById('file-upload').click()}
              style={{
                width: '100%', height: '100px', borderRadius: '12px',
                border: `2px dashed ${theme.border}`, backgroundColor: theme.bg,
                display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center',
                cursor: 'pointer', transition: 'all 0.3s'
              }}
            >
              <Upload size={24} color={theme.subText} style={{ marginBottom: '8px' }} />
              <span style={{ color: theme.text, fontSize: '14px', fontWeight: '600' }}>
                {selectedFile ? "Ganti Gambar" : "Klik untuk Pilih Gambar"}
              </span>
              <input type="file" id="file-upload" hidden onChange={handleFileChange} accept="image/*" />
            </div>

            {/* AREA PREVIEW & HASIL */}
            {(previewUrl || isLoading || upscaledUrl) && (
              <div style={{ display: 'flex', gap: '20px', justifyContent: 'center', flexWrap: 'wrap' }}>
                
                {previewUrl && (
                  <div style={{ flex: 1, minWidth: '250px', textAlign: 'center' }}>
                    <p style={{ color: theme.subText, marginBottom: '10px', fontSize: '12px', fontWeight: 'bold' }}>BEFORE (LOW RES)</p>
                    <img src={previewUrl} alt="Original" style={{ width: '100%', borderRadius: '12px', border: `1px solid ${theme.border}` }} />
                  </div>
                )}

                {isLoading ? (
                  <div style={{ flex: 1, minWidth: '250px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                    <Loader2 size={40} color={theme.accent} className="animate-spin" />
                    <p style={{ marginTop: '15px', color: theme.text, fontWeight: '500' }}>Merekonstruksi Piksel...</p>
                  </div>
                ) : upscaledUrl ? (
                  <div style={{ flex: 1, minWidth: '250px', textAlign: 'center' }}>
                    <p style={{ color: theme.accent, marginBottom: '10px', fontSize: '12px', fontWeight: 'bold' }}>AFTER (HIGH RES)</p>
                    <img src={upscaledUrl} alt="Upscaled" style={{ width: '100%', borderRadius: '12px', border: `2px solid ${theme.accent}` }} />
                    <a 
                      href={upscaledUrl} 
                      download="Omni_Upscaled.png" 
                      style={{ 
                        ...actionBtn(false, theme), 
                        backgroundColor: '#22c55e', 
                        color: 'white', 
                        marginTop: '15px', 
                        display: 'inline-flex', 
                        gap: '8px', 
                        textDecoration: 'none', 
                        padding: '10px 20px',
                        fontWeight: 'bold'
                      }}
                    >
                      <Download size={18} /> Unduh Hasil HD
                    </a>
                  </div>
                ) : null}
              </div>
            )}

            {/* TOMBOL PROSES */}
            {selectedFile && !isLoading && !upscaledUrl && (
              <button 
                onClick={handleUpscale} 
                style={{ 
                  ...actionBtn(false, theme), 
                  backgroundColor: theme.accent, 
                  width: '100%', 
                  padding: '15px', 
                  fontWeight: 'bold', 
                  fontSize: '16px' 
                }}
              >
                <Maximize size={20} style={{ marginRight: '8px' }}/> Upscale Sekarang (2 Kredit)
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Upscaler;