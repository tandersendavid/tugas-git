import React, { useState, useEffect } from 'react';
import { Layers3, UploadCloud, Video, Square, Download, Power } from 'lucide-react';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
import { 
  scrollArea, visionCard, visionCardHeader, 
  videoStreamWrapper, videoStreamImg, visionDisclaimer, actionBtn
} from '../styles/themeStyles';

function VirtualBackground({ theme }) {
  const [isRecording, setIsRecording] = useState(false);
  const [hasRecording, setHasRecording] = useState(false);
  const [statusMsg, setStatusMsg] = useState('');
  const [isStreamActive, setIsStreamActive] = useState(false);

  // --- KONFIGURASI JALUR CEPAT ---
  const API_BASE_TUNNEL = "https://mtztf49c-8000.asse.devtunnels.ms";
  const API_BASE_LOCAL = "http://localhost:8000";

  useEffect(() => {
    return () => {
      axios.post(`${API_BASE_TUNNEL}/api/vision/stop`).catch(() => {});
    };
  }, []);

  const toggleStream = async () => {
    if (isStreamActive) {
      setIsStreamActive(false);
      if (isRecording) {
        setIsRecording(false);
        setHasRecording(true);
      }
      await axios.post(`${API_BASE_TUNNEL}/api/vision/stop`);
      setStatusMsg('AI dihentikan. Memori dibebaskan.');
    } else {
      setIsStreamActive(true);
      setStatusMsg('AI diaktifkan.');
    }
  };

  const handleBgUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    try {
      setStatusMsg('Mengunggah latar belakang...');
      await axios.post(`${API_BASE_TUNNEL}/api/vision/background`, formData);
      setStatusMsg('Latar belakang berhasil diubah!');
      toast.success("Background terpasang!");
    } catch (error) {
      setStatusMsg('Gagal mengubah latar belakang.');
    }
  };

  const toggleRecord = async () => {
    try {
      const action = isRecording ? 'stop' : 'start';
      // Tambahkan Token untuk potong 5 kredit Wilson
      const res = await axios.post(`${API_BASE_TUNNEL}/api/vision/record`, 
        { action },
        { headers: { 'Authorization': `Bearer ${localStorage.getItem('omni_token')}` } }
      );
      
      setIsRecording(!isRecording);
      
      if (action === 'stop') {
        setHasRecording(true); 
        setStatusMsg('Rekaman selesai!');
        toast.success("Video tersimpan di server.");
      } else {
        setHasRecording(false); 
        setStatusMsg(res.data.status);
        toast.success("Merekam... (5 Kredit)");
      }
    } catch (error) {
      toast.error("Gagal memulai rekaman.");
    }
  };

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = `${API_BASE_TUNNEL}/api/vision/download_record`;
    link.setAttribute('download', 'Omni_Studio_Record.avi');
    document.body.appendChild(link);
    link.click();
    link.parentNode.removeChild(link);
    setHasRecording(false);
  };

  return (
    <div style={scrollArea}>
      <Toaster position="top-center" />
      <div style={swapContainerStyle}>
        <div style={{...visionCard, backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`}}>
          <div style={visionCardHeader}>
            <Layers3 size={24} color={theme.accent}/>
            <div>
              <h3 style={{fontSize: '18px', margin: 0, color: theme.text}}>AI No-Greenscreen Studio</h3>
              <p style={{fontSize: '13px', color: theme.subText, margin: '2px 0 0 0'}}>Beralih ke mod Lokal untuk performa maksimal.</p>
            </div>
          </div>
          
          <div style={{...videoStreamWrapper, height: '350px', border: `2px solid ${isRecording ? '#ef4444' : (isStreamActive ? '#10b981' : theme.border)}`, backgroundColor: '#000', display: 'flex', justifyContent: 'center', alignItems: 'center', borderRadius: '12px', overflow: 'hidden'}}>
            {isStreamActive ? (
              <img 
                /* JALUR LOKAL: Untuk preview yang sangat lancar tanpa lag */
                src={`${API_BASE_LOCAL}/api/vision/stream_vb?token=${localStorage.getItem('omni_token')}`} 
                alt="AI Virtual Background Stream" 
                style={videoStreamImg}
                onError={() => {
                  toast.error("Gagal memuat stream lokal. Pastikan port 8000 terbuka!");
                  setIsStreamActive(false);
                }}
              />
            ) : (
              <div style={{ color: 'white', textAlign: 'center' }}>
                <Power size={48} color="#ef4444" style={{ marginBottom: '10px' }}/>
                <p>Studio Dijeda.<br/>Siap digunakan secara lokal.</p>
              </div>
            )}
          </div>

          <div style={controlPanel}>
            <label style={{...uploadBtnStyle, backgroundColor: theme.bg, color: theme.text, border: `1px solid ${theme.border}`}}>
              <input type="file" accept="image/*" onChange={handleBgUpload} style={{ display: 'none' }} />
              <UploadCloud size={18}/> Ganti Background
            </label>

            <button 
              onClick={toggleRecord} 
              disabled={!isStreamActive}
              style={{...actionBtn(false, theme), backgroundColor: isRecording ? '#ef4444' : '#10b981', flex: 1, padding: '10px', opacity: !isStreamActive ? 0.5 : 1}}
            >
              {isRecording ? <><Square size={18}/> Berhenti</> : <><Video size={18}/> Rekam (5 Kredit)</>}
            </button>
          </div>

          <button 
            onClick={toggleStream} 
            style={{...actionBtn(false, theme), backgroundColor: isStreamActive ? '#ef4444' : '#10b981', width: '100%', marginTop: '15px', padding: '12px'}}
          >
            <Power size={18}/> {isStreamActive ? "Matikan Studio" : "Nyalakan Studio AI"}
          </button>

          {hasRecording && (
            <button 
              onClick={handleDownload} 
              style={{...actionBtn(false, theme), backgroundColor: '#3b82f6', width: '100%', marginTop: '15px', padding: '12px'}}
            >
              <Download size={18}/> Unduh Video Sekarang
            </button>
          )}

          {statusMsg && <p style={statusTextStyle}>{statusMsg}</p>}
        </div>
      </div>
    </div>
  );
}

const swapContainerStyle = { maxWidth: '800px', margin: '0 auto', padding: '30px', display: 'flex', justifyContent: 'center' };
const controlPanel = { display: 'flex', gap: '15px', marginTop: '20px' };
const uploadBtnStyle = { display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', padding: '10px 20px', borderRadius: '12px', cursor: 'pointer', fontWeight: 'bold', fontSize: '14px', flex: 1, transition: '0.2s' };
const statusTextStyle = { textAlign: 'center', fontSize: '13px', color: '#2563eb', marginTop: '15px', fontWeight: 'bold' };

export default VirtualBackground;