import React, { useState, useRef } from 'react';
import { Mic, Square, Loader2, Play, Volume2, Users } from 'lucide-react';
import { scrollArea, visionCard, visionCardHeader, actionBtn } from '../styles/themeStyles';
import toast, { Toaster } from 'react-hot-toast';

function VoiceChanger({ theme }) {
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState(null);
  const [resultAudioUrl, setResultAudioUrl] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  
  // STATE BARU: Untuk menyimpan pilihan suara
  const [selectedVoice, setSelectedVoice] = useState('21m00Tcm4TlvDq8ikWAM'); 

  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);

  // Daftar Karakter Suara Resmi dari ElevenLabs
  // Daftar Lengkap 45 Karakter Suara Resmi ElevenLabs
  const voiceOptions = [
    { id: '21m00Tcm4TlvDq8ikWAM', name: '👩 Rachel (Wanita, Calm / Narator)' },
    { id: 'pNInz6obpgDQGcFmaJgB', name: '👨 Adam (Pria, Deep / Narator)' },
    { id: 'Xb7hH8MSUJpSbSDYk0k2', name: '👩 Alice (Wanita, Confident / Berita)' },
    { id: 'ErXwobaYiN019PkySvjV', name: '👨 Antoni (Pria, Natural / Narator)' },
    { id: 'VR6AewLTigWG4xSOukaG', name: '👨 Arnold (Pria, Crisp / Narator)' },
    { id: 'AZnzlk1XvdvUeBnXmlld', name: '👩 Domi (Wanita, Ekspresif & Kuat)' },
    { id: 'pqHfZKP75CvOlQylNhV4', name: '👨 Bill (Pria, Dokumenter Kuat)' },
    { id: 'nPczCjzI2devNBz1zQrb', name: '👨 Brian (Pria, Suara Dalam)' },
    { id: 'N2lVS1w4EtoT3dr4eOWO', name: '👨 Callum (Pria, Serak / Gaming)' },
    { id: 'IKne3meq5aSn9XLyUdCD', name: '👨 Charlie (Pria, Kasual / Australia)' },
    { id: 'XB0fDUnXU5powFXDhCwa', name: '👩 Charlotte (Wanita, Menggoda / Gaming)' },
    { id: 'iP95p4xoKVk53GoZ742B', name: '👨 Chris (Pria, Kasual)' },
    { id: '2EiwWnXFnvU5JabPnv8n', name: '👨 Clyde (Pria, Veteran Perang)' },
    { id: 'onwK4e9ZLuTAKqWW03F9', name: '👨 Daniel (Pria, Presenter Berita)' },
    { id: 'CYw3kZ02Hs0563khs1Fj', name: '👨 Dave (Pria, Logat British)' },
    { id: 'ThT5KcBeYPX3keUQqHPh', name: '👩 Dorothy (Wanita, Cerita Anak)' },
    { id: '29vD33N1CtxCmqQRPOHJ', name: '👨 Drew (Pria, Berita Utama)' },
    { id: 'LcfcDJNUP1GQjkzn1xUU', name: '👩 Emily (Wanita, Tenang / Meditasi)' },
    { id: 'g5CIjZEefAph4nQFvHAz', name: '👨 Ethan (Pria, Suara ASMR)' },
    { id: 'D38z5RcWu1voky8WS1ja', name: '👴 Fin (Kakek, Pelaut Irlandia)' },
    { id: 'jsCqWAovK2LkecY7zXl4', name: '👩 Freya (Wanita, Standar Amerika)' },
    { id: 'JBFqnCBsd6RMkjVDRZzb', name: '👨 George (Pria, Serak / Narator)' },
    { id: 'jBpfuIE2acCO8z3wKNLl', name: '👧 Gigi (Anak Perempuan, Childish)' },
    { id: 'zcAOhNBS3c14rBihAFp1', name: '👨 Giovanni (Pria, Aksen Asing)' },
    { id: 'z9fAnlkpzviPz146aGWa', name: '🧙‍♀️ Glinda (Penyihir Wanita)' },
    { id: 'oWAxZDx7w5VEj9dCyTzz', name: '👩 Grace (Wanita, Logat Selatan)' },
    { id: 'SOYHLrjzK2X1ezoPC6cr', name: '👨 Harry (Pria, Cemas / Gaming)' },
    { id: 'ZQe5CZNOzWyzPSCn5a3c', name: '👴 James (Kakek, Berita Tenang)' },
    { id: 'bVMeCyTHy58xNoL34h3p', name: '👨 Jeremy (Pria, Bersemangat / Irlandia)' },
    { id: 't0jbNlBVZ17f02VDIeMI', name: '👴 Jessie (Kakek, Serak / Gaming)' },
    { id: 'Zlb1dXrM653N07WRdFW3', name: '👨 Joseph (Pria, Berita British)' },
    { id: 'TxGEqnHWrfWFTfGW9XjX', name: '👨 Josh (Pria, Deep Narator)' },
    { id: 'TX3LPaxmHKxFdv7VOQHJ', name: '👨 Liam (Pria, Narator Amerika)' },
    { id: 'pFZP5JQG7iQjIQuC4Bku', name: '👩 Lily (Wanita, Serak British)' },
    { id: 'XrExE9yKIg1WjnnlVkGX', name: '👩 Matilda (Wanita, Hangat / Audiobook)' },
    { id: 'flq6f7yk4E4fJM5XTYuZ', name: '👴 Michael (Kakek, Audiobook)' },
    { id: 'zrHiDhphv9ZnVXBqCLjz', name: '👧 Mimi (Anak Perempuan, Animasi)' },
    { id: 'piTKgcLEGmPE4e6mEKli', name: '👩 Nicole (Wanita, Berbisik)' },
    { id: 'ODq5zmih8GrVes37Dizd', name: '👨 Patrick (Pria, Berteriak / Gaming)' },
    { id: '5Q0t7uMcjvnagumLfvZi', name: '👨 Paul (Pria, Reporter Lapangan)' },
    { id: 'oZ06aMxZJJ28mfd3POQ', name: '👨 Samy (Pria, Serak Narator)' },
    { id: 'EXAVITQu4vr4xnSDxMaL', name: '👩 Sarah (Wanita, Lembut / Berita)' },
    { id: 'pMsXgVXv3BLzUgSXRplE', name: '👩 Serena (Wanita, Interaktif)' },
    { id: 'GBv7mTt0atIp3Br8iCZE', name: '👨 Thomas (Pria, Tenang / Meditasi)' },
    { id: 'knrPHWnBmmDHMoiMeP3l', name: '🎅 Santa Claus (Kakek, Edisi Natal)' }
  ];

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream);
      audioChunksRef.current = [];

      mediaRecorderRef.current.ondataavailable = (event) => {
        if (event.data.size > 0) audioChunksRef.current.push(event.data);
      };

      mediaRecorderRef.current.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        setAudioBlob(audioBlob);
      };

      mediaRecorderRef.current.start();
      setIsRecording(true);
      setResultAudioUrl(null);
    } catch (error) {
      console.error("Error accessing mic:", error);
      toast.error("Gagal mengakses Mikrofon. Pastikan Anda memberikan izin.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
    }
  };

  const handleChangeVoice = async () => {
    if (!audioBlob) return;
    if (!window.puter) {
      toast.error("Puter.js belum siap. Pastikan Anda sudah memasukkan script di index.html");
      return;
    }

    setIsLoading(true);

    try {
      // Menggunakan voice ID yang dipilih dari Dropdown
      const audioResultUrl = await window.puter.ai.speech2speech(audioBlob, {
        voice: selectedVoice, 
        model: 'eleven_multilingual_sts_v2'
      });
      
      setResultAudioUrl(audioResultUrl);
    } catch (error) {
      console.error("Error dari Puter API:", error);
      toast.error("Gagal mengubah suara. Coba rekam ulang dengan intonasi yang lebih jelas.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={scrollArea}>
      <div style={{ maxWidth: '800px', margin: '0 auto', padding: '30px' }}>
        <div style={{...visionCard, backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`}}>
          
          <div style={visionCardHeader}>
            <Volume2 size={24} color={theme.accent}/>
            <div>
              <h3 style={{fontSize: '18px', margin: 0, color: theme.text}}>AI Voice Changer</h3>
              <p style={{fontSize: '13px', color: theme.subText, margin: '2px 0 0 0'}}>Powered by Puter.js & ElevenLabs</p>
            </div>
          </div>

          <div style={{ padding: '20px 0', display: 'flex', flexDirection: 'column', gap: '20px', alignItems: 'center' }}>
            
            <div style={{ display: 'flex', gap: '15px' }}>
              {!isRecording ? (
                <button 
                  onClick={startRecording}
                  style={{
                    ...actionBtn(false, theme), backgroundColor: '#ef4444', color: 'white',
                    padding: '15px 30px', borderRadius: '50px', display: 'flex', gap: '10px', fontWeight: 'bold'
                  }}
                >
                  <Mic size={20} /> Mulai Merekam
                </button>
              ) : (
                <button 
                  onClick={stopRecording}
                  style={{
                    ...actionBtn(false, theme), backgroundColor: theme.bg, border: `2px solid #ef4444`, color: '#ef4444',
                    padding: '15px 30px', borderRadius: '50px', display: 'flex', gap: '10px', fontWeight: 'bold', animation: 'pulse 1.5s infinite'
                  }}
                >
                  <Square size={20} /> Berhenti Merekam
                </button>
              )}
            </div>

            {audioBlob && !isRecording && (
              <div style={{ width: '100%', padding: '20px', borderRadius: '12px', backgroundColor: theme.bg, border: `1px solid ${theme.border}`, display: 'flex', flexDirection: 'column', gap: '15px' }}>
                
                {/* PREVIEW ASLI */}
                <div>
                  <span style={{ fontSize: '14px', color: theme.subText, marginBottom: '5px', display: 'block' }}>Audio Asli Anda:</span>
                  <audio src={URL.createObjectURL(audioBlob)} controls style={{ width: '100%', height: '40px' }} />
                </div>

                <hr style={{ border: 'none', borderTop: `1px solid ${theme.border}`, margin: '5px 0' }}/>

                {/* PILIHAN KARAKTER SUARA */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  <label style={{ fontSize: '14px', color: theme.text, display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 'bold' }}>
                    <Users size={16} color={theme.accent} /> Pilih Karakter AI:
                  </label>
                  <select 
                    value={selectedVoice} 
                    onChange={(e) => setSelectedVoice(e.target.value)}
                    style={{
                      width: '100%', padding: '12px', borderRadius: '8px', border: `2px solid ${theme.border}`, 
                      backgroundColor: theme.inputBg, color: theme.text, outline: 'none', fontSize: '15px', cursor: 'pointer'
                    }}
                  >
                    {voiceOptions.map((voice) => (
                      <option key={voice.id} value={voice.id}>{voice.name}</option>
                    ))}
                  </select>
                </div>
                
                <button 
                  onClick={handleChangeVoice}
                  disabled={isLoading}
                  style={{
                    ...actionBtn(false, theme), backgroundColor: theme.accent, width: '100%', padding: '15px',
                    display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '10px', 
                    opacity: isLoading ? 0.6 : 1, cursor: isLoading ? 'not-allowed' : 'pointer', fontWeight: 'bold', marginTop: '5px'
                  }}
                >
                  {isLoading ? (
                    <><Loader2 className="animate-spin" size={20} /> Mentransfer Pita Suara...</>
                  ) : (
                    <><Play size={20} /> Ubah Suara Sekarang</>
                  )}
                </button>
              </div>
            )}

            {resultAudioUrl && (
              <div style={{ width: '100%', padding: '20px', borderRadius: '12px', backgroundColor: '#10b98120', border: `1px solid #10b981`, display: 'flex', flexDirection: 'column', gap: '10px', animation: 'fadeIn 0.5s ease' }}>
                <span style={{ fontSize: '14px', color: '#10b981', fontWeight: 'bold' }}>✨ Suara AI Berhasil Dibuat:</span>
                <audio src={resultAudioUrl} controls autoPlay style={{ width: '100%', height: '40px' }} />
              </div>
            )}

          </div>
        </div>
      </div>
    </div>
  );
}

export default VoiceChanger;