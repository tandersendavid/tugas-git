import React, { useState, useEffect } from 'react';
import { Camera, Loader2, Link as LinkIcon, Download, ShieldCheck } from 'lucide-react';
import { scrollArea, visionCard, visionCardHeader, actionBtn } from '../styles/themeStyles';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';

function WebScreenshot({ theme }) {
  const [url, setUrl] = useState('');
  const [imageUrl, setImageUrl] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const API_BASE = "https://mtztf49c-8000.asse.devtunnels.ms";

  // Reset saat pindah tab
  useEffect(() => {
    setImageUrl(null);
    setUrl('');
  }, []);

  const handleCapture = async () => {
    if (!url) return;
    setIsLoading(true);
    setImageUrl(null);

    const token = localStorage.getItem('omni_token');

    try {
      // --- INTEGRASI SISTEM KREDIT (2 KREDIT) ---
      // Kita menyisipkan token di URL agar backend bisa memotong kredit sebelum mengambil screenshot
      const targetUrl = `${API_BASE}/api/tools/screenshot?url=${encodeURIComponent(url)}&token=${token}`;

      // Gunakan Image object untuk pre-loading gambar hasil screenshot
      const img = new Image();
      img.onload = () => {
        setImageUrl(targetUrl);
        setIsLoading(false);
        toast.success("Screenshot berhasil diambil! (2 Kredit)");
      };
      img.onerror = () => {
        toast.error("Gagal mengambil screenshot. Cek saldo atau validitas URL.");
        setIsLoading(false);
      };
      
      img.src = targetUrl; 
    } catch (error) {
      toast.error("Terjadi kesalahan sistem.");
      setIsLoading(false);
    }
  };

  return (
    <div style={scrollArea}>
      <Toaster position="top-center" />
      <div style={{ maxWidth: '800px', margin: '0 auto', padding: '30px' }}>
        <div style={{...visionCard, backgroundColor: theme.visionCard, border: `1px solid ${theme.border}`}}>
          
          <div style={visionCardHeader}>
            <div style={{ backgroundColor: theme.accent + '20', padding: '10px', borderRadius: '12px' }}>
              <Camera size={24} color={theme.accent}/>
            </div>
            <div>
              <h3 style={{fontSize: '18px', margin: 0, color: theme.text}}>Web Screenshot Scanner</h3>
              <p style={{fontSize: '13px', color: theme.subText, margin: '2px 0 0 0'}}>Biaya: 2 Kredit per pengambilan gambar website.</p>
            </div>
          </div>

          <div style={{ padding: '20px 0', display: 'flex', flexDirection: 'column', gap: '15px' }}>
            
            <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
              <LinkIcon size={18} color={theme.subText} style={{ position: 'absolute', left: '15px' }} />
              <input 
                type="text"
                placeholder="Masukkan URL Web... (contoh: google.com)"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                style={{
                  width: '100%', padding: '14px 15px 14px 45px', borderRadius: '12px',
                  border: `2px solid ${theme.border}`, backgroundColor: theme.bg,
                  color: theme.text, outline: 'none', fontSize: '14px', transition: '0.3s'
                }}
              />
            </div>

            <button 
              onClick={handleCapture}
              disabled={isLoading || !url}
              style={{
                ...actionBtn(false, theme), backgroundColor: theme.accent,
                width: '100%', padding: '14px', opacity: (isLoading || !url) ? 0.6 : 1,
                cursor: (isLoading || !url) ? 'not-allowed' : 'pointer',
                display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '10px',
                fontWeight: 'bold', fontSize: '15px'
              }}
            >
              {isLoading ? (
                <>
                  <Loader2 className="animate-spin" size={20} /> 
                  <span>Memotret Website...</span>
                </>
              ) : (
                <>
                  <Camera size={20} /> 
                  <span>Ambil Screenshot (2 Kredit)</span>
                </>
              )}
            </button>
          </div>

          {imageUrl && (
            <div style={{ 
              marginTop: '10px', padding: '20px', borderRadius: '16px', 
              backgroundColor: theme.bg, border: `1px solid ${theme.border}`,
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '20px', 
              animation: 'fadeIn 0.5s ease'
            }}>
              
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', width: '100%', color: '#22c55e', fontSize: '13px', fontWeight: 'bold' }}>
                <ShieldCheck size={16} /> Scan Selesai: Website Aman Diambil
              </div>

              <div style={{ 
                width: '100%', 
                maxHeight: '500px', 
                overflowY: 'auto', 
                borderRadius: '12px', 
                border: `1px solid ${theme.border}`,
                boxShadow: '0 8px 30px rgba(0,0,0,0.2)',
                backgroundColor: '#1a1a1a'
              }}>
                <img 
                  src={imageUrl} 
                  alt="Web Screenshot Result"
                  style={{ width: '100%', display: 'block' }} 
                />
              </div>

              <a 
                href={`${API_BASE}/api/proxy/download?url=${encodeURIComponent(imageUrl)}&token=${localStorage.getItem('omni_token')}`}
                style={{
                  ...actionBtn(false, theme), textDecoration: 'none', display: 'flex', justifyContent: 'center', gap: '10px',
                  backgroundColor: '#10b981', color: 'white', padding: '14px 20px', fontWeight: 'bold', width: '100%', borderRadius: '12px'
                }}
              >
                <Download size={20} /> Simpan ke Galeri
              </a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default WebScreenshot;