import React, { useState, useEffect } from 'react';
import hammerImg from '../assets/palu.png';

const WhacAMole = () => {
  // State Navigasi & Setup
  const [gameState, setGameState] = useState('menu'); // 'menu', 'playing', 'gameover'
  const [difficulty, setDifficulty] = useState('normal');
  const [timeSetting, setTimeSetting] = useState(30);
  
  // State Permainan
  const [score, setScore] = useState(0);
  const [activeHole, setActiveHole] = useState(null);
  const [hitHole, setHitHole] = useState(null);
  const [hitType, setHitType] = useState(null);
  const [customImage, setCustomImage] = useState(null);
  const [timeLeft, setTimeLeft] = useState(0);
  const [highScore, setHighScore] = useState(0);

  // --- State Kursor Kustom ---
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isHitting, setIsHitting] = useState(false);

  const holes = [0, 1, 2, 3, 4, 5, 6, 7, 8];

  // Fungsi melacak pergerakan mouse
  const handleMouseMove = (e) => {
    setMousePos({ x: e.clientX, y: e.clientY });
  };

  const getDifficultySettings = () => {
    switch (difficulty) {
      case 'easy': return { spawn: 1500, hide: 1000 };
      case 'hard': return { spawn: 600, hide: 450 };
      default: return { spawn: 1000, hide: 750 }; // Normal
    }
  };

  useEffect(() => {
    let timer;
    if (gameState === 'playing' && timeLeft > 0) {
      timer = setInterval(() => setTimeLeft((prev) => prev - 1), 1000);
    } else if (timeLeft === 0 && gameState === 'playing') {
      setGameState('gameover');
      setActiveHole(null);
      if (score > highScore) setHighScore(score);
    }
    return () => clearInterval(timer);
  }, [gameState, timeLeft, score, highScore]);

  useEffect(() => {
    let moleInterval;
    if (gameState === 'playing' && timeLeft > 0) {
      const settings = getDifficultySettings();
      
      moleInterval = setInterval(() => {
        const randomHole = Math.floor(Math.random() * holes.length);
        setActiveHole(randomHole);

        setTimeout(() => {
          setActiveHole(null);
        }, settings.hide);
        
      }, settings.spawn);
    }
    return () => clearInterval(moleInterval);
  }, [gameState, timeLeft, difficulty]);

  const handleHit = (id) => {
    if (gameState !== 'playing') return;

    if (id === activeHole) {
      setScore((prev) => prev + 10);
      setHitType('BAM!');
      setActiveHole(null);
    } else {
      setScore((prev) => Math.max(0, prev - 5));
      setHitType('MISS');
    }
    
    setHitHole(id);
    setTimeout(() => {
      setHitHole(null);
      setHitType(null);
    }, 400);
  };

  const startGame = () => {
    setScore(0);
    setTimeLeft(timeSetting);
    setGameState('playing');
    setHitHole(null);
    setActiveHole(null);
  };

  const handleImageUpload = (e) => {
    if (e.target.files && e.target.files[0]) {
      setCustomImage(URL.createObjectURL(e.target.files[0]));
    }
  };

  const styles = {
    container: {
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      fontFamily: '"Segoe UI", sans-serif', padding: '20px', 
      background: '#f4e5c2', minHeight: '100vh', color: '#333',
      // Sembunyikan kursor asli agar tidak double
      cursor: gameState === 'playing' ? 'none' : 'default',
      position: 'relative',
      overflow: 'hidden'
    },
    // --- Style Palu Kustom ---
    hammer: {
      position: 'fixed',
      left: mousePos.x,
      top: mousePos.y,
      width: '80px', // Ukuran palu
      height: '80px',
      pointerEvents: 'none', // Klik harus tembus ke bawah
      zIndex: 9999,
      // Anchor point di tengah palu, rotasi saat memukul
      transform: `translate(-50%, -50%) rotate(${isHitting ? '-45deg' : '0deg'})`,
      transition: 'transform 0.05s ease-out',
      display: gameState === 'playing' ? 'block' : 'none'
    },
    menuCard: {
      background: 'white', padding: '40px', borderRadius: '20px',
      boxShadow: '0 10px 30px rgba(0,0,0,0.1)', textAlign: 'center',
      width: '100%', maxWidth: '400px', marginTop: '50px',
      cursor: 'default'
    },
    selectBtn: (isActive, color) => ({
      padding: '10px 20px', margin: '5px', borderRadius: '8px',
      border: 'none', fontWeight: 'bold', cursor: 'pointer',
      background: isActive ? color : '#e0e0e0',
      color: isActive ? 'white' : '#555',
      transition: 'all 0.2s', boxShadow: isActive ? `0 4px 0 ${color}aa` : 'none'
    }),
    board: {
      display: 'grid', gridTemplateColumns: 'repeat(3, 130px)', gap: '30px',
      padding: '50px', background: '#d4a373',
      borderRadius: '30px', perspective: '1000px', transform: 'rotateX(30deg)',
      boxShadow: '0 40px 0 #bc6c25, 0 50px 30px rgba(0,0,0,0.5)',
      border: '12px solid #bc6c25', marginTop: '20px'
    },
    hole: {
      width: '130px', height: '110px', background: '#283618',
      borderRadius: '50%', position: 'relative', overflow: 'hidden',
      boxShadow: 'inset 0 20px 30px rgba(0,0,0,0.9), 0 5px 0 #606c38',
      borderBottom: '8px solid #606c38'
    },
    mole: (isActive) => ({
      width: '90px', height: '90px', position: 'absolute',
      left: '20px', bottom: isActive ? '10px' : '-120px',
      transition: 'all 0.15s cubic-bezier(0.34, 1.56, 0.64, 1)',
      objectFit: 'cover', pointerEvents: 'none', filter: 'drop-shadow(0 5px 5px rgba(0,0,0,0.5))'
    }),
    hud: {
      display: 'flex', justifyContent: 'space-between', width: '100%',
      maxWidth: '600px', background: '#fff', padding: '15px 30px',
      borderRadius: '15px', boxShadow: '0 5px 15px rgba(0,0,0,0.05)',
      fontSize: '20px', fontWeight: 'bold', marginBottom: '20px'
    }
  };

  if (gameState === 'menu') {
    return (
      <div style={styles.container}>
        <div style={styles.menuCard}>
          <h1 style={{ color: '#d35400', marginBottom: '30px' }}>Omni Whac-A-Mole</h1>
          
          <div style={{ marginBottom: '25px' }}>
            <h3 style={{ margin: '0 0 10px 0' }}>Waktu Bermain</h3>
            <button style={styles.selectBtn(timeSetting === 30, '#3498db')} onClick={() => setTimeSetting(30)}>30s</button>
            <button style={styles.selectBtn(timeSetting === 60, '#3498db')} onClick={() => setTimeSetting(60)}>60s</button>
            <button style={styles.selectBtn(timeSetting === 90, '#3498db')} onClick={() => setTimeSetting(90)}>90s</button>
          </div>

          <div style={{ marginBottom: '30px' }}>
            <h3 style={{ margin: '0 0 10px 0' }}>Tingkat Kesulitan</h3>
            <button style={styles.selectBtn(difficulty === 'easy', '#2ecc71')} onClick={() => setDifficulty('easy')}>Mudah</button>
            <button style={styles.selectBtn(difficulty === 'normal', '#f39c12')} onClick={() => setDifficulty('normal')}>Normal</button>
            <button style={styles.selectBtn(difficulty === 'hard', '#e74c3c')} onClick={() => setDifficulty('hard')}>Sulit</button>
          </div>

          <div style={{ marginBottom: '20px' }}>
            <input type="file" id="uploadMole" hidden onChange={handleImageUpload} accept="image/*" />
            <label htmlFor="uploadMole" style={{...styles.selectBtn(true, '#9b59b6'), display: 'inline-block'}}>
              {customImage ? '📸 Foto Berhasil Diupload' : '📸 Upload Wajah Target'}
            </label>
          </div>

          <button 
            onClick={startGame} 
            style={{ width: '100%', padding: '15px', fontSize: '18px', background: '#d35400', color: 'white', border: 'none', borderRadius: '10px', fontWeight: 'bold', cursor: 'pointer', boxShadow: '0 5px 0 #a04000' }}
          >
            MULAI GAME 🕹️
          </button>
        </div>
      </div>
    );
  }

  return (
    <div 
      style={styles.container} 
      onMouseMove={handleMouseMove}
      onMouseDown={() => setIsHitting(true)}
      onMouseUp={() => setIsHitting(false)}
    >
      {/* Gambar Palu Kustom */}
      <img 
        src={hammerImg} 
        alt="hammer"
        style={styles.hammer}
      />

      <style>{`
        @keyframes popText { 0% { transform: scale(0.5); opacity: 0; } 100% { transform: scale(1); opacity: 1; } }
      `}</style>

      <div style={styles.hud}>
        <div style={{ color: '#e74c3c' }}>Waktu: {timeLeft}s</div>
        <div style={{ color: '#2ecc71' }}>Skor: {score}</div>
      </div>

      <div style={styles.board}>
        {holes.map((id) => (
          <div key={id} style={styles.hole} onMouseDown={() => handleHit(id)}>
            <img 
              src={customImage || 'https://api.dicebear.com/7.x/bottts/svg?seed=Omni'} 
              alt="mole" 
              style={styles.mole(activeHole === id)} 
            />
            {hitHole === id && (
              <div style={{
                position: 'absolute', top: '15px', left: '20px', 
                color: hitType === 'MISS' ? '#ff4757' : '#f1c40f',
                fontSize: '28px', fontWeight: '900', textShadow: '2px 2px 0 #000',
                animation: 'popText 0.3s ease-out', pointerEvents: 'none', zIndex: 10
              }}>
                {hitType}
              </div>
            )}
            <div style={{ position: 'absolute', bottom: 0, width: '100%', height: '35%', background: 'linear-gradient(to top, rgba(40,54,24,1), transparent)', pointerEvents: 'none' }}></div>
          </div>
        ))}
      </div>

      {gameState === 'gameover' && (
        <div style={{ marginTop: '40px', textAlign: 'center', background: 'white', padding: '30px', borderRadius: '15px', boxShadow: '0 10px 20px rgba(0,0,0,0.1)', cursor: 'default' }}>
          <h2 style={{ color: '#e74c3c', margin: '0 0 10px 0' }}>WAKTU HABIS!</h2>
          <p style={{ fontSize: '20px', margin: '0 0 20px 0' }}>Skor Akhir Kamu: <strong>{score}</strong></p>
          <button onClick={() => setGameState('menu')} style={{ padding: '10px 30px', background: '#3498db', color: 'white', border: 'none', borderRadius: '8px', fontSize: '18px', cursor: 'pointer', fontWeight: 'bold' }}>
            Kembali ke Menu
          </button>
        </div>
      )}
    </div>
  );
};

export default WhacAMole;