// File: src/styles/themeStyles.js

export const containerStyle = { display: 'flex', height: '100vh', width: '100%', overflow: 'hidden', position: 'fixed' };
export const sidebarStyle = { width: '260px', display: 'flex', flexDirection: 'column', padding: '20px', flexShrink: 0, transition: 'all 0.3s ease' };
export const logoArea = { display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px' };
export const logoIcon = { width: '32px', height: '32px', backgroundColor: '#2563eb', borderRadius: '8px', display: 'flex', justifyContent: 'center', alignItems: 'center' };
export const logoText = { fontWeight: 'bold', fontSize: '18px' };

export const navItemStyle = (active, theme) => ({
  display: 'flex', alignItems: 'center', gap: '12px', padding: '12px', borderRadius: '8px',
  backgroundColor: active ? (theme.sidebar === '#f9fafb' ? '#eff6ff' : '#334155') : 'transparent', 
  color: active ? '#2563eb' : theme.subText, cursor: 'pointer', fontWeight: active ? '600' : '400', transition: '0.2s'
});

export const newChatBtn = (theme) => ({
  display: 'flex', alignItems: 'center', gap: '10px', width: '100%', padding: '10px',
  borderRadius: '8px', border: `1px dashed ${theme.border}`, backgroundColor: 'transparent',
  color: theme.text, cursor: 'pointer', marginBottom: '10px', fontSize: '14px', transition: '0.2s'
});

export const historySection = { flex: 1, overflowY: 'auto', marginBottom: '20px', paddingRight: '5px' };
export const historyLabel = { fontSize: '10px', fontWeight: '700', color: '#9ca3af', letterSpacing: '1px', margin: 0 };
export const clearBtn = (theme) => ({ background: 'none', border: 'none', color: theme.subText, cursor: 'pointer', display: 'flex', alignItems: 'center' });
export const historyList = { display: 'flex', flexDirection: 'column', gap: '4px' };
export const historyItem = (theme) => ({ padding: '10px 12px', borderRadius: '8px', fontSize: '13px', cursor: 'pointer', transition: 'all 0.2s ease', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '10px' });
export const singleDeleteBtn = { background: 'none', border: 'none', cursor: 'pointer', padding: '2px', display: 'flex', alignItems: 'center', flexShrink: 0 };
export const themeToggleStyle = (theme) => ({ display: 'flex', alignItems: 'center', gap: '12px', padding: '12px', borderRadius: '8px', cursor: 'pointer', color: theme.subText, border: `1px solid ${theme.border}`, marginTop: '5px' });

export const mainStyle = { flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 };
export const headerStyle = { padding: '15px 40px', flexShrink: 0 };
export const scrollArea = { flex: 1, overflowY: 'auto' };

export const chatContentContainer = { maxWidth: '850px', margin: '0 auto', padding: '30px 20px', display: 'flex', flexDirection: 'column', gap: '40px' };
export const msgRowStyle = (role) => ({ display: 'flex', flexDirection: role === 'user' ? 'row-reverse' : 'row', gap: '16px', width: '100%' });
export const avatarStyle = (role, theme) => ({ width: '32px', height: '32px', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: role === 'user' ? theme.inputBg : '#2563eb', color: role === 'user' ? theme.subText : 'white' });
export const bubbleWrapper = (role) => ({ maxWidth: '85%', display: 'flex', flexDirection: 'column', alignItems: role === 'user' ? 'flex-end' : 'flex-start' });
export const roleHeader = (role, theme) => ({ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '10px', fontWeight: '800', color: theme.subText, marginBottom: '6px' });
export const copyBtn = { background: 'none', border: 'none', cursor: 'pointer', padding: '2px', display: 'flex', alignItems: 'center' };
export const loadingBubble = (theme) => ({ display: 'flex', gap: '6px', padding: '15px 20px', backgroundColor: theme.bubbleAi, borderRadius: '12px', marginTop: '5px' });
export const dotStyle = (theme) => ({ width: '8px', height: '8px', backgroundColor: theme.subText, borderRadius: '50%', animation: 'pulse 1.4s infinite ease-in-out both' });
export const inputSection = { padding: '20px 40px', flexShrink: 0 };
export const inputBox = (loading, theme) => ({ display: 'flex', alignItems: 'center', backgroundColor: theme.inputBg, borderRadius: '24px', padding: '5px 15px', border: `1px solid ${theme.border}`, maxWidth: '800px', margin: '0 auto' });
export const inputField = { flex: 1, border: 'none', backgroundColor: 'transparent', outline: 'none', padding: '12px', fontSize: '15px' };
export const sendBtn = (loading, theme) => ({ width: '36px', height: '36px', backgroundColor: loading ? 'transparent' : '#2563eb', border: 'none', borderRadius: '50%', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' });

export const visionContainer = { maxWidth: '1000px', margin: '0 auto', padding: '30px', display: 'flex', justifyContent: 'center' };
export const visionCard = { padding: '25px', borderRadius: '16px', boxShadow: '0 10px 30px rgba(0,0,0,0.05)', width: '100%' };
export const visionCardHeader = { display: 'flex', alignItems: 'center', gap: '15px', marginBottom: '20px' };
export const videoStreamWrapper = { width: '100%', height: 'auto', borderRadius: '12px', overflow: 'hidden', backgroundColor: '#000', position: 'relative' };
export const videoStreamImg = { width: '100%', height: 'auto', display: 'block', objectFit: 'contain' };
export const visionDisclaimer = { fontSize: '11px', color: '#9ca3af', textAlign: 'center', marginTop: '15px', margin: '15px 0 0 0' };

// === STYLES UNTUK FACE SWAP ===
export const swapContainer = { maxWidth: '1000px', margin: '0 auto', padding: '30px', display: 'flex', flexDirection: 'column', gap: '20px' };
export const uploadGrid = { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' };
export const uploadBox = (theme) => ({ border: `2px dashed ${theme.border}`, borderRadius: '12px', padding: '20px', textAlign: 'center', cursor: 'pointer', backgroundColor: theme.inputBg, transition: '0.3s', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '250px', position: 'relative', overflow: 'hidden' });
export const previewImg = { maxWidth: '100%', maxHeight: '200px', borderRadius: '8px', objectFit: 'contain', zIndex: 1 };
export const actionBtn = (disabled, theme) => ({ width: '100%', padding: '15px', backgroundColor: disabled ? theme.border : theme.accent, color: disabled ? theme.subText : 'white', border: 'none', borderRadius: '12px', fontSize: '16px', fontWeight: 'bold', cursor: disabled ? 'not-allowed' : 'pointer', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '10px', transition: '0.3s' });
export const resultContainer = { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '15px', marginTop: '20px', padding: '20px', borderRadius: '12px', backgroundColor: '#000' };
export const resultImg = { maxWidth: '100%', maxHeight: '500px', borderRadius: '8px' };